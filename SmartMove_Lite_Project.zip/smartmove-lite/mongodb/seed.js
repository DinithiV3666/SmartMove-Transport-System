/**
 * npm run seed  ->  inserts a small amount of sample data (10 documents or fewer per collection):
 *   gps_tracking    8 pings along the Colombo - Kandy route for trip 1
 *   feedback_media  5 documents, one per feedback row in 02_sample_data.sql
 * Ids match the Oracle sample data (trip 1 = vehicle 1, feedback ids 1-5).
 * More GPS pings can be generated in the app with "Simulate journey".
 */
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', 'backend', '.env') });
const { MongoClient } = require('mongodb');

const start = new Date();
start.setDate(start.getDate() - 6);
start.setHours(6, 33, 0, 0);

// [longitude, latitude, minutes after departure, km/h]
const path1 = [
  [79.8500, 6.9335, 0, 0], [79.9500, 7.0010, 35, 48], [80.0600, 7.0900, 60, 52], [80.2000, 7.1800, 85, 45],
  [80.3464, 7.2513, 120, 40], [80.4600, 7.2700, 150, 38], [80.5600, 7.2850, 185, 42], [80.6337, 7.2906, 210, 0],
];
const gps = path1.map(([lng, lat, min, speed]) => ({
  tripId: 1, vehicleId: 1, ts: new Date(start.getTime() + min * 60000),
  location: { type: 'Point', coordinates: [lng, lat] }, speedKmh: speed, heading: 60,
}));

const feedback = [
  { feedbackId: 1, tripId: 1, passengerId: 1, tags: ['punctual', 'clean'], photos: [], sentiment: 'POSITIVE', replies: [] },
  { feedbackId: 2, tripId: 1, passengerId: 2, tags: ['late-start'], photos: [], sentiment: 'POSITIVE', replies: [] },
  { feedbackId: 3, tripId: 2, passengerId: 3, tags: ['late-start', 'delay'], photos: [], sentiment: 'NEUTRAL',
    replies: [{ by: 'staff', message: 'Sorry about the delay, we are reviewing it.', at: new Date() }] },
  { feedbackId: 4, tripId: 3, passengerId: 4, tags: ['comfortable', 'friendly-driver'],
    photos: [{ url: 'https://files.example.com/feedback/4-seat.jpg' }], sentiment: 'POSITIVE', replies: [] },
  { feedbackId: 5, tripId: 4, passengerId: 5, tags: ['ok'], photos: [], sentiment: 'POSITIVE', replies: [] },
].map((d) => ({ ...d, createdAt: new Date() }));

(async () => {
  const uri = process.env.MONGODB_URI;
  if (!uri || uri.includes('<password>')) {
    console.error('Set MONGODB_URI (with the real password) in backend/.env first.');
    process.exit(1);
  }
  const client = new MongoClient(uri);
  await client.connect();
  const db = client.db(process.env.MONGODB_DB || 'smartmove');
  await db.collection('gps_tracking').deleteMany({});
  await db.collection('gps_tracking').insertMany(gps);
  await db.collection('feedback_media').deleteMany({});
  await db.collection('feedback_media').insertMany(feedback);
  console.log(`Seeded ${gps.length} GPS pings and ${feedback.length} feedback_media documents.`);
  await client.close();
})().catch((err) => { console.error(err.message); process.exit(1); });
