# SmartMove Lite: MongoDB (NoSQL) layer

Oracle holds everything transactional (bookings, payments, seat inventory).
MongoDB holds the two kinds of data that do not fit a fixed table well. Documents point
back at Oracle rows with plain numeric ids.

| Collection | What it stores | Why MongoDB |
|---|---|---|
| `gps_tracking` | One location ping per trip every few minutes | Very high write volume; GeoJSON with a `2dsphere` index for location queries |
| `feedback_media` | Tags, photo links, sentiment and staff replies for a feedback row | Variable-length arrays and threaded replies; the numeric ratings stay in Oracle |

## Setup

```
cd mongodb
npm install
npm run setup   # creates the collections, validators and indexes
npm run seed    # 8 GPS pings (trip 1) and 5 feedback_media documents
```

Both scripts read `../backend/.env`. More GPS data can be generated in the web app
(**GPS tracking > Simulate journey**).
