/**
 * npm run setup  ->  creates the two collections with JSON-schema validators
 * and indexes. Safe to rerun: existing collections get their validator updated.
 * Reads MONGODB_URI and MONGODB_DB from ../backend/.env
 */
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', 'backend', '.env') });
const { MongoClient } = require('mongodb');

const point = {
  bsonType: 'object', required: ['type', 'coordinates'],
  properties: {
    type: { enum: ['Point'] },
    coordinates: { bsonType: 'array', minItems: 2, maxItems: 2, items: { bsonType: ['double', 'int', 'long', 'decimal'] } },
  },
};
const num = { bsonType: ['int', 'long', 'double', 'decimal'] };

const COLLECTIONS = {
  gps_tracking: {
    schema: {
      bsonType: 'object', required: ['tripId', 'vehicleId', 'ts', 'location'],
      properties: {
        tripId: num, vehicleId: num, ts: { bsonType: 'date' }, location: point,
        speedKmh: { bsonType: ['int', 'long', 'double', 'null'], minimum: 0 },
        heading: { bsonType: ['int', 'long', 'double', 'null'], minimum: 0, maximum: 360 },
      },
    },
    indexes: [{ key: { tripId: 1, ts: 1 } }, { key: { location: '2dsphere' } }],
  },
  feedback_media: {
    schema: {
      bsonType: 'object', required: ['feedbackId'],
      properties: {
        feedbackId: num, tripId: num, passengerId: num,
        tags: { bsonType: 'array', items: { bsonType: 'string' } },
        photos: { bsonType: 'array', items: { bsonType: 'object', required: ['url'] } },
        sentiment: { enum: ['POSITIVE', 'NEUTRAL', 'NEGATIVE', null] },
        replies: { bsonType: 'array' },
      },
    },
    indexes: [{ key: { feedbackId: 1 }, unique: true }, { key: { tags: 1 } }],
  },
};

(async () => {
  const uri = process.env.MONGODB_URI;
  if (!uri || uri.includes('<password>')) {
    console.error('Set MONGODB_URI (with the real password) in backend/.env first.');
    process.exit(1);
  }
  const client = new MongoClient(uri);
  await client.connect();
  const db = client.db(process.env.MONGODB_DB || 'smartmove');
  const existing = new Set((await db.listCollections({}, { nameOnly: true }).toArray()).map((c) => c.name));
  for (const [name, spec] of Object.entries(COLLECTIONS)) {
    const validator = { $jsonSchema: spec.schema };
    if (existing.has(name)) {
      await db.command({ collMod: name, validator, validationLevel: 'moderate' });
    } else {
      await db.createCollection(name, { validator, validationLevel: 'moderate' });
    }
    for (const idx of spec.indexes) {
      const { key, ...opts } = idx;
      await db.collection(name).createIndex(key, opts);
    }
    console.log(`${existing.has(name) ? 'updated' : 'created'}  ${name}`);
  }
  await client.close();
  console.log('MongoDB setup complete.');
})().catch((err) => { console.error(err.message); process.exit(1); });
