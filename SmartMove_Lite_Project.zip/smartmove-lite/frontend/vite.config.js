import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The dev server forwards /api/* to the Express backend, so the browser never
// needs to know the API's address and there are no CORS issues.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: { '/api': 'http://localhost:4000' },
  },
});
