import { useCallback, useEffect, useState } from 'react';

/** Loads data with `loader()` whenever `deps` change; exposes reload(). */
export function useLoad(loader, deps = []) {
  const [state, setState] = useState({ data: null, error: null, loading: true });
  const run = useCallback(() => {
    let alive = true;
    setState((s) => ({ ...s, loading: true, error: null }));
    loader()
      .then((data) => alive && setState({ data, error: null, loading: false }))
      .catch((error) => alive && setState({ data: null, error, loading: false }));
    return () => { alive = false; };
  }, deps); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(run, [run]);
  return { ...state, reload: run };
}

/** Wraps an async action with busy / error / success state for forms. */
export function useAction() {
  const [state, setState] = useState({ busy: false, error: null, message: null });
  const run = useCallback(async (fn, successMessage) => {
    setState({ busy: true, error: null, message: null });
    try {
      const result = await fn();
      setState({ busy: false, error: null, message: typeof successMessage === 'function' ? successMessage(result) : successMessage || null });
      return result;
    } catch (error) {
      setState({ busy: false, error, message: null });
      return undefined;
    }
  }, []);
  const clear = useCallback(() => setState({ busy: false, error: null, message: null }), []);
  return { ...state, run, clear };
}
