const lkr = new Intl.NumberFormat('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const whole = new Intl.NumberFormat('en-LK');

export const money = (n) => (n === null || n === undefined ? '–' : `LKR\u00A0${lkr.format(n)}`);
export const moneyShort = (n) => {
  if (n === null || n === undefined) return '–';
  if (Math.abs(n) >= 1e6) return `LKR\u00A0${(n / 1e6).toFixed(2)}M`;
  if (Math.abs(n) >= 1e4) return `LKR\u00A0${Math.round(n / 1e3)}k`;
  return money(n);
};
export const number = (n) => (n === null || n === undefined ? '–' : whole.format(n));
export const pct = (n) => (n === null || n === undefined ? '–' : `${Number(n).toFixed(1)}%`);

export const date = (d) => (d ? new Date(d).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '–');
export const time = (d) => (d ? new Date(d).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) : '–');
export const dateTime = (d) => (d ? `${date(d)}, ${time(d)}` : '–');

export const isoDate = (offsetDays = 0) => {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  const p = (x) => String(x).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
};

export const titleCase = (s) => (s ? String(s).toLowerCase().replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase()) : '–');
