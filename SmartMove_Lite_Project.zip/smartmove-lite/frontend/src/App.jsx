import { Route, Routes } from 'react-router-dom';
import Layout from './components/Layout.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Trips from './pages/Trips.jsx';
import TripDetail from './pages/TripDetail.jsx';
import Bookings from './pages/Bookings.jsx';
import BookingDetail from './pages/BookingDetail.jsx';
import Reports from './pages/Reports.jsx';
import Feedback from './pages/Feedback.jsx';
import Tracking from './pages/Tracking.jsx';
import { PageHeader } from './components/ui.jsx';

function NotFound() {
  return <PageHeader title="Page not found" lead="Pick a section from the route line on the left." />;
}

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Dashboard />} />
        <Route path="trips" element={<Trips />} />
        <Route path="trips/:id" element={<TripDetail />} />
        <Route path="bookings" element={<Bookings />} />
        <Route path="bookings/:key" element={<BookingDetail />} />
        <Route path="reports" element={<Reports />} />
        <Route path="tracking" element={<Tracking />} />
        <Route path="feedback" element={<Feedback />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
