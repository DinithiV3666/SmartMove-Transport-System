import { useMemo, useState } from 'react';
import { api } from '../api.js';
import { useAction, useLoad } from '../hooks.js';
import { Empty, Field, Loader, Notice, PageHeader, RouteBullet, routeColour } from '../components/ui.jsx';
import { date, time } from '../format.js';

// Plots GPS pings (MongoDB) over the route's stops (Oracle) on a simple projected map.
function TrackMap({ pings, stops, colour }) {
  const pts = [...stops.map((s) => [s.longitude, s.latitude]), ...pings.map((p) => p.location.coordinates)];
  if (!pts.length) return null;
  const W = 640; const H = 420; const pad = 36; const labelRoom = 150;
  const xs = pts.map((p) => p[0]); const ys = pts.map((p) => p[1]);
  const [minX, maxX, minY, maxY] = [Math.min(...xs), Math.max(...xs), Math.min(...ys), Math.max(...ys)];
  // Longitude degrees shrink with latitude; scale them so the route keeps its real shape.
  const k = Math.cos(((minY + maxY) / 2) * (Math.PI / 180));
  const spanX = Math.max((maxX - minX) * k, 1e-4); const spanY = Math.max(maxY - minY, 1e-4);
  const scale = Math.min((W - 2 * pad - labelRoom) / spanX, (H - 2 * pad) / spanY);
  const offX = pad + ((W - 2 * pad - labelRoom) - spanX * scale) / 2;
  const offY = pad + ((H - 2 * pad) - spanY * scale) / 2;
  const sx = (x) => offX + (x - minX) * k * scale;
  const sy = (y) => H - offY - (y - minY) * scale;
  const path = pings.map((p, i) => `${i ? 'L' : 'M'}${sx(p.location.coordinates[0]).toFixed(1)},${sy(p.location.coordinates[1]).toFixed(1)}`).join(' ');
  const last = pings[pings.length - 1];
  // Label terminals always; skip intermediate labels that would collide.
  const placed = [];
  const labelled = stops.map((s, i) => {
    const x = sx(s.longitude); const y = sy(s.latitude);
    const terminal = i === 0 || i === stops.length - 1;
    const clash = placed.some((q) => Math.abs(q.y - y) < 16 && Math.abs(q.x - x) < 120);
    const show = terminal || !clash;
    if (show) placed.push({ x, y });
    return { ...s, x, y, show };
  });
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="map-box" role="img" aria-label="Map of GPS positions for this trip" style={{ width: '100%', height: 'auto' }}>
      {path && <path d={path} fill="none" stroke={colour} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" opacity=".7" />}
      {labelled.map((s) => (
        <g key={s.stopId}>
          <circle cx={s.x} cy={s.y} r="7" fill="#fff" stroke={colour} strokeWidth="4" />
          {s.show && <text x={s.x + 12} y={s.y + 5} fontSize="14" fill="#3B4A63">{s.stopName}</text>}
        </g>
      ))}
      {last && <circle cx={sx(last.location.coordinates[0])} cy={sy(last.location.coordinates[1])} r="9" fill={colour} stroke="#fff" strokeWidth="3" />}
    </svg>
  );
}

export default function Tracking() {
  const [tripId, setTripId] = useState('');
  const trips = useLoad(() => api('/trips'));
  const trip = useLoad(() => (tripId ? api(`/trips/${tripId}`) : Promise.resolve(null)), [tripId]);
  const pings = useLoad(() => (tripId ? api(`/nosql/tracking/${tripId}`) : Promise.resolve([])), [tripId]);
  const act = useAction();
  const colour = routeColour(trip.data?.routeCode);
  const simulate = async () => {
    const r = await act.run(() => api(`/nosql/tracking/${tripId}/simulate`, { method: 'POST' }), (x) => `Generated ${x.pings} GPS pings along the route.`);
    if (r) pings.reload();
  };
  const latest = useMemo(() => (pings.data && pings.data.length ? pings.data[pings.data.length - 1] : null), [pings.data]);

  return (
    <>
      <PageHeader title="GPS tracking" lead="GPS positions are stored in MongoDB (gps_tracking) and drawn over the route's stops from Oracle." />
      <section className="section">
        <div className="filters">
          <Field label="Trip">
            <select value={tripId} onChange={(e) => setTripId(e.target.value)}>
              <option value="">Choose…</option>
              {(trips.data || []).map((t) => <option key={t.tripId} value={t.tripId}>{date(t.tripDate)} {time(t.scheduledDeparture)} {t.routeCode} {t.regNo}</option>)}
            </select>
          </Field>
          {tripId && <button type="button" className="btn" onClick={simulate} disabled={act.busy}>Simulate journey</button>}
        </div>
        <Notice error={act.error || pings.error} message={act.message} />
        {!tripId && <Empty>Choose a trip to see where its vehicle has been.</Empty>}
        {tripId && (
          <Loader loading={trip.loading || pings.loading} error={trip.error}>
            {trip.data && (
              <div className="grid-2">
                <TrackMap pings={pings.data || []} stops={trip.data.stops} colour={colour} />
                <div>
                  <h3><RouteBullet code={trip.data.routeCode} /> {trip.data.routeName}</h3>
                  {latest ? (
                    <dl className="details">
                      <dt>Last ping</dt><dd>{time(latest.ts)}</dd>
                      <dt>Speed</dt><dd>{latest.speedKmh ?? '–'} km/h</dd>
                      <dt>Heading</dt><dd>{latest.heading ?? '–'}°</dd>
                      <dt>Pings stored</dt><dd>{pings.data.length}</dd>
                    </dl>
                  ) : <p className="muted">No GPS data for this trip yet. Use “Simulate journey” to generate a realistic track.</p>}
                </div>
              </div>
            )}
          </Loader>
        )}
      </section>
    </>
  );
}
