import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, qs } from '../api.js';
import { useLoad } from '../hooks.js';
import { Empty, Field, Loader, PageHeader, RouteBullet, Status, routeColour } from '../components/ui.jsx';
import { date, time } from '../format.js';

export default function Trips() {
  const [filter, setFilter] = useState({ date: '', routeId: '', status: '' });
  const navigate = useNavigate();
  const lookups = useLoad(() => api('/lookups'));
  const trips = useLoad(() => api(`/trips${qs(filter)}`), [filter.date, filter.routeId, filter.status]);
  const set = (k) => (e) => setFilter({ ...filter, [k]: e.target.value });

  return (
    <>
      <PageHeader title="Trips and booking" lead="Pick a trip to see its stops and book seats." />

      <section className="section">
        <div className="filters">
          <Field label="Date"><input type="date" value={filter.date} onChange={set('date')} /></Field>
          <Field label="Route">
            <select value={filter.routeId} onChange={set('routeId')}>
              <option value="">All routes</option>
              {(lookups.data?.routes || []).map((r) => <option key={r.routeId} value={r.routeId}>{r.routeCode} {r.routeName}</option>)}
            </select>
          </Field>
          <Field label="Status">
            <select value={filter.status} onChange={set('status')}>
              <option value="">Any status</option>
              {['SCHEDULED', 'BOARDING', 'IN_TRANSIT', 'DELAYED', 'COMPLETED', 'CANCELLED'].map((s) => <option key={s} value={s}>{s.replace('_', ' ').toLowerCase()}</option>)}
            </select>
          </Field>
        </div>
        <Loader loading={trips.loading} error={trips.error} onRetry={trips.reload}>
          {trips.data && trips.data.length === 0 && <Empty>No trips match these filters.</Empty>}
          {trips.data && trips.data.length > 0 && (
            <div className="table-wrap">
              <table className="board">
                <thead><tr><th>Date</th><th>Departs</th><th>Route</th><th>Vehicle</th><th>Driver</th><th>Seats left</th><th>Status</th></tr></thead>
                <tbody>
                  {trips.data.map((t) => {
                    const used = 1 - t.seatsAvailable / t.seatCapacity;
                    return (
                      <tr key={t.tripId} className="clickable" onClick={() => navigate(`/trips/${t.tripId}`)}>
                        <td className="nowrap">{date(t.tripDate)}</td>
                        <td className="time">{time(t.scheduledDeparture)}</td>
                        <td><RouteBullet code={t.routeCode} /> <span className="muted">{t.routeName}</span></td>
                        <td className="nowrap">{t.regNo} <span className="muted">{t.typeName.toLowerCase()}</span></td>
                        <td>{t.driverName}</td>
                        <td>
                          <span className="seats-bar" style={{ '--c': routeColour(t.routeCode) }}><span style={{ width: `${Math.round(used * 100)}%` }} /></span>
                          {t.seatsAvailable} / {t.seatCapacity}
                        </td>
                        <td><Status value={t.status} /></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </Loader>
      </section>
    </>
  );
}
