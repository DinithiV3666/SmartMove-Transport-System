import { useState } from 'react';
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { api, qs } from '../api.js';
import { useLoad } from '../hooks.js';
import { Empty, Field, Loader, PageHeader, RouteBullet, Status, Tabs, routeColour } from '../components/ui.jsx';
import { date, isoDate, money, number, pct } from '../format.js';

const TABS = [
  { id: 'routes', label: 'Most used routes' },
  { id: 'revenue', label: 'Revenue' },
  { id: 'history', label: 'Passenger history' },
  { id: 'maintenance', label: 'Maintenance due' },
  { id: 'drivers', label: 'Driver performance' },
];

function Range({ value, onChange, children }) {
  return (
    <div className="filters">
      <Field label="From"><input type="date" value={value.from} onChange={(e) => onChange({ ...value, from: e.target.value })} /></Field>
      <Field label="To"><input type="date" value={value.to} onChange={(e) => onChange({ ...value, to: e.target.value })} /></Field>
      {children}
    </div>
  );
}

function TopRoutes() {
  const [r, setR] = useState({ from: isoDate(-90), to: isoDate(0), top: 6 });
  const { data, error, loading, reload } = useLoad(() => api(`/reports/top-routes${qs(r)}`), [r.from, r.to, r.top]);
  return (
    <>
      <Range value={r} onChange={setR}><Field label="Show top"><input type="number" min="1" max="6" value={r.top} onChange={(e) => setR({ ...r, top: e.target.value })} /></Field></Range>
      <Loader loading={loading} error={error} onRetry={reload}>
        {data && (data.rows.length === 0 ? <Empty>No trips in this period.</Empty> : (
          <div className="grid-2">
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={data.rows} margin={{ left: 0, right: 10 }}>
                <CartesianGrid vertical={false} stroke="#E7EBF1" />
                <XAxis dataKey="routeCode" tick={{ fontSize: 14, fontWeight: 600 }} />
                <YAxis tick={{ fontSize: 13 }} />
                <Tooltip formatter={(v) => number(v)} />
                <Bar dataKey="bookings" name="Bookings" radius={[4, 4, 0, 0]}>{data.rows.map((x) => <Cell key={x.routeCode} fill={routeColour(x.routeCode)} />)}</Bar>
              </BarChart>
            </ResponsiveContainer>
            <div className="table-wrap"><table>
              <thead><tr><th>#</th><th>Route</th><th className="num">Trips</th><th className="num">Bookings</th><th className="num">Seats</th><th className="num">Revenue</th><th className="num">Load</th></tr></thead>
              <tbody>{data.rows.map((x) => (
                <tr key={x.routeCode}><td>{x.rankNo}</td><td><RouteBullet code={x.routeCode} /></td><td className="num">{number(x.trips)}</td><td className="num">{number(x.bookings)}</td><td className="num">{number(x.seatsSold)}</td><td className="num">{money(x.revenue)}</td><td className="num">{pct(x.loadFactorPct)}</td></tr>
              ))}</tbody>
            </table></div>
          </div>
        ))}
      </Loader>
    </>
  );
}

function Revenue() {
  const [r, setR] = useState({ from: isoDate(-30), to: isoDate(0) });
  const { data, error, loading, reload } = useLoad(() => api(`/reports/revenue${qs(r)}`), [r.from, r.to]);
  const sum = data ? data.byMethod.reduce((a, m) => a + m.net, 0) : 0;
  return (
    <>
      <Range value={r} onChange={setR} />
      <Loader loading={loading} error={error} onRetry={reload}>
        {data && (
          <>
            <p><strong style={{ fontFamily: 'var(--cond)', fontSize: 30 }}>{money(data.totalNet)}</strong> <span className="muted">net revenue from {date(data.pFrom)} to {date(data.pTo)} (smartmove_pkg.fn_total_revenue).</span>{' '}
              {Math.abs(sum - data.totalNet) < 0.01
                ? <span className="status tone-good">Breakdown matches the total</span>
                : <span className="status tone-bad">Breakdown differs from the total by {money(data.totalNet - sum)}</span>}</p>
            <div className="grid-2">
              <div className="table-wrap"><h3>By payment method</h3><table>
                <thead><tr><th>Method</th><th className="num">Payments</th><th className="num">Gross</th><th className="num">Refunds</th><th className="num">Net</th><th className="num">Share</th></tr></thead>
                <tbody>{data.byMethod.map((m) => <tr key={m.method}><td>{m.method.toLowerCase()}</td><td className="num">{number(m.txns)}</td><td className="num">{money(m.gross)}</td><td className="num">{money(m.refunds)}</td><td className="num">{money(m.net)}</td><td className="num">{pct(m.sharePct)}</td></tr>)}</tbody>
              </table></div>
              <div className="table-wrap"><h3>By route</h3><table>
                <thead><tr><th>Route</th><th className="num">Bookings</th><th className="num">Seats</th><th className="num">Net</th><th className="num">Per seat</th></tr></thead>
                <tbody>{data.byRoute.map((x) => <tr key={x.routeCode}><td><RouteBullet code={x.routeCode} /></td><td className="num">{number(x.bookings)}</td><td className="num">{number(x.seats)}</td><td className="num">{money(x.net)}</td><td className="num">{money(x.avgPerSeat)}</td></tr>)}</tbody>
              </table></div>
            </div>
          </>
        )}
      </Loader>
    </>
  );
}

function History() {
  const { data: pax } = useLoad(() => api('/passengers'));
  const [id, setId] = useState('');
  const { data, error, loading, reload } = useLoad(
    () => (id ? api(`/reports/passenger-history/${id}`) : Promise.resolve(null)), [id]);
  return (
    <>
      <div className="filters">
        <Field label="Passenger"><select value={id} onChange={(e) => setId(e.target.value)}><option value="">Choose…</option>{(pax || []).map((p) => <option key={p.passengerId} value={p.passengerId}>{p.fullName}</option>)}</select></Field>
      </div>
      {!id && <Empty>Choose a passenger to open their travel history.</Empty>}
      {id && (
        <Loader loading={loading} error={error} onRetry={reload}>
          {data && data.rows.length === 0 && <Empty>No bookings for this passenger.</Empty>}
          {data && data.rows.length > 0 && (
            <div className="table-wrap">
              <table className="board">
                <thead><tr><th>Booking</th><th>Date</th><th>Route</th><th>From</th><th>To</th><th>Seats</th><th>Total</th><th>Status</th><th>Paid by</th><th>Rating</th></tr></thead>
                <tbody>
                  {data.rows.map((r) => (
                    <tr key={r.bookingRef}>
                      <td>{r.bookingRef}</td><td>{date(r.tripDate)} {r.depTime}</td><td>{r.routeCode}</td>
                      <td>{r.boardStop}</td><td>{r.dropStop}</td><td>{r.seatCount}</td><td>{money(r.totalAmount)}</td>
                      <td><Status value={r.bookingStatus} /></td><td>{r.payMethod || '–'}</td><td>{r.rating ?? '–'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Loader>
      )}
    </>
  );
}

function MaintenanceDue() {
  const [p, setP] = useState({ days: 14, km: 2000 });
  const { data, error, loading, reload } = useLoad(() => api(`/reports/maintenance-due${qs(p)}`), [p.days, p.km]);
  return (
    <>
      <div className="filters">
        <Field label="Days ahead"><input type="number" min="0" value={p.days} onChange={(e) => setP({ ...p, days: e.target.value })} /></Field>
        <Field label="Km buffer"><input type="number" min="0" step="500" value={p.km} onChange={(e) => setP({ ...p, km: e.target.value })} /></Field>
      </div>
      <Loader loading={loading} error={error} onRetry={reload}>
        {data && (data.rows.length === 0 ? <Empty>No vehicles due in this window.</Empty> : (
          <div className="table-wrap"><table>
            <thead><tr><th>Priority</th><th>Vehicle</th><th>Last service</th><th>Due</th><th className="num">Days left</th><th className="num">Km left</th><th>Insurance</th></tr></thead>
            <tbody>{data.rows.map((r) => <tr key={r.regNo}><td><Status value={r.priority} /></td><td><strong>{r.regNo}</strong></td><td>{date(r.lastService)}</td><td>{date(r.nextServiceDue)}</td><td className="num">{r.daysRemaining ?? '–'}</td><td className="num">{r.kmRemaining === null ? '–' : number(r.kmRemaining)}</td><td>{date(r.insuranceExpiry)}</td></tr>)}</tbody>
          </table></div>
        ))}
      </Loader>
    </>
  );
}

function Drivers() {
  const [r, setR] = useState({ from: isoDate(-60), to: isoDate(-1) });
  const { data, error, loading, reload } = useLoad(() => api(`/reports/driver-performance${qs(r)}`), [r.from, r.to]);
  return (
    <>
      <Range value={r} onChange={setR} />
      <Loader loading={loading} error={error} onRetry={reload}>
        {data && (data.rows.length === 0 ? <Empty>No completed trips in this period.</Empty> : (
          <div className="table-wrap"><table>
            <thead><tr><th>#</th><th>Driver</th><th className="num">Trips</th><th className="num">Cancelled</th><th className="num">Passengers</th><th className="num">On time</th><th className="num">Avg late</th><th className="num">Rating</th><th className="num">Score</th><th>Band</th></tr></thead>
            <tbody>{data.rows.map((d) => <tr key={d.licenceNo}><td>{d.rankNo}</td><td>{d.driverName}</td><td className="num">{number(d.completed)}</td><td className="num">{number(d.cancelled)}</td><td className="num">{number(d.passengers)}</td><td className="num">{pct(d.onTimePct)}</td><td className="num">{d.avgDelayMin ?? '–'} min</td><td className="num">{d.driverRating ?? '–'}</td><td className="num">{d.score}</td><td><Status value={d.band} /></td></tr>)}</tbody>
          </table></div>
        ))}
      </Loader>
      <p className="field-hint">Score = 50% departures within 10 minutes of schedule + 50% average passenger rating (scaled to 100).</p>
    </>
  );
}

export default function Reports() {
  const [tab, setTab] = useState('routes');
  return (
    <>
      <PageHeader title="Reports" lead="Each report runs the matching function in the smartmove_pkg PL/SQL package." />
      <section className="section">
        <Tabs tabs={TABS} active={tab} onChange={setTab} />
        {tab === 'routes' && <TopRoutes />}
        {tab === 'revenue' && <Revenue />}
        {tab === 'history' && <History />}
        {tab === 'maintenance' && <MaintenanceDue />}
        {tab === 'drivers' && <Drivers />}
      </section>
    </>
  );
}
