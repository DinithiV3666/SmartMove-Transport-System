import { api } from '../api.js';
import { useLoad } from '../hooks.js';
import { Empty, Loader, PageHeader, RouteBullet } from '../components/ui.jsx';
import { date } from '../format.js';

// Ratings come from Oracle (feedback table); tags, sentiment and replies come from MongoDB (feedback_media).
export default function Feedback() {
  const { data, error, loading, reload } = useLoad(() => api('/nosql/feedback'));
  return (
    <>
      <PageHeader title="Feedback" lead="Structured ratings live in Oracle. Free-form tags, sentiment and photos live in MongoDB (feedback_media)." />
      <section className="section">
        <Loader loading={loading} error={error} onRetry={reload}>
          {data && data.length === 0 && <Empty>No feedback yet.</Empty>}
          {data && data.length > 0 && (
            <div className="table-wrap">
              <table className="board">
                <thead><tr><th>Date</th><th>Passenger</th><th>Route</th><th>Overall</th><th>Driver</th><th>Vehicle</th><th>Punctuality</th><th>Comment</th><th>Tags (Mongo)</th><th>Sentiment (Mongo)</th></tr></thead>
                <tbody>
                  {data.map((f) => (
                    <tr key={f.feedbackId}>
                      <td className="nowrap">{date(f.submittedAt)}</td>
                      <td>{f.passengerName}</td>
                      <td><RouteBullet code={f.routeCode} /></td>
                      <td>{f.overallRating}/5</td><td>{f.driverRating ?? '–'}</td><td>{f.vehicleRating ?? '–'}</td><td>{f.punctuality ?? '–'}</td>
                      <td>{f.comments}</td>
                      <td>{f.media ? f.media.tags.join(', ') : '–'}</td>
                      <td>{f.media ? f.media.sentiment.toLowerCase() : '–'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Loader>
      </section>
    </>
  );
}
