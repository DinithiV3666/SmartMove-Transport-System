import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api } from '../api.js';
import { useAction, useLoad } from '../hooks.js';
import { Field, Loader, Notice, PageHeader, RouteBullet, Status } from '../components/ui.jsx';
import { dateTime, money } from '../format.js';

function PaymentForm({ booking, onPaid }) {
  const [f, setF] = useState({ method: 'CARD', cardBrand: 'VISA', cardLast4: '', gateway: 'PayHere', walletProvider: 'FriMi', walletRef: '' });
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const act = useAction();
  const submit = async (e) => {
    e.preventDefault();
    const r = await act.run(() => api(`/bookings/${booking.bookingId}/pay`, { method: 'POST', body: { ...f, amount: booking.totalAmount } }), 'Payment recorded. The booking is confirmed.');
    if (r) onPaid();
  };
  return (
    <form className="section form" onSubmit={submit}>
      <h2>Take payment of {money(booking.totalAmount)}</h2>
      <Notice error={act.error} message={act.message} />
      <div className="form-row">
        <Field label="Method">
          <select value={f.method} onChange={set('method')}>
            <option value="CARD">Card</option><option value="WALLET">Mobile wallet</option><option value="CASH">Cash</option>
          </select>
        </Field>
        {f.method === 'CARD' && (
          <>
            <Field label="Card brand">
              <select value={f.cardBrand} onChange={set('cardBrand')}><option>VISA</option><option>MASTERCARD</option><option>AMEX</option></select>
            </Field>
            <Field label="Last 4 digits" hint="Never store the full card number">
              <input required inputMode="numeric" pattern="[0-9]{4}" maxLength={4} value={f.cardLast4} onChange={set('cardLast4')} />
            </Field>
          </>
        )}
        {f.method === 'WALLET' && (
          <>
            <Field label="Wallet">
              <select value={f.walletProvider} onChange={set('walletProvider')}><option>FriMi</option><option>eZ Cash</option><option>Genie</option></select>
            </Field>
            <Field label="Wallet reference"><input value={f.walletRef} onChange={set('walletRef')} /></Field>
          </>
        )}
      </div>
      <div><button className="btn btn-primary" disabled={act.busy}>Record payment</button></div>
    </form>
  );
}

export default function BookingDetail() {
  const { key } = useParams();
  const { data: b, error, loading, reload } = useLoad(() => api(`/bookings/${encodeURIComponent(key)}`), [key]);
  const cancel = useAction();
  const doCancel = async () => {
    if (!window.confirm('Cancel this booking? Refund: 90% if 24h+ before departure, 50% if 2–24h, none within 2h.')) return;
    const r = await cancel.run(() => api(`/bookings/${b.bookingId}/cancel`, { method: 'POST' }), (x) => `Booking cancelled. Refund: ${money(x.refundAmount)}.`);
    if (r) reload();
  };

  return (
    <Loader loading={loading} error={error} onRetry={reload}>
      {b && (
        <>
          <PageHeader title={`Booking ${b.bookingRef}`} lead={`${b.passengerName}, booked ${dateTime(b.bookedAt)} via ${b.bookingChannel.toLowerCase()}`}>
            <Status value={b.status} />
          </PageHeader>
          <Notice error={cancel.error} message={cancel.message} />
          <div className="grid-2">
            <section className="section">
              <h2>Journey</h2>
              <dl className="details">
                <dt>Route</dt><dd><RouteBullet code={b.routeCode} /> {b.routeName}</dd>
                <dt>Trip</dt><dd><Link to={`/trips/${b.tripId}`}>Trip {b.tripId}</Link> <Status value={b.tripStatus} /></dd>
                <dt>Departs</dt><dd>{dateTime(b.scheduledDeparture)}</dd>
                <dt>From</dt><dd>{b.boardStop}</dd>
                <dt>To</dt><dd>{b.dropStop}</dd>
                <dt>Vehicle</dt><dd>{b.regNo}</dd>
                <dt>Passenger</dt><dd>{b.passengerName}</dd>
                <dt>Total</dt><dd>{money(b.totalAmount)}</dd>
              </dl>
            </section>
            <section className="section">
              <h2>Tickets</h2>
              <div className="ticket-strip">
                {b.tickets.map((t) => (
                  <div className="ticket" key={t.ticketId}>
                    <span className="muted">Seat</span><strong>{t.seatNo}</strong>
                    <span className="muted">{money(t.fare)}</span><br /><Status value={t.status} />
                  </div>
                ))}
              </div>
              <h3 style={{ marginTop: 18 }}>Payments</h3>
              {b.payments.length === 0 ? <p className="muted">Not paid yet.</p> : (
                <table>
                  <thead><tr><th>Reference</th><th>Method</th><th className="num">Amount</th><th className="num">Refund</th><th>Status</th></tr></thead>
                  <tbody>
                    {b.payments.map((p) => (
                      <tr key={p.paymentId}>
                        <td>{p.txnRef}</td>
                        <td>{p.method === 'CARD' ? `${p.cardBrand} ···${p.cardLast4}` : p.method === 'WALLET' ? p.walletProvider : `Cash ${p.receiptNo || ''}`}</td>
                        <td className="num">{money(p.amount)}</td><td className="num">{money(p.refundAmount)}</td><td><Status value={p.status} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </section>
          </div>
          {b.status === 'PENDING' && <PaymentForm booking={b} onPaid={reload} />}
          {['PENDING', 'CONFIRMED'].includes(b.status) && (
            <section className="section">
              <h2>Cancel booking</h2>
              <p className="muted">Seats go back on sale immediately. The refund depends on how close departure is.</p>
              <button type="button" className="btn btn-danger" onClick={doCancel} disabled={cancel.busy}>Cancel booking</button>
            </section>
          )}
        </>
      )}
    </Loader>
  );
}
