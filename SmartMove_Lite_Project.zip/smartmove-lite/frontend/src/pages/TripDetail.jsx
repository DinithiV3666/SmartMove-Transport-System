import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api } from '../api.js';
import { useAction, useLoad } from '../hooks.js';
import { Empty, Field, Loader, Notice, PageHeader, RouteBullet, Status, routeColour } from '../components/ui.jsx';
import { dateTime, money, time } from '../format.js';

function BookingForm({ trip, onBooked }) {
  const navigate = useNavigate();
  const [q, setQ] = useState('');
  const pax = useLoad(() => api(`/passengers${q ? `?q=${encodeURIComponent(q)}` : ''}`), [q]);
  const stops = trip.stops;
  const [f, setF] = useState({ passengerId: '', boardStopId: stops[0]?.stopId || '', dropStopId: stops[stops.length - 1]?.stopId || '', seatCount: 1, channel: 'COUNTER' });
  const [quote, setQuote] = useState(null);
  const act = useAction();
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const boardSeq = stops.find((s) => String(s.stopId) === String(f.boardStopId))?.stopSeq || 0;
  const dropOptions = stops.filter((s) => s.stopSeq > boardSeq);

  useEffect(() => {
    if (!dropOptions.some((s) => String(s.stopId) === String(f.dropStopId)) && dropOptions.length) {
      setF((x) => ({ ...x, dropStopId: dropOptions[dropOptions.length - 1].stopId }));
    }
  }, [f.boardStopId]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    setQuote(null);
    if (!f.passengerId || !f.boardStopId || !f.dropStopId) return;
    api('/bookings/quote', { method: 'POST', body: { routeId: trip.routeId, ...f } })
      .then(setQuote).catch((e) => setQuote({ error: e.message }));
  }, [f.passengerId, f.boardStopId, f.dropStopId, f.seatCount]); // eslint-disable-line react-hooks/exhaustive-deps

  const submit = async (e) => {
    e.preventDefault();
    const r = await act.run(() => api('/bookings', { method: 'POST', body: { tripId: trip.tripId, ...f } }));
    if (r) { onBooked(); navigate(`/bookings/${r.bookingId}`); }
  };

  return (
    <form className="section form" onSubmit={submit}>
      <h2>Book seats</h2>
      <Notice error={act.error} />
      <div className="form-row">
        <Field label="Find passenger" hint="Name, NIC or phone"><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="e.g. Amali" /></Field>
        <Field label="Passenger">
          <select required value={f.passengerId} onChange={set('passengerId')}>
            <option value="">Choose…</option>
            {(pax.data || []).map((p) => <option key={p.passengerId} value={p.passengerId}>{p.fullName} ({p.passengerCategory.toLowerCase()})</option>)}
          </select>
        </Field>
      </div>
      <div className="form-row">
        <Field label="Boards at">
          <select value={f.boardStopId} onChange={set('boardStopId')}>
            {stops.slice(0, -1).map((s) => <option key={s.stopId} value={s.stopId}>{s.stopName}</option>)}
          </select>
        </Field>
        <Field label="Gets off at">
          <select value={f.dropStopId} onChange={set('dropStopId')}>
            {dropOptions.map((s) => <option key={s.stopId} value={s.stopId}>{s.stopName}</option>)}
          </select>
        </Field>
        <Field label="Seats"><input type="number" min="1" max="10" value={f.seatCount} onChange={set('seatCount')} /></Field>
        <Field label="Channel">
          <select value={f.channel} onChange={set('channel')}>
            {['COUNTER', 'ONLINE', 'MOBILE', 'AGENT'].map((c) => <option key={c} value={c}>{c.toLowerCase()}</option>)}
          </select>
        </Field>
      </div>
      {quote && !quote.error && <p><strong>{money(quote.total)}</strong> <span className="muted">({money(quote.unitFare)} per seat, discounts applied)</span></p>}
      {quote?.error && <Notice error={{ message: quote.error }} />}
      <div><button className="btn btn-primary" disabled={act.busy || !f.passengerId}>Reserve seats</button></div>
      <p className="field-hint">The booking is held as pending until it is paid.</p>
    </form>
  );
}

function TripActions({ trip, onChange }) {
  const act = useAction();
  const setStatus = (status) => act.run(() => api(`/trips/${trip.tripId}/status`, { method: 'PATCH', body: { status } }), `Trip marked ${status.toLowerCase().replace('_', ' ')}.`).then((r) => r && onChange());
  const complete = () => act.run(() => api(`/trips/${trip.tripId}/complete`, { method: 'POST' }), (r) => `Trip completed: ${r.passengersCompleted} passenger seat(s) closed out.`).then((r) => r && onChange());
  const s = trip.status;
  return (
    <section className="section">
      <h2>Trip status</h2>
      <Notice error={act.error} message={act.message} />
      <div className="page-actions">
        {s === 'SCHEDULED' && <button type="button" className="btn" onClick={() => setStatus('BOARDING')} disabled={act.busy}>Start boarding</button>}
        {['SCHEDULED', 'BOARDING', 'DELAYED'].includes(s) && <button type="button" className="btn" onClick={() => setStatus('IN_TRANSIT')} disabled={act.busy}>Depart</button>}
        {['SCHEDULED', 'BOARDING'].includes(s) && <button type="button" className="btn" onClick={() => setStatus('DELAYED')} disabled={act.busy}>Mark delayed</button>}
        {['BOARDING', 'IN_TRANSIT', 'DELAYED'].includes(s) && <button type="button" className="btn btn-primary" onClick={complete} disabled={act.busy}>Complete trip</button>}
        {['SCHEDULED', 'DELAYED'].includes(s) && <button type="button" className="btn btn-danger" onClick={() => setStatus('CANCELLED')} disabled={act.busy}>Cancel trip</button>}
        {['COMPLETED', 'CANCELLED'].includes(s) && <span className="muted">This trip is closed.</span>}
      </div>
    </section>
  );
}

export default function TripDetail() {
  const { id } = useParams();
  const { data: trip, error, loading, reload } = useLoad(() => api(`/trips/${id}`), [id]);
  const bookable = useMemo(() => trip && ['SCHEDULED', 'BOARDING', 'DELAYED'].includes(trip.status) && new Date(trip.scheduledDeparture) > new Date(), [trip]);
  const colour = routeColour(trip?.routeCode);

  return (
    <Loader loading={loading} error={error} onRetry={reload}>
      {trip && (
        <>
          <PageHeader title={<><RouteBullet code={trip.routeCode} /> {trip.routeName}</>} lead={`Trip ${trip.tripId}, departing ${dateTime(trip.scheduledDeparture)}`}>
            <Status value={trip.status} />
          </PageHeader>
          <div className="grid-2">
            <section className="section">
              <h2>Stops</h2>
              <ol className="route-line" style={{ '--c': colour }}>
                {trip.stops.map((s, i) => (
                  <li key={s.stopId} className={i === 0 || i === trip.stops.length - 1 ? 'rl-terminal' : ''}>
                    <span className="rl-dot" /><span>{s.stopName}</span>
                    <span className="rl-meta">{time(new Date(new Date(trip.scheduledDeparture).getTime() + s.offsetMin * 60000))}&emsp;{money(s.fareFromOrigin)}</span>
                  </li>
                ))}
              </ol>
            </section>
            <section className="section">
              <h2>Trip details</h2>
              <dl className="details">
                <dt>Vehicle</dt><dd>{trip.regNo} {trip.makeModel}</dd>
                <dt>Driver</dt><dd>{trip.driverName}</dd>
                <dt>Seats left</dt><dd>{trip.seatsAvailable} of {trip.seatCapacity}</dd>
                <dt>Departed</dt><dd>{dateTime(trip.actualDeparture)}</dd>
                <dt>Arrived</dt><dd>{dateTime(trip.actualArrival)}</dd>
                <dt>Full fare</dt><dd>{money(trip.baseFare)}</dd>
              </dl>
            </section>
          </div>
          {bookable && <BookingForm trip={trip} onBooked={reload} />}
          <TripActions trip={trip} onChange={reload} />
          <section className="section">
            <div className="section-head"><h2>Bookings on this trip</h2><span className="muted">{trip.bookings.length} total</span></div>
            {trip.bookings.length === 0 ? <Empty>No bookings yet.</Empty> : (
              <div className="table-wrap">
                <table>
                  <thead><tr><th>Reference</th><th>Passenger</th><th>From</th><th>To</th><th className="num">Seats</th><th className="num">Amount</th><th>Status</th></tr></thead>
                  <tbody>
                    {trip.bookings.map((b) => (
                      <tr key={b.bookingId}>
                        <td><Link to={`/bookings/${b.bookingId}`}>{b.bookingRef}</Link></td>
                        <td>{b.passengerName}</td><td>{b.boardStop}</td><td>{b.dropStop}</td>
                        <td className="num">{b.seatCount}</td><td className="num">{money(b.totalAmount)}</td>
                        <td><Status value={b.status} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        </>
      )}
    </Loader>
  );
}
