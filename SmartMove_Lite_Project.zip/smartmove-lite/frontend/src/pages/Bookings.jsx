import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, qs } from '../api.js';
import { useLoad } from '../hooks.js';
import { Empty, Field, Loader, PageHeader, RouteBullet, Status } from '../components/ui.jsx';
import { dateTime, money } from '../format.js';

export default function Bookings() {
  const [ref, setRef] = useState('');
  const [status, setStatus] = useState('');
  const navigate = useNavigate();
  const list = useLoad(() => api(`/bookings${qs({ status })}`), [status]);
  const find = (e) => { e.preventDefault(); if (ref.trim()) navigate(`/bookings/${ref.trim()}`); };

  return (
    <>
      <PageHeader title="Bookings" lead="Look up a booking to take payment or cancel it." />
      <form className="section filters" onSubmit={find}>
        <Field label="Booking reference or number"><input value={ref} onChange={(e) => setRef(e.target.value)} placeholder="SM00001234" /></Field>
        <button className="btn btn-primary">Find booking</button>
      </form>
      <section className="section">
        <div className="section-head">
          <h2>Latest 100 bookings</h2>
          <Field label="Status">
            <select value={status} onChange={(e) => setStatus(e.target.value)}>
              <option value="">Any</option>
              {['PENDING', 'CONFIRMED', 'COMPLETED', 'CANCELLED', 'NO_SHOW'].map((s) => <option key={s} value={s}>{s.replace('_', ' ').toLowerCase()}</option>)}
            </select>
          </Field>
        </div>
        <Loader loading={list.loading} error={list.error} onRetry={list.reload}>
          {list.data && list.data.length === 0 && <Empty>No bookings with this status.</Empty>}
          {list.data && list.data.length > 0 && (
            <div className="table-wrap">
              <table>
                <thead><tr><th>Reference</th><th>Passenger</th><th>Route</th><th>Departs</th><th className="num">Seats</th><th className="num">Amount</th><th>Status</th></tr></thead>
                <tbody>
                  {list.data.map((b) => (
                    <tr key={b.bookingId} className="clickable" onClick={() => navigate(`/bookings/${b.bookingId}`)}>
                      <td>{b.bookingRef}</td><td>{b.passengerName}</td><td><RouteBullet code={b.routeCode} /></td>
                      <td>{dateTime(b.scheduledDeparture)}</td><td className="num">{b.seatCount}</td>
                      <td className="num">{money(b.totalAmount)}</td><td><Status value={b.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Loader>
      </section>
    </>
  );
}
