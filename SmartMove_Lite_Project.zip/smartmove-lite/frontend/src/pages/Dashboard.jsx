import { Link, useNavigate } from 'react-router-dom';
import { Bar, BarChart, CartesianGrid, Cell, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { api } from '../api.js';
import { useLoad } from '../hooks.js';
import { Empty, Loader, PageHeader, RouteBullet, Stat, Status, routeColour } from '../components/ui.jsx';
import { money, moneyShort, number, pct, time, date } from '../format.js';

export default function Dashboard() {
  const { data, error, loading, reload } = useLoad(() => api('/dashboard'));
  const navigate = useNavigate();
  const t = data?.tripsToday || {};
  const tripsToday = Object.values(t).reduce((a, b) => a + b, 0);

  return (
    <>
      <PageHeader title="Today on the network" lead={data ? `Figures for the last 30 days (${date(data.period.from)} to ${date(data.period.to)}) unless marked today.` : null}>
        <Link to="/trips" className="btn btn-primary">Book a seat</Link>
      </PageHeader>
      <Loader loading={loading} error={error} onRetry={reload}>
        {data && (
          <>
            <div className="stats">
              <Stat label="Trips today" value={number(tripsToday)} sub={`${number(t.IN_TRANSIT || 0)} in transit, ${number(t.SCHEDULED || 0)} to depart`} />
              <Stat label="Paid bookings" value={number(data.bookings30d?.bookings)} sub={`${number(data.bookings30d?.seats)} seats`} />
              <Stat label="Net ticket revenue" value={moneyShort(data.revenue30d)} sub={money(data.revenue30d)} />
              <Stat label="Vehicles in service" value={number(data.fleet?.ACTIVE || 0)} sub={`${number(data.fleet?.UNDER_REPAIR || 0)} under repair`} />
              <Stat label="Due for maintenance" value={number(data.maintenanceDue)} sub={<Link to="/reports">See report 4</Link>} />
            </div>

            <div className="grid-2">
              <section className="section">
                <div className="section-head"><h2>Next departures</h2><Link to="/trips">All trips</Link></div>
                {data.upcoming.length === 0 ? <Empty>No departures scheduled.</Empty> : (
                  <div className="table-wrap">
                    <table className="board">
                      <thead><tr><th>Departs</th><th>Route</th><th>Vehicle</th><th className="num">Seats left</th></tr></thead>
                      <tbody>
                        {data.upcoming.map((u) => (
                          <tr key={u.tripId} className="clickable" onClick={() => navigate(`/trips/${u.tripId}`)}>
                            <td><span className="time">{time(u.scheduledDeparture)}</span><br /><span className="muted">{date(u.scheduledDeparture)}</span></td>
                            <td><RouteBullet code={u.routeCode} /> <span className="muted">{u.routeName}</span></td>
                            <td className="nowrap">{u.regNo}</td>
                            <td className="num">{u.seatsAvailable} / {u.seatCapacity}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </section>

              <section className="section">
                <div className="section-head"><h2>Busiest routes</h2><Link to="/reports">Reports</Link></div>
                {data.topRoutes.length === 0 ? <Empty>No bookings in this period.</Empty> : (
                  <ResponsiveContainer width="100%" height={260}>
                    <BarChart data={data.topRoutes} layout="vertical" margin={{ left: 10, right: 30 }}>
                      <CartesianGrid horizontal={false} stroke="#E7EBF1" />
                      <XAxis type="number" tick={{ fontSize: 13 }} />
                      <YAxis type="category" dataKey="routeCode" width={60} tick={{ fontSize: 14, fontWeight: 600 }} />
                      <Tooltip formatter={(v, n, p) => [`${number(v)} bookings, load ${pct(p.payload.loadFactorPct)}`, p.payload.routeName]} />
                      <Bar dataKey="bookings" radius={[0, 4, 4, 0]}>
                        {data.topRoutes.map((r) => <Cell key={r.routeCode} fill={routeColour(r.routeCode)} />)}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </section>
            </div>

            <section className="section">
              <div className="section-head"><h2>Net revenue per day</h2><span className="muted">Payments less refunds, LKR</span></div>
              {data.dailyRevenue.length === 0 ? <Empty>No payments in the last 30 days.</Empty> : (
                <ResponsiveContainer width="100%" height={240}>
                  <LineChart data={data.dailyRevenue} margin={{ left: 10, right: 20 }}>
                    <CartesianGrid stroke="#E7EBF1" vertical={false} />
                    <XAxis dataKey="day" tickFormatter={(d) => d.slice(5)} tick={{ fontSize: 13 }} minTickGap={20} />
                    <YAxis tickFormatter={(v) => `${Math.round(v / 1000)}k`} tick={{ fontSize: 13 }} width={48} />
                    <Tooltip formatter={(v) => money(v)} labelFormatter={(d) => date(d)} />
                    <Line type="monotone" dataKey="net" stroke="#15233B" strokeWidth={2.5} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </section>

            {t.DELAYED > 0 && <p><Status value="DELAYED" /> {t.DELAYED} trip(s) are running late today.</p>}
          </>
        )}
      </Loader>
    </>
  );
}
