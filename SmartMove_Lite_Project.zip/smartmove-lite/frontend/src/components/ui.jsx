import { Link } from 'react-router-dom';
import { titleCase } from '../format.js';

// Each route owns a line colour, like a transit map.
export const ROUTE_COLOURS = {
  'R-101': '#2F5AA8', 'R-102': '#0F8B7E', 'R-103': '#B8860B',
  'R-104': '#6B4FB8', 'R-105': '#C2413B', 'R-106': '#3E8E41',
};
export const routeColour = (code) => ROUTE_COLOURS[code] || '#15233B';

export function RouteBullet({ code, to }) {
  const el = <span className="route-bullet" style={{ '--c': routeColour(code) }}>{code || '–'}</span>;
  return to ? <Link to={to} className="plain">{el}</Link> : el;
}

const STATUS_TONE = {
  ACTIVE: 'good', AVAILABLE: 'good', CONFIRMED: 'good', COMPLETED: 'good', SUCCESS: 'good', VALID: 'good', USED: 'muted',
  SCHEDULED: 'info', BOARDING: 'info', IN_TRANSIT: 'info', PENDING: 'warn', DELAYED: 'warn', IN_PROGRESS: 'warn',
  ON_TRIP: 'info', DUE_SOON: 'warn', INSURANCE: 'warn', UNDER_REPAIR: 'bad', OVERDUE: 'bad', CANCELLED: 'bad',
  NO_SHOW: 'bad', SUSPENDED: 'bad', REFUNDED: 'muted', EXPIRED: 'muted', RETIRED: 'muted', ON_LEAVE: 'muted',
  EXCELLENT: 'good', GOOD: 'good', FAIR: 'warn', 'NEEDS REVIEW': 'bad',
};
export function Status({ value }) {
  if (!value) return <span className="muted">–</span>;
  return <span className={`status tone-${STATUS_TONE[value] || 'muted'}`}>{titleCase(value)}</span>;
}

export function PageHeader({ title, lead, children }) {
  return (
    <header className="page-header">
      <div>
        <h1>{title}</h1>
        {lead && <p className="lead">{lead}</p>}
      </div>
      {children && <div className="page-actions">{children}</div>}
    </header>
  );
}

export function Notice({ error, message, onClose }) {
  if (!error && !message) return null;
  return (
    <div className={`notice ${error ? 'notice-error' : 'notice-ok'}`} role={error ? 'alert' : 'status'}>
      <span>{error ? (error.message || String(error)) : message}</span>
      {error && error.code && <span className="notice-code">{error.code}</span>}
      {onClose && <button type="button" className="notice-close" onClick={onClose} aria-label="Dismiss">×</button>}
    </div>
  );
}

export function Loader({ loading, error, children, onRetry }) {
  if (loading) return <p className="state">Loading…</p>;
  if (error) {
    return (
      <div className="state state-error">
        <p>{error.message}</p>
        {onRetry && <button type="button" className="btn" onClick={onRetry}>Try again</button>}
      </div>
    );
  }
  return children;
}

export function Empty({ children }) {
  return <p className="state">{children}</p>;
}

export function Field({ label, hint, children }) {
  return (
    <label className="field">
      <span className="field-label">{label}</span>
      {children}
      {hint && <span className="field-hint">{hint}</span>}
    </label>
  );
}

export function Stat({ label, value, sub }) {
  return (
    <div className="stat">
      <span className="stat-value">{value}</span>
      <span className="stat-label">{label}</span>
      {sub && <span className="stat-sub">{sub}</span>}
    </div>
  );
}

export function Tabs({ tabs, active, onChange }) {
  return (
    <div className="tabs" role="tablist">
      {tabs.map((t) => (
        <button key={t.id} type="button" role="tab" aria-selected={active === t.id}
          className={`tab ${active === t.id ? 'tab-active' : ''}`} onClick={() => onChange(t.id)}>
          {t.label}
        </button>
      ))}
    </div>
  );
}
