import { useEffect, useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { api } from '../api.js';

const STOPS = [
  { to: '/', label: 'Dashboard', end: true },
  { to: '/trips', label: 'Trips and booking' },
  { to: '/bookings', label: 'Bookings and payment' },
  { to: '/reports', label: 'Reports' },
  { to: '/tracking', label: 'GPS tracking (Mongo)' },
  { to: '/feedback', label: 'Feedback (Mongo)' },
];

function Health() {
  const [h, setH] = useState(null);
  useEffect(() => {
    let alive = true;
    const check = () => api('/health').then((d) => alive && setH(d)).catch(() => alive && setH({ api: 'down' }));
    check();
    const id = setInterval(check, 30000);
    return () => { alive = false; clearInterval(id); };
  }, []);
  const dot = (ok) => <span className={`dot ${ok ? 'dot-ok' : 'dot-bad'}`} aria-hidden="true" />;
  if (!h) return null;
  return (
    <div className="health" title={[h.oracle?.error, h.mongo?.error].filter(Boolean).join('\n')}>
      <span>{dot(h.api === 'ok')}API</span>
      <span>{dot(h.oracle?.connected)}Oracle</span>
      <span>{dot(h.mongo?.connected)}MongoDB</span>
    </div>
  );
}

export default function Layout() {
  const [open, setOpen] = useState(false);
  return (
    <div className="shell">
      <aside className={`sidebar ${open ? 'sidebar-open' : ''}`}>
        <div className="brand">
          <span className="brand-mark">SM</span>
          <span className="brand-name">SmartMove<small>Lite</small></span>
          <button type="button" className="menu-toggle" onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-label="Menu">
            {open ? '×' : '≡'}
          </button>
        </div>
        <nav className="line-nav" aria-label="Main">
          <ol>
            {STOPS.map((s) => (
              <li key={s.to}>
                <NavLink to={s.to} end={s.end} onClick={() => setOpen(false)}
                  className={({ isActive }) => `stop ${isActive ? 'stop-active' : ''}`}>
                  <span className="stop-dot" aria-hidden="true" />
                  <span>{s.label}</span>
                </NavLink>
              </li>
            ))}
          </ol>
        </nav>
        <Health />
      </aside>
      <main className="content">
        <Outlet />
      </main>
    </div>
  );
}
