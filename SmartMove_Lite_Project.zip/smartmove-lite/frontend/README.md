# SmartMove Lite: frontend (React)

Five screens plus a MongoDB view: Dashboard, Trips and booking, Bookings and payment,
Reports (all five), GPS tracking and Feedback (the last two read MongoDB).

The backend must be running first (see `../backend/README.md`).

```
cd frontend
npm install
npm run dev
```

Open http://localhost:5173. The dev server forwards every `/api` request to the backend on
port 4000. The coloured dots at the bottom of the sidebar show whether the API, Oracle and
MongoDB are connected.
