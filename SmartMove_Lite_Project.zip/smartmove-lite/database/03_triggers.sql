--------------------------------------------------------------------------------
-- SmartMove Transport Solutions  (LITE)
-- 03_triggers.sql : Four row-level triggers
--
--   trg_booking_keys              BEFORE INSERT  booking   key + reference generation
--   trg_trip_status_change        AFTER UPDATE   trip      odometer + driver status
--   trg_payment_confirms_booking  AFTER INSERT   payment   PENDING -> CONFIRMED
--   trg_maintenance_status        AFTER INS/UPD  maintenance  vehicle status + next service
--
-- Run order : 01_schema -> 02_sample_data -> 03_triggers -> 04_smartmove_pkg
-- Triggers are created AFTER the sample data so the data loads untouched.
--------------------------------------------------------------------------------

-- T4 : Booking key and reference generation
--
-- Lets the application (and smartmove_pkg.create_booking) insert a booking
-- without knowing its key in advance. Replaces the provisional-value-then-
-- UPDATE workaround used inside the sample data generator.
--------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER trg_booking_keys
BEFORE INSERT ON booking
FOR EACH ROW
BEGIN
    IF :NEW.booking_id IS NULL THEN
        :NEW.booking_id := seq_booking.NEXTVAL;
    END IF;

    IF :NEW.booking_ref IS NULL THEN
        :NEW.booking_ref := 'SM' || LPAD(:NEW.booking_id, 8, '0');
    END IF;

    :NEW.booked_at := NVL(:NEW.booked_at, SYSTIMESTAMP);
END trg_booking_keys;
/



-- T6 : Trip lifecycle side effects
--
-- BOARDING / IN_TRANSIT  -> driver marked ON_TRIP
-- COMPLETED              -> vehicle odometer advanced by route distance,
--                           driver released
-- CANCELLED              -> driver released
--
-- The odometer update is what keeps Report 4 (maintenance due) live: every
-- completed trip moves the vehicle closer to its next_due_km.
--------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER trg_trip_status_change
AFTER UPDATE OF status ON trip
FOR EACH ROW
WHEN (NEW.status <> OLD.status)
DECLARE
    v_distance  route.distance_km%TYPE;
BEGIN
    IF :NEW.status IN ('BOARDING', 'IN_TRANSIT') THEN
        UPDATE driver
           SET status = 'ON_TRIP'
         WHERE driver_id = :NEW.driver_id
           AND status = 'AVAILABLE';

    ELSIF :NEW.status = 'COMPLETED' THEN
        SELECT distance_km INTO v_distance FROM route WHERE route_id = :NEW.route_id;

        UPDATE vehicle
           SET odometer_km = odometer_km + ROUND(v_distance)
         WHERE vehicle_id = :NEW.vehicle_id;

        UPDATE driver
           SET status = 'AVAILABLE'
         WHERE driver_id = :NEW.driver_id
           AND status = 'ON_TRIP';

    ELSIF :NEW.status = 'CANCELLED' THEN
        UPDATE driver
           SET status = 'AVAILABLE'
         WHERE driver_id = :NEW.driver_id
           AND status = 'ON_TRIP';
    END IF;
END trg_trip_status_change;
/


--------------------------------------------------------------------------------
-- T7 : Successful payment confirms a pending booking
--------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER trg_payment_confirms_booking
AFTER INSERT ON payment
FOR EACH ROW
WHEN (NEW.status = 'SUCCESS')
BEGIN
    UPDATE booking
       SET status = 'CONFIRMED'
     WHERE booking_id = :NEW.booking_id
       AND status = 'PENDING';
END trg_payment_confirms_booking;
/




--------------------------------------------------------------------------------
-- T10 : Maintenance lifecycle keeps the vehicle record in step
--
-- A repair going IN_PROGRESS takes the vehicle out of service.
-- Any job being marked COMPLETED returns it to service and rolls its
-- next_service_due forward. Historical COMPLETED rows inserted directly are
-- ignored (UPDATING check), so back-loading history never rewrites the
-- vehicle's current schedule.
--------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER trg_maintenance_status
AFTER INSERT OR UPDATE OF status ON maintenance
FOR EACH ROW
BEGIN
    IF :NEW.status = 'IN_PROGRESS' AND :NEW.maint_type IN ('REPAIR', 'EMERGENCY') THEN
        UPDATE vehicle
           SET status = 'UNDER_REPAIR'
         WHERE vehicle_id = :NEW.vehicle_id
           AND status = 'ACTIVE';

    ELSIF UPDATING AND :NEW.status = 'COMPLETED' AND :OLD.status <> 'COMPLETED' THEN
        UPDATE vehicle
           SET status           = CASE WHEN status = 'UNDER_REPAIR' THEN 'ACTIVE' ELSE status END,
               next_service_due = NVL(:NEW.next_due_date, :NEW.service_date + 180)
         WHERE vehicle_id = :NEW.vehicle_id;
    END IF;
END trg_maintenance_status;
/


--------------------------------------------------------------------------------
-- Verification
--------------------------------------------------------------------------------
SELECT trigger_name, table_name, triggering_event, status
  FROM user_triggers
 ORDER BY table_name, trigger_name;

SELECT name, type, line, position, text
  FROM user_errors
 WHERE type = 'TRIGGER'
 ORDER BY name, sequence;
