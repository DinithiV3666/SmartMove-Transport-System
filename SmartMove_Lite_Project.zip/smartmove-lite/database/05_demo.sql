--------------------------------------------------------------------------------
-- SmartMove Transport Solutions  (LITE)
-- 05_demo.sql : Demonstration script
--
-- Part A  the five business reports
-- Part B  booking -> payment -> cancel, then trip completion (triggers fire)
-- Part C  business rules rejecting bad input (exception handling)
--
-- Parts B and C are rolled back at the end, so this can be run repeatedly.
-- Output uses DBMS_OUTPUT: in SQL Developer open View > DBMS Output and enable
-- it for your connection; FreeSQL shows it automatically.
--------------------------------------------------------------------------------

-- PART A : Business reports ----------------------------------------------------

BEGIN smartmove_pkg.rpt_top_routes(TRUNC(SYSDATE) - 30, TRUNC(SYSDATE), 5); END;
/

BEGIN smartmove_pkg.rpt_revenue(TRUNC(SYSDATE) - 30, TRUNC(SYSDATE)); END;
/

SELECT TO_CHAR(smartmove_pkg.fn_total_revenue(TRUNC(SYSDATE) - 30, TRUNC(SYSDATE)),
               'FM999,999,999,990.00') AS net_revenue_last_30_days_lkr
  FROM dual;

-- Passenger 2 (Kasun Fernando, corporate)
BEGIN smartmove_pkg.rpt_passenger_history(2, 10); END;
/

BEGIN smartmove_pkg.rpt_maintenance_due(14, 2000); END;
/

BEGIN smartmove_pkg.rpt_driver_performance(TRUNC(SYSDATE) - 30, TRUNC(SYSDATE)); END;
/


-- PART B : Booking lifecycle ---------------------------------------------------

DECLARE
    v_booking_id  booking.booking_id%TYPE;
    v_ref         booking.booking_ref%TYPE;
    v_total       booking.total_amount%TYPE;
    v_payment_id  payment.payment_id%TYPE;
    v_status      booking.status%TYPE;
    v_refund      payment.refund_amount%TYPE;
    v_seats       trip.seats_available%TYPE;
    v_odo_before  vehicle.odometer_km%TYPE;
    v_odo_after   vehicle.odometer_km%TYPE;
    v_done        PLS_INTEGER;
BEGIN
    -- Trip 9 (Colombo -> Galle, 2 days out). Passenger 4 is a senior (25% off).
    SELECT seats_available INTO v_seats FROM trip WHERE trip_id = 9;
    DBMS_OUTPUT.PUT_LINE('B1  Trip 9 has ' || v_seats || ' seats free');

    smartmove_pkg.create_booking(4, 9, 1, 6, 2, 'ONLINE', v_booking_id, v_ref, v_total);
    SELECT seats_available INTO v_seats FROM trip WHERE trip_id = 9;
    DBMS_OUTPUT.PUT_LINE('B2  Created ' || v_ref || ' for LKR ' || v_total ||
                         ' (senior fare); trip now has ' || v_seats || ' seats free');

    smartmove_pkg.record_payment(v_booking_id, 'CARD', v_total,
                                 p_card_brand => 'VISA', p_card_last4 => '4417',
                                 p_gateway => 'PayHere', o_payment_id => v_payment_id);
    SELECT status INTO v_status FROM booking WHERE booking_id = v_booking_id;
    DBMS_OUTPUT.PUT_LINE('B3  Payment ' || v_payment_id || ' recorded; booking is ' || v_status ||
                         '  (trg_payment_confirms_booking)');

    smartmove_pkg.cancel_booking(v_booking_id, v_refund);
    SELECT seats_available INTO v_seats FROM trip WHERE trip_id = 9;
    DBMS_OUTPUT.PUT_LINE('B4  Cancelled: refund LKR ' || v_refund || '; seats back to ' || v_seats);

    -- Trip 7 has one confirmed booking. Boarding then completing it fires
    -- trg_trip_status_change (driver ON_TRIP, then odometer + driver released).
    SELECT odometer_km INTO v_odo_before FROM vehicle WHERE vehicle_id = 3;
    UPDATE trip SET status = 'BOARDING' WHERE trip_id = 7;
    smartmove_pkg.complete_trip(7, v_done);
    SELECT odometer_km INTO v_odo_after FROM vehicle WHERE vehicle_id = 3;
    DBMS_OUTPUT.PUT_LINE('B5  Trip 7 completed, ' || v_done || ' passenger seat(s) closed out; odometer ' ||
                         v_odo_before || ' -> ' || v_odo_after || ' km  (trg_trip_status_change)');
END;
/


-- PART C : Business rules rejecting bad input ----------------------------------

DECLARE
    v_id    booking.booking_id%TYPE;
    v_ref   booking.booking_ref%TYPE;
    v_total booking.total_amount%TYPE;
    v_pay   payment.payment_id%TYPE;

    PROCEDURE ok (p_label IN VARCHAR2, p_err IN VARCHAR2) IS
    BEGIN
        DBMS_OUTPUT.PUT_LINE(RPAD(p_label, 26) || 'caught -> ' || p_err);
    END ok;
BEGIN
    -- C1 overbooking: trip 10 is a 4-seat car
    BEGIN
        smartmove_pkg.create_booking(1, 10, 1, 8, 5, 'ONLINE', v_id, v_ref, v_total);
        DBMS_OUTPUT.PUT_LINE('C1 FAILED: overbooking was accepted');
    EXCEPTION WHEN smartmove_pkg.e_insufficient_seats THEN ok('C1 Overbooking', SQLERRM);
    END;

    -- C2 stops in the wrong order (Kandy -> Fort on trip 8)
    BEGIN
        smartmove_pkg.create_booking(1, 8, 4, 1, 1, 'ONLINE', v_id, v_ref, v_total);
        DBMS_OUTPUT.PUT_LINE('C2 FAILED: reversed stops were accepted');
    EXCEPTION WHEN smartmove_pkg.e_invalid_stops THEN ok('C2 Reversed stops', SQLERRM);
    END;

    -- C3 booking a trip that already ran
    BEGIN
        smartmove_pkg.create_booking(1, 1, 1, 4, 1, 'ONLINE', v_id, v_ref, v_total);
        DBMS_OUTPUT.PUT_LINE('C3 FAILED: completed trip was bookable');
    EXCEPTION WHEN smartmove_pkg.e_trip_not_bookable THEN ok('C3 Past trip', SQLERRM);
    END;

    -- C4 unknown passenger
    BEGIN
        smartmove_pkg.create_booking(999, 8, 1, 4, 1, 'ONLINE', v_id, v_ref, v_total);
        DBMS_OUTPUT.PUT_LINE('C4 FAILED: unknown passenger accepted');
    EXCEPTION WHEN smartmove_pkg.e_not_found THEN ok('C4 Unknown passenger', SQLERRM);
    END;

    -- C5 payment that does not match the booking (booking 8 is PENDING, total 500)
    BEGIN
        smartmove_pkg.record_payment(8, 'CASH', 100, o_payment_id => v_pay);
        DBMS_OUTPUT.PUT_LINE('C5 FAILED: short payment accepted');
    EXCEPTION WHEN smartmove_pkg.e_payment_invalid THEN ok('C5 Short payment', SQLERRM);
    END;

    -- C6 cancelling something already cancelled (booking 9)
    BEGIN
        smartmove_pkg.cancel_booking(9, v_total);
        DBMS_OUTPUT.PUT_LINE('C6 FAILED: double cancellation accepted');
    EXCEPTION WHEN smartmove_pkg.e_not_cancellable THEN ok('C6 Double cancellation', SQLERRM);
    END;
END;
/

ROLLBACK;
