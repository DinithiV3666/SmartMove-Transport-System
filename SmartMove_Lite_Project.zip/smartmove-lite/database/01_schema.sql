--------------------------------------------------------------------------------
-- SmartMove Transport Solutions
-- 01_schema.sql : Relational schema (Oracle Database)
--
-- Run order : 01_schema -> 02_sample_data -> 03_triggers -> 04_smartmove_pkg -> 05_demo
-- Tested on : Oracle Database 21c XE / 19c
-- Notes     : Surrogate keys use sequences (portable to 11g). If you are on
--             12c+ you may swap these for GENERATED AS IDENTITY columns.
--------------------------------------------------------------------------------


--------------------------------------------------------------------------------
-- SECTION 0 : Clean slate (safe to re-run)
--------------------------------------------------------------------------------
DECLARE
    TYPE name_list IS TABLE OF VARCHAR2(30);

    v_tables name_list := name_list(
        'feedback', 'cash_payment', 'wallet_payment', 'card_payment', 'payment',
        'ticket', 'booking', 'trip', 'schedule', 'route_stop', 'route',
        'maintenance', 'bus', 'van', 'car', 'vehicle', 'vehicle_type',
        'service_center', 'stop', 'staff', 'driver', 'passenger',
        'corporate_client', 'person'
    );

    v_sequences name_list := name_list(
        'seq_person', 'seq_corporate_client', 'seq_vehicle_type', 'seq_vehicle',
        'seq_service_center', 'seq_stop', 'seq_route', 'seq_route_stop',
        'seq_schedule', 'seq_trip', 'seq_booking', 'seq_ticket', 'seq_payment',
        'seq_maintenance', 'seq_feedback'
    );
BEGIN
    FOR i IN 1 .. v_tables.COUNT LOOP
        BEGIN
            EXECUTE IMMEDIATE 'DROP TABLE ' || v_tables(i) || ' CASCADE CONSTRAINTS PURGE';
        EXCEPTION
            WHEN OTHERS THEN
                IF SQLCODE != -942 THEN RAISE; END IF;   -- -942 = table does not exist
        END;
    END LOOP;

    FOR i IN 1 .. v_sequences.COUNT LOOP
        BEGIN
            EXECUTE IMMEDIATE 'DROP SEQUENCE ' || v_sequences(i);
        EXCEPTION
            WHEN OTHERS THEN
                IF SQLCODE != -2289 THEN RAISE; END IF;  -- -2289 = sequence does not exist
        END;
    END LOOP;
END;
/


-- Free space held by tables dropped in earlier runs (they still count
-- against the schema's storage quota until purged).
PURGE RECYCLEBIN;

--------------------------------------------------------------------------------
-- SECTION 1 : Sequences
--------------------------------------------------------------------------------
CREATE SEQUENCE seq_person           START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_corporate_client START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_vehicle_type     START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_vehicle          START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_service_center   START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_stop             START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_route            START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_route_stop       START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_schedule         START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_trip             START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_booking          START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_ticket           START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_payment          START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_maintenance      START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_feedback         START WITH 1 INCREMENT BY 1 NOCACHE;


--------------------------------------------------------------------------------
-- SECTION 2 : PERSON supertype and its specializations
--
-- EER mapping: table-per-subclass. Each subtype table shares the supertype's
-- primary key and adds only the attributes specific to that role. The
-- person_type discriminator makes the disjoint constraint explicit.
--------------------------------------------------------------------------------
CREATE TABLE person (
    person_id       NUMBER(10)      NOT NULL,
    nic             VARCHAR2(12)    NOT NULL,
    full_name       VARCHAR2(100)   NOT NULL,
    date_of_birth   DATE,
    gender          VARCHAR2(10),
    phone           VARCHAR2(15)    NOT NULL,
    email           VARCHAR2(100),
    address         VARCHAR2(200),
    person_type     VARCHAR2(10)    NOT NULL,
    created_at      TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT pk_person        PRIMARY KEY (person_id),
    CONSTRAINT uk_person_nic    UNIQUE (nic),
    CONSTRAINT ck_person_type   CHECK (person_type IN ('PASSENGER', 'DRIVER', 'STAFF')),
    CONSTRAINT ck_person_gender CHECK (gender IN ('MALE', 'FEMALE', 'OTHER')),
    CONSTRAINT ck_person_email  CHECK (email IS NULL OR email LIKE '%@%.%')
);

CREATE TABLE corporate_client (
    client_id         NUMBER(10)      NOT NULL,
    company_name      VARCHAR2(120)   NOT NULL,
    business_reg_no   VARCHAR2(30)    NOT NULL,
    contact_person    VARCHAR2(100),
    contact_phone     VARCHAR2(15),
    billing_address   VARCHAR2(200),
    discount_pct      NUMBER(4,2)     DEFAULT 0 NOT NULL,
    contract_start    DATE            NOT NULL,
    contract_end      DATE,
    status            VARCHAR2(10)    DEFAULT 'ACTIVE' NOT NULL,
    CONSTRAINT pk_corp_client       PRIMARY KEY (client_id),
    CONSTRAINT uk_corp_reg_no       UNIQUE (business_reg_no),
    CONSTRAINT ck_corp_discount     CHECK (discount_pct BETWEEN 0 AND 50),
    CONSTRAINT ck_corp_status       CHECK (status IN ('ACTIVE', 'SUSPENDED', 'EXPIRED')),
    CONSTRAINT ck_corp_contract     CHECK (contract_end IS NULL OR contract_end > contract_start)
);

CREATE TABLE passenger (
    passenger_id        NUMBER(10)      NOT NULL,
    client_id           NUMBER(10),
    passenger_category  VARCHAR2(15)    DEFAULT 'REGULAR' NOT NULL,
    registered_date     DATE            DEFAULT SYSDATE NOT NULL,
    loyalty_points      NUMBER(8)       DEFAULT 0 NOT NULL,
    status              VARCHAR2(10)    DEFAULT 'ACTIVE' NOT NULL,
    CONSTRAINT pk_passenger         PRIMARY KEY (passenger_id),
    CONSTRAINT fk_passenger_person  FOREIGN KEY (passenger_id) REFERENCES person (person_id),
    CONSTRAINT fk_passenger_client  FOREIGN KEY (client_id)    REFERENCES corporate_client (client_id),
    CONSTRAINT ck_passenger_cat     CHECK (passenger_category IN ('REGULAR', 'CORPORATE', 'STUDENT', 'SENIOR')),
    CONSTRAINT ck_passenger_status  CHECK (status IN ('ACTIVE', 'INACTIVE', 'BLACKLISTED')),
    CONSTRAINT ck_passenger_points  CHECK (loyalty_points >= 0)
);

CREATE TABLE driver (
    driver_id       NUMBER(10)      NOT NULL,
    licence_no      VARCHAR2(20)    NOT NULL,
    licence_class   VARCHAR2(10)    NOT NULL,
    licence_expiry  DATE            NOT NULL,
    hire_date       DATE            NOT NULL,
    years_exp       NUMBER(3)       DEFAULT 0 NOT NULL,
    status          VARCHAR2(12)    DEFAULT 'AVAILABLE' NOT NULL,
    CONSTRAINT pk_driver            PRIMARY KEY (driver_id),
    CONSTRAINT fk_driver_person     FOREIGN KEY (driver_id) REFERENCES person (person_id),
    CONSTRAINT uk_driver_licence    UNIQUE (licence_no),
    CONSTRAINT ck_driver_status     CHECK (status IN ('AVAILABLE', 'ON_TRIP', 'ON_LEAVE', 'SUSPENDED')),
    CONSTRAINT ck_driver_class      CHECK (licence_class IN ('B', 'C', 'CE', 'D', 'DE'))
);

CREATE TABLE staff (
    staff_id        NUMBER(10)      NOT NULL,
    job_role        VARCHAR2(30)    NOT NULL,
    username        VARCHAR2(40)    NOT NULL,
    password_hash   VARCHAR2(200)   NOT NULL,
    status          VARCHAR2(10)    DEFAULT 'ACTIVE' NOT NULL,
    CONSTRAINT pk_staff         PRIMARY KEY (staff_id),
    CONSTRAINT fk_staff_person  FOREIGN KEY (staff_id) REFERENCES person (person_id),
    CONSTRAINT uk_staff_user    UNIQUE (username),
    CONSTRAINT ck_staff_role    CHECK (job_role IN ('ADMIN', 'OPERATIONS', 'FINANCE', 'SUPPORT')),
    CONSTRAINT ck_staff_status  CHECK (status IN ('ACTIVE', 'INACTIVE'))
);


--------------------------------------------------------------------------------
-- SECTION 3 : Vehicle management (VEHICLE supertype + disjoint specializations)
--------------------------------------------------------------------------------
CREATE TABLE vehicle_type (
    type_id           NUMBER(10)    NOT NULL,
    type_name         VARCHAR2(20)  NOT NULL,
    default_capacity  NUMBER(3)     NOT NULL,
    description       VARCHAR2(120),
    CONSTRAINT pk_vehicle_type  PRIMARY KEY (type_id),
    CONSTRAINT uk_vehicle_type  UNIQUE (type_name),
    CONSTRAINT ck_vtype_cap     CHECK (default_capacity > 0)
);

CREATE TABLE vehicle (
    vehicle_id          NUMBER(10)      NOT NULL,
    type_id             NUMBER(10)      NOT NULL,
    reg_no              VARCHAR2(15)    NOT NULL,
    make_model          VARCHAR2(60)    NOT NULL,
    manufacture_year    NUMBER(4)       NOT NULL,
    seat_capacity       NUMBER(3)       NOT NULL,
    fuel_type           VARCHAR2(10)    DEFAULT 'DIESEL' NOT NULL,
    odometer_km         NUMBER(9)       DEFAULT 0 NOT NULL,
    purchase_date       DATE,
    insurance_expiry    DATE,
    next_service_due    DATE,
    status              VARCHAR2(15)    DEFAULT 'ACTIVE' NOT NULL,
    CONSTRAINT pk_vehicle       PRIMARY KEY (vehicle_id),
    CONSTRAINT fk_vehicle_type  FOREIGN KEY (type_id) REFERENCES vehicle_type (type_id),
    CONSTRAINT uk_vehicle_reg   UNIQUE (reg_no),
    CONSTRAINT ck_vehicle_seats CHECK (seat_capacity BETWEEN 1 AND 90),
    CONSTRAINT ck_vehicle_year  CHECK (manufacture_year BETWEEN 1980 AND 2100),
    CONSTRAINT ck_vehicle_odo   CHECK (odometer_km >= 0),
    CONSTRAINT ck_vehicle_fuel  CHECK (fuel_type IN ('DIESEL', 'PETROL', 'HYBRID', 'ELECTRIC')),
    CONSTRAINT ck_vehicle_stat  CHECK (status IN ('ACTIVE', 'UNDER_REPAIR', 'RETIRED', 'RESERVED'))
);

CREATE TABLE bus (
    vehicle_id    NUMBER(10)    NOT NULL,
    deck_type     VARCHAR2(10)  DEFAULT 'SINGLE' NOT NULL,
    door_count    NUMBER(1)     DEFAULT 2 NOT NULL,
    has_ac        CHAR(1)       DEFAULT 'N' NOT NULL,
    has_wifi      CHAR(1)       DEFAULT 'N' NOT NULL,
    CONSTRAINT pk_bus         PRIMARY KEY (vehicle_id),
    CONSTRAINT fk_bus_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicle (vehicle_id) ON DELETE CASCADE,
    CONSTRAINT ck_bus_deck    CHECK (deck_type IN ('SINGLE', 'DOUBLE')),
    CONSTRAINT ck_bus_ac      CHECK (has_ac IN ('Y', 'N')),
    CONSTRAINT ck_bus_wifi    CHECK (has_wifi IN ('Y', 'N'))
);

CREATE TABLE van (
    vehicle_id            NUMBER(10)  NOT NULL,
    luggage_capacity_kg   NUMBER(5)   DEFAULT 0 NOT NULL,
    has_sliding_door      CHAR(1)     DEFAULT 'Y' NOT NULL,
    CONSTRAINT pk_van          PRIMARY KEY (vehicle_id),
    CONSTRAINT fk_van_vehicle  FOREIGN KEY (vehicle_id) REFERENCES vehicle (vehicle_id) ON DELETE CASCADE,
    CONSTRAINT ck_van_door     CHECK (has_sliding_door IN ('Y', 'N'))
);

CREATE TABLE car (
    vehicle_id        NUMBER(10)  NOT NULL,
    is_luxury         CHAR(1)     DEFAULT 'N' NOT NULL,
    boot_capacity_kg  NUMBER(4)   DEFAULT 0 NOT NULL,
    CONSTRAINT pk_car          PRIMARY KEY (vehicle_id),
    CONSTRAINT fk_car_vehicle  FOREIGN KEY (vehicle_id) REFERENCES vehicle (vehicle_id) ON DELETE CASCADE,
    CONSTRAINT ck_car_luxury   CHECK (is_luxury IN ('Y', 'N'))
);


--------------------------------------------------------------------------------
-- SECTION 4 : Route management
--------------------------------------------------------------------------------
CREATE TABLE stop (
    stop_id     NUMBER(10)      NOT NULL,
    stop_name   VARCHAR2(80)    NOT NULL,
    city        VARCHAR2(60)    NOT NULL,
    district    VARCHAR2(60),
    latitude    NUMBER(9,6),
    longitude   NUMBER(9,6),
    is_terminal CHAR(1)         DEFAULT 'N' NOT NULL,
    CONSTRAINT pk_stop       PRIMARY KEY (stop_id),
    CONSTRAINT uk_stop_name  UNIQUE (stop_name, city),
    CONSTRAINT ck_stop_lat   CHECK (latitude  IS NULL OR latitude  BETWEEN  -90 AND  90),
    CONSTRAINT ck_stop_lng   CHECK (longitude IS NULL OR longitude BETWEEN -180 AND 180),
    CONSTRAINT ck_stop_term  CHECK (is_terminal IN ('Y', 'N'))
);

CREATE TABLE route (
    route_id        NUMBER(10)      NOT NULL,
    route_code      VARCHAR2(15)    NOT NULL,
    route_name      VARCHAR2(120)   NOT NULL,
    origin_stop_id  NUMBER(10)      NOT NULL,
    dest_stop_id    NUMBER(10)      NOT NULL,
    distance_km     NUMBER(6,2)     NOT NULL,
    duration_min    NUMBER(5)       NOT NULL,
    base_fare       NUMBER(8,2)     NOT NULL,
    status          VARCHAR2(10)    DEFAULT 'ACTIVE' NOT NULL,
    CONSTRAINT pk_route          PRIMARY KEY (route_id),
    CONSTRAINT uk_route_code     UNIQUE (route_code),
    CONSTRAINT fk_route_origin   FOREIGN KEY (origin_stop_id) REFERENCES stop (stop_id),
    CONSTRAINT fk_route_dest     FOREIGN KEY (dest_stop_id)   REFERENCES stop (stop_id),
    CONSTRAINT ck_route_endpts   CHECK (origin_stop_id <> dest_stop_id),
    CONSTRAINT ck_route_dist     CHECK (distance_km > 0),
    CONSTRAINT ck_route_dur      CHECK (duration_min > 0),
    CONSTRAINT ck_route_fare     CHECK (base_fare >= 0),
    CONSTRAINT ck_route_status   CHECK (status IN ('ACTIVE', 'SUSPENDED', 'ARCHIVED'))
);

-- Associative entity resolving the M:N between ROUTE and STOP.
-- fare_from_origin is what makes partial-journey pricing possible.
CREATE TABLE route_stop (
    route_stop_id     NUMBER(10)    NOT NULL,
    route_id          NUMBER(10)    NOT NULL,
    stop_id           NUMBER(10)    NOT NULL,
    stop_seq          NUMBER(3)     NOT NULL,
    offset_min        NUMBER(5)     NOT NULL,
    fare_from_origin  NUMBER(8,2)   NOT NULL,
    CONSTRAINT pk_route_stop        PRIMARY KEY (route_stop_id),
    CONSTRAINT fk_rs_route          FOREIGN KEY (route_id) REFERENCES route (route_id) ON DELETE CASCADE,
    CONSTRAINT fk_rs_stop           FOREIGN KEY (stop_id)  REFERENCES stop (stop_id),
    CONSTRAINT uk_rs_route_seq      UNIQUE (route_id, stop_seq),
    CONSTRAINT uk_rs_route_stop     UNIQUE (route_id, stop_id),
    CONSTRAINT ck_rs_seq            CHECK (stop_seq > 0),
    CONSTRAINT ck_rs_offset         CHECK (offset_min >= 0),
    CONSTRAINT ck_rs_fare           CHECK (fare_from_origin >= 0)
);


--------------------------------------------------------------------------------
-- SECTION 5 : Trip scheduling
--
-- SCHEDULE is the recurring timetable template.
-- TRIP is one dated instance of a schedule, with an actual vehicle and driver.
--------------------------------------------------------------------------------
CREATE TABLE schedule (
    schedule_id     NUMBER(10)    NOT NULL,
    route_id        NUMBER(10)    NOT NULL,
    departure_time  VARCHAR2(5)   NOT NULL,   -- 'HH24:MI'
    days_of_week    VARCHAR2(7)   NOT NULL,   -- 'YYYYYNN' = Mon..Sun
    effective_from  DATE          DEFAULT SYSDATE NOT NULL,
    effective_to    DATE,
    is_active       CHAR(1)       DEFAULT 'Y' NOT NULL,
    CONSTRAINT pk_schedule       PRIMARY KEY (schedule_id),
    CONSTRAINT fk_schedule_route FOREIGN KEY (route_id) REFERENCES route (route_id),
    CONSTRAINT uk_schedule       UNIQUE (route_id, departure_time, effective_from),
    CONSTRAINT ck_sched_time     CHECK (REGEXP_LIKE(departure_time, '^([01][0-9]|2[0-3]):[0-5][0-9]$')),
    CONSTRAINT ck_sched_days     CHECK (REGEXP_LIKE(days_of_week, '^[YN]{7}$')),
    CONSTRAINT ck_sched_active   CHECK (is_active IN ('Y', 'N')),
    CONSTRAINT ck_sched_dates    CHECK (effective_to IS NULL OR effective_to >= effective_from)
);

CREATE TABLE trip (
    trip_id             NUMBER(10)    NOT NULL,
    schedule_id         NUMBER(10),
    route_id            NUMBER(10)    NOT NULL,
    vehicle_id          NUMBER(10)    NOT NULL,
    driver_id           NUMBER(10)    NOT NULL,
    trip_date           DATE          NOT NULL,
    scheduled_departure TIMESTAMP     NOT NULL,
    actual_departure    TIMESTAMP,
    actual_arrival      TIMESTAMP,
    seats_available     NUMBER(3)     NOT NULL,
    status              VARCHAR2(12)  DEFAULT 'SCHEDULED' NOT NULL,
    CONSTRAINT pk_trip           PRIMARY KEY (trip_id),
    CONSTRAINT fk_trip_schedule  FOREIGN KEY (schedule_id) REFERENCES schedule (schedule_id),
    CONSTRAINT fk_trip_route     FOREIGN KEY (route_id)    REFERENCES route (route_id),
    CONSTRAINT fk_trip_vehicle   FOREIGN KEY (vehicle_id)  REFERENCES vehicle (vehicle_id),
    CONSTRAINT fk_trip_driver    FOREIGN KEY (driver_id)   REFERENCES driver (driver_id),
    CONSTRAINT uk_trip_vehicle   UNIQUE (vehicle_id, scheduled_departure),
    CONSTRAINT uk_trip_driver    UNIQUE (driver_id, scheduled_departure),
    CONSTRAINT ck_trip_seats     CHECK (seats_available >= 0),
    CONSTRAINT ck_trip_status    CHECK (status IN ('SCHEDULED', 'BOARDING', 'IN_TRANSIT', 'COMPLETED', 'CANCELLED', 'DELAYED')),
    CONSTRAINT ck_trip_times     CHECK (actual_arrival IS NULL OR actual_departure IS NULL OR actual_arrival >= actual_departure)
);


--------------------------------------------------------------------------------
-- SECTION 6 : Booking and ticketing
--------------------------------------------------------------------------------
CREATE TABLE booking (
    booking_id      NUMBER(10)      NOT NULL,
    booking_ref     VARCHAR2(15)    NOT NULL,
    passenger_id    NUMBER(10)      NOT NULL,
    trip_id         NUMBER(10)      NOT NULL,
    board_stop_id   NUMBER(10)      NOT NULL,
    drop_stop_id    NUMBER(10)      NOT NULL,
    booked_at       TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL,
    seat_count      NUMBER(2)       NOT NULL,
    total_amount    NUMBER(10,2)    NOT NULL,
    booking_channel VARCHAR2(10)    DEFAULT 'ONLINE' NOT NULL,
    status          VARCHAR2(12)    DEFAULT 'PENDING' NOT NULL,
    cancelled_at    TIMESTAMP,
    CONSTRAINT pk_booking          PRIMARY KEY (booking_id),
    CONSTRAINT uk_booking_ref      UNIQUE (booking_ref),
    CONSTRAINT fk_booking_pax      FOREIGN KEY (passenger_id)  REFERENCES passenger (passenger_id),
    CONSTRAINT fk_booking_trip     FOREIGN KEY (trip_id)       REFERENCES trip (trip_id),
    CONSTRAINT fk_booking_board    FOREIGN KEY (board_stop_id) REFERENCES stop (stop_id),
    CONSTRAINT fk_booking_drop     FOREIGN KEY (drop_stop_id)  REFERENCES stop (stop_id),
    CONSTRAINT ck_booking_stops    CHECK (board_stop_id <> drop_stop_id),
    CONSTRAINT ck_booking_seats    CHECK (seat_count BETWEEN 1 AND 10),
    CONSTRAINT ck_booking_amt      CHECK (total_amount >= 0),
    CONSTRAINT ck_booking_channel  CHECK (booking_channel IN ('ONLINE', 'MOBILE', 'COUNTER', 'AGENT')),
    CONSTRAINT ck_booking_status   CHECK (status IN ('PENDING', 'CONFIRMED', 'CANCELLED', 'COMPLETED', 'NO_SHOW'))
);

CREATE TABLE ticket (
    ticket_id       NUMBER(10)      NOT NULL,
    booking_id      NUMBER(10)      NOT NULL,
    seat_no         VARCHAR2(5)     NOT NULL,
    passenger_name  VARCHAR2(100)   NOT NULL,
    fare            NUMBER(8,2)     NOT NULL,
    qr_code         VARCHAR2(60)    NOT NULL,
    issued_at       TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL,
    status          VARCHAR2(10)    DEFAULT 'VALID' NOT NULL,
    CONSTRAINT pk_ticket         PRIMARY KEY (ticket_id),
    CONSTRAINT fk_ticket_booking FOREIGN KEY (booking_id) REFERENCES booking (booking_id) ON DELETE CASCADE,
    CONSTRAINT uk_ticket_qr      UNIQUE (qr_code),
    CONSTRAINT uk_ticket_seat    UNIQUE (booking_id, seat_no),
    CONSTRAINT ck_ticket_fare    CHECK (fare >= 0),
    CONSTRAINT ck_ticket_status  CHECK (status IN ('VALID', 'USED', 'CANCELLED', 'EXPIRED'))
);


--------------------------------------------------------------------------------
-- SECTION 7 : Payment (supertype + disjoint specializations)
--------------------------------------------------------------------------------
CREATE TABLE payment (
    payment_id    NUMBER(10)      NOT NULL,
    booking_id    NUMBER(10)      NOT NULL,
    amount        NUMBER(10,2)    NOT NULL,
    method        VARCHAR2(10)    NOT NULL,
    txn_ref       VARCHAR2(50),
    paid_at       TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL,
    status        VARCHAR2(10)    DEFAULT 'PENDING' NOT NULL,
    refund_amount NUMBER(10,2)    DEFAULT 0 NOT NULL,
    CONSTRAINT pk_payment          PRIMARY KEY (payment_id),
    CONSTRAINT fk_payment_booking  FOREIGN KEY (booking_id) REFERENCES booking (booking_id),
    CONSTRAINT uk_payment_txn      UNIQUE (txn_ref),
    CONSTRAINT ck_payment_amt      CHECK (amount > 0),
    CONSTRAINT ck_payment_method   CHECK (method IN ('CARD', 'CASH', 'WALLET')),
    CONSTRAINT ck_payment_status   CHECK (status IN ('PENDING', 'SUCCESS', 'FAILED', 'REFUNDED')),
    CONSTRAINT ck_payment_refund   CHECK (refund_amount >= 0 AND refund_amount <= amount)
);

CREATE TABLE card_payment (
    payment_id  NUMBER(10)    NOT NULL,
    card_brand  VARCHAR2(20)  NOT NULL,
    card_last4  CHAR(4)       NOT NULL,
    auth_code   VARCHAR2(20),
    gateway     VARCHAR2(30),
    CONSTRAINT pk_card_payment  PRIMARY KEY (payment_id),
    CONSTRAINT fk_card_payment  FOREIGN KEY (payment_id) REFERENCES payment (payment_id) ON DELETE CASCADE,
    CONSTRAINT ck_card_brand    CHECK (card_brand IN ('VISA', 'MASTERCARD', 'AMEX')),
    CONSTRAINT ck_card_last4    CHECK (REGEXP_LIKE(card_last4, '^[0-9]{4}$'))
);

CREATE TABLE wallet_payment (
    payment_id      NUMBER(10)    NOT NULL,
    wallet_provider VARCHAR2(30)  NOT NULL,
    wallet_ref      VARCHAR2(50),
    CONSTRAINT pk_wallet_payment  PRIMARY KEY (payment_id),
    CONSTRAINT fk_wallet_payment  FOREIGN KEY (payment_id) REFERENCES payment (payment_id) ON DELETE CASCADE
);

CREATE TABLE cash_payment (
    payment_id   NUMBER(10)    NOT NULL,
    collected_by NUMBER(10),
    receipt_no   VARCHAR2(20),
    CONSTRAINT pk_cash_payment  PRIMARY KEY (payment_id),
    CONSTRAINT fk_cash_payment  FOREIGN KEY (payment_id)   REFERENCES payment (payment_id) ON DELETE CASCADE,
    CONSTRAINT fk_cash_driver   FOREIGN KEY (collected_by) REFERENCES driver (driver_id)
);


--------------------------------------------------------------------------------
-- SECTION 8 : Maintenance management
--------------------------------------------------------------------------------
CREATE TABLE service_center (
    centre_id     NUMBER(10)      NOT NULL,
    centre_name   VARCHAR2(100)   NOT NULL,
    city          VARCHAR2(60)    NOT NULL,
    address       VARCHAR2(200),
    contact_no    VARCHAR2(15),
    is_authorized CHAR(1)         DEFAULT 'Y' NOT NULL,
    CONSTRAINT pk_service_centre  PRIMARY KEY (centre_id),
    CONSTRAINT uk_service_centre  UNIQUE (centre_name, city),
    CONSTRAINT ck_sc_authorized   CHECK (is_authorized IN ('Y', 'N'))
);

CREATE TABLE maintenance (
    maint_id            NUMBER(10)    NOT NULL,
    vehicle_id          NUMBER(10)    NOT NULL,
    centre_id           NUMBER(10)    NOT NULL,
    maint_type          VARCHAR2(15)  NOT NULL,
    service_date        DATE          NOT NULL,
    completed_date      DATE,
    odometer_at_service NUMBER(9)     NOT NULL,
    cost                NUMBER(10,2)  DEFAULT 0 NOT NULL,
    next_due_date       DATE,
    next_due_km         NUMBER(9),
    description         VARCHAR2(400),
    status              VARCHAR2(12)  DEFAULT 'SCHEDULED' NOT NULL,
    CONSTRAINT pk_maintenance      PRIMARY KEY (maint_id),
    CONSTRAINT fk_maint_vehicle    FOREIGN KEY (vehicle_id) REFERENCES vehicle (vehicle_id),
    CONSTRAINT fk_maint_centre     FOREIGN KEY (centre_id)  REFERENCES service_center (centre_id),
    CONSTRAINT ck_maint_type       CHECK (maint_type IN ('ROUTINE', 'REPAIR', 'INSPECTION', 'EMERGENCY')),
    CONSTRAINT ck_maint_status     CHECK (status IN ('SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED')),
    CONSTRAINT ck_maint_cost       CHECK (cost >= 0),
    CONSTRAINT ck_maint_odo        CHECK (odometer_at_service >= 0),
    CONSTRAINT ck_maint_dates      CHECK (completed_date IS NULL OR completed_date >= service_date)
);


--------------------------------------------------------------------------------
-- SECTION 9 : Feedback and review
--------------------------------------------------------------------------------
CREATE TABLE feedback (
    feedback_id     NUMBER(10)      NOT NULL,
    passenger_id    NUMBER(10)      NOT NULL,
    trip_id         NUMBER(10)      NOT NULL,
    overall_rating  NUMBER(1)       NOT NULL,
    driver_rating   NUMBER(1),
    vehicle_rating  NUMBER(1),
    punctuality     NUMBER(1),
    comments        VARCHAR2(1000),
    submitted_at    TIMESTAMP       DEFAULT SYSTIMESTAMP NOT NULL,
    response        VARCHAR2(1000),
    responded_at    TIMESTAMP,
    CONSTRAINT pk_feedback        PRIMARY KEY (feedback_id),
    CONSTRAINT fk_feedback_pax    FOREIGN KEY (passenger_id) REFERENCES passenger (passenger_id),
    CONSTRAINT fk_feedback_trip   FOREIGN KEY (trip_id)      REFERENCES trip (trip_id),
    CONSTRAINT uk_feedback        UNIQUE (passenger_id, trip_id),
    CONSTRAINT ck_fb_overall      CHECK (overall_rating  BETWEEN 1 AND 5),
    CONSTRAINT ck_fb_driver       CHECK (driver_rating   IS NULL OR driver_rating   BETWEEN 1 AND 5),
    CONSTRAINT ck_fb_vehicle      CHECK (vehicle_rating  IS NULL OR vehicle_rating  BETWEEN 1 AND 5),
    CONSTRAINT ck_fb_punctuality  CHECK (punctuality     IS NULL OR punctuality     BETWEEN 1 AND 5)
);


--------------------------------------------------------------------------------
-- SECTION 10 : Indexes
--
-- Oracle does NOT auto-index foreign keys. These cover the join and filter
-- columns used by the five business reports and by the booking screens.
--------------------------------------------------------------------------------
CREATE INDEX idx_passenger_client   ON passenger   (client_id);
CREATE INDEX idx_vehicle_type       ON vehicle     (type_id);
CREATE INDEX idx_vehicle_service    ON vehicle     (next_service_due, status);
CREATE INDEX idx_route_origin       ON route       (origin_stop_id);
CREATE INDEX idx_route_dest         ON route       (dest_stop_id);
CREATE INDEX idx_rs_stop            ON route_stop  (stop_id);
CREATE INDEX idx_schedule_route     ON schedule    (route_id, is_active);
CREATE INDEX idx_trip_route_date    ON trip        (route_id, trip_date);
CREATE INDEX idx_trip_vehicle       ON trip        (vehicle_id);
CREATE INDEX idx_trip_driver        ON trip        (driver_id);
CREATE INDEX idx_trip_date_status   ON trip        (trip_date, status);
CREATE INDEX idx_booking_pax        ON booking     (passenger_id, booked_at);
CREATE INDEX idx_booking_trip       ON booking     (trip_id, status);
CREATE INDEX idx_booking_board      ON booking     (board_stop_id);
CREATE INDEX idx_booking_drop       ON booking     (drop_stop_id);
CREATE INDEX idx_payment_booking    ON payment     (booking_id);
CREATE INDEX idx_payment_date       ON payment     (paid_at, status);
CREATE INDEX idx_maint_vehicle      ON maintenance (vehicle_id, service_date);
CREATE INDEX idx_maint_centre       ON maintenance (centre_id);
CREATE INDEX idx_maint_due          ON maintenance (next_due_date, status);
CREATE INDEX idx_feedback_trip      ON feedback    (trip_id);
CREATE INDEX idx_feedback_pax       ON feedback    (passenger_id);
CREATE INDEX idx_cash_driver        ON cash_payment(collected_by);

COMMIT;

