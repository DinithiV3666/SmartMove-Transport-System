--------------------------------------------------------------------------------
-- SmartMove Transport Solutions  (LITE)
-- 02_sample_data.sql : Small hand-written sample data, max 10 rows per table
--
-- Run 01_schema.sql first (it recreates the sequences, so the generated ids
-- below are 1, 2, 3 ... in insert order and the foreign keys line up).
-- Dates are relative to SYSDATE so the reports always have recent data.
--------------------------------------------------------------------------------

-- Reference data -----------------------------------------------------------------
INSERT INTO corporate_client (client_id, company_name, business_reg_no, contact_person, contact_phone, billing_address, discount_pct, contract_start, contract_end, status)
VALUES (seq_corporate_client.NEXTVAL, 'Lanka Tech Solutions', 'PV-10021', 'Mahesh Gunasekara', '0112345678', 'Union Place, Colombo 02', 10, TRUNC(SYSDATE) - 365, TRUNC(SYSDATE) + 365, 'ACTIVE');
INSERT INTO corporate_client (client_id, company_name, business_reg_no, contact_person, contact_phone, billing_address, discount_pct, contract_start, contract_end, status)
VALUES (seq_corporate_client.NEXTVAL, 'Ceylon Traders', 'PV-20458', 'Ishara Dias', '0112876543', 'Sea Street, Colombo 11', 5, TRUNC(SYSDATE) - 200, TRUNC(SYSDATE) + 200, 'ACTIVE');

INSERT INTO vehicle_type (type_id, type_name, default_capacity, description) VALUES (seq_vehicle_type.NEXTVAL, 'BUS', 45, 'Long distance coach');
INSERT INTO vehicle_type (type_id, type_name, default_capacity, description) VALUES (seq_vehicle_type.NEXTVAL, 'VAN', 14, 'Mini van');
INSERT INTO vehicle_type (type_id, type_name, default_capacity, description) VALUES (seq_vehicle_type.NEXTVAL, 'CAR', 4,  'Sedan');

INSERT INTO service_center (centre_id, centre_name, city, address, contact_no, is_authorized) VALUES (seq_service_center.NEXTVAL, 'Lanka Auto Care',        'Colombo', 'Baseline Rd, Colombo 09', '0112111222', 'Y');
INSERT INTO service_center (centre_id, centre_name, city, address, contact_no, is_authorized) VALUES (seq_service_center.NEXTVAL, 'Ceylon Motors Service',  'Kandy',   'Peradeniya Rd, Kandy',   '0812222333', 'Y');
INSERT INTO service_center (centre_id, centre_name, city, address, contact_no, is_authorized) VALUES (seq_service_center.NEXTVAL, 'Galle Fleet Garage',     'Galle',   'Matara Rd, Galle',       '0912333444', 'N');

-- People (ids 1-5 passengers, 6-8 drivers, 9-10 staff) ---------------------------
INSERT INTO person (person_id, nic, full_name, date_of_birth, gender, phone, email, address, person_type) VALUES (seq_person.NEXTVAL, '199045612345', 'Nimali Perera',          DATE '1990-03-14', 'FEMALE', '0771111111', 'nimali@example.com',   'Colombo 05',  'PASSENGER');
INSERT INTO person (person_id, nic, full_name, date_of_birth, gender, phone, email, address, person_type) VALUES (seq_person.NEXTVAL, '198834567890', 'Kasun Fernando',        DATE '1988-07-02', 'MALE',   '0772222222', 'kasun@example.com',    'Nugegoda',    'PASSENGER');
INSERT INTO person (person_id, nic, full_name, date_of_birth, gender, phone, email, address, person_type) VALUES (seq_person.NEXTVAL, '200156789012', 'Dilini Silva',          DATE '2001-11-21', 'FEMALE', '0773333333', 'dilini@example.com',   'Malabe',      'PASSENGER');
INSERT INTO person (person_id, nic, full_name, date_of_birth, gender, phone, email, address, person_type) VALUES (seq_person.NEXTVAL, '195512345V',   'Sunil Jayasinghe',     DATE '1955-01-09', 'MALE',   '0774444444', NULL,                   'Kandy',       'PASSENGER');
INSERT INTO person (person_id, nic, full_name, date_of_birth, gender, phone, email, address, person_type) VALUES (seq_person.NEXTVAL, '199267890123', 'Tharindu Bandara',     DATE '1992-05-30', 'MALE',   '0775555555', 'tharindu@example.com', 'Galle',       'PASSENGER');
INSERT INTO person (person_id, nic, full_name, date_of_birth, gender, phone, email, address, person_type) VALUES (seq_person.NEXTVAL, '198078901234', 'Ruwan Wickramasinghe', DATE '1980-08-18', 'MALE',   '0716666666', NULL,                   'Kadawatha',   'DRIVER');
INSERT INTO person (person_id, nic, full_name, date_of_birth, gender, phone, email, address, person_type) VALUES (seq_person.NEXTVAL, '198589012345', 'Chaminda Rathnayake',  DATE '1985-12-05', 'MALE',   '0717777777', NULL,                   'Panadura',    'DRIVER');
INSERT INTO person (person_id, nic, full_name, date_of_birth, gender, phone, email, address, person_type) VALUES (seq_person.NEXTVAL, '197590123456', 'Lasantha Herath',      DATE '1975-04-27', 'MALE',   '0718888888', NULL,                   'Ja-Ela',      'DRIVER');
INSERT INTO person (person_id, nic, full_name, date_of_birth, gender, phone, email, address, person_type) VALUES (seq_person.NEXTVAL, '198201234567', 'Anoma Gunawardena',    DATE '1982-09-12', 'FEMALE', '0779999999', 'anoma@smartmove.lk',   'Colombo 07',  'STAFF');
INSERT INTO person (person_id, nic, full_name, date_of_birth, gender, phone, email, address, person_type) VALUES (seq_person.NEXTVAL, '199112345678', 'Priyantha Kumara',     DATE '1991-02-23', 'MALE',   '0770000000', 'priyantha@smartmove.lk','Colombo 03', 'STAFF');

INSERT INTO passenger (passenger_id, client_id, passenger_category, registered_date, loyalty_points, status) VALUES (1, NULL, 'REGULAR',   TRUNC(SYSDATE) - 300, 12, 'ACTIVE');
INSERT INTO passenger (passenger_id, client_id, passenger_category, registered_date, loyalty_points, status) VALUES (2, 1,    'CORPORATE', TRUNC(SYSDATE) - 250, 30, 'ACTIVE');
INSERT INTO passenger (passenger_id, client_id, passenger_category, registered_date, loyalty_points, status) VALUES (3, NULL, 'STUDENT',   TRUNC(SYSDATE) - 200, 5,  'ACTIVE');
INSERT INTO passenger (passenger_id, client_id, passenger_category, registered_date, loyalty_points, status) VALUES (4, NULL, 'SENIOR',    TRUNC(SYSDATE) - 150, 8,  'ACTIVE');
INSERT INTO passenger (passenger_id, client_id, passenger_category, registered_date, loyalty_points, status) VALUES (5, NULL, 'REGULAR',   TRUNC(SYSDATE) - 90,  0,  'ACTIVE');

INSERT INTO driver (driver_id, licence_no, licence_class, licence_expiry, hire_date, years_exp, status) VALUES (6, 'B1234567', 'D',  TRUNC(SYSDATE) + 400, TRUNC(SYSDATE) - 2000, 15, 'AVAILABLE');
INSERT INTO driver (driver_id, licence_no, licence_class, licence_expiry, hire_date, years_exp, status) VALUES (7, 'B2345678', 'D',  TRUNC(SYSDATE) + 500, TRUNC(SYSDATE) - 1500, 10, 'AVAILABLE');
INSERT INTO driver (driver_id, licence_no, licence_class, licence_expiry, hire_date, years_exp, status) VALUES (8, 'B3456789', 'DE', TRUNC(SYSDATE) + 300, TRUNC(SYSDATE) - 3000, 20, 'AVAILABLE');

INSERT INTO staff (staff_id, job_role, username, password_hash, status) VALUES (9,  'ADMIN',      'anoma',     'change-me-hash', 'ACTIVE');
INSERT INTO staff (staff_id, job_role, username, password_hash, status) VALUES (10, 'OPERATIONS', 'priyantha', 'change-me-hash', 'ACTIVE');

-- Vehicles -------------------------------------------------------------------------
INSERT INTO vehicle (vehicle_id, type_id, reg_no, make_model, manufacture_year, seat_capacity, fuel_type, odometer_km, purchase_date, insurance_expiry, next_service_due, status)
VALUES (seq_vehicle.NEXTVAL, 1, 'NB-4521',  'Ashok Leyland Viking', 2019, 45, 'DIESEL', 182000, TRUNC(SYSDATE) - 2200, TRUNC(SYSDATE) + 200, TRUNC(SYSDATE) + 60, 'ACTIVE');
INSERT INTO vehicle (vehicle_id, type_id, reg_no, make_model, manufacture_year, seat_capacity, fuel_type, odometer_km, purchase_date, insurance_expiry, next_service_due, status)
VALUES (seq_vehicle.NEXTVAL, 1, 'NC-7788',  'Tata Starbus',         2021, 45, 'DIESEL', 96400,  TRUNC(SYSDATE) - 1300, TRUNC(SYSDATE) + 180, TRUNC(SYSDATE) + 7,  'ACTIVE');
INSERT INTO vehicle (vehicle_id, type_id, reg_no, make_model, manufacture_year, seat_capacity, fuel_type, odometer_km, purchase_date, insurance_expiry, next_service_due, status)
VALUES (seq_vehicle.NEXTVAL, 2, 'KV-3302',  'Toyota HiAce',         2020, 14, 'DIESEL', 121500, TRUNC(SYSDATE) - 1700, TRUNC(SYSDATE) + 150, TRUNC(SYSDATE) - 5,  'ACTIVE');
INSERT INTO vehicle (vehicle_id, type_id, reg_no, make_model, manufacture_year, seat_capacity, fuel_type, odometer_km, purchase_date, insurance_expiry, next_service_due, status)
VALUES (seq_vehicle.NEXTVAL, 2, 'KX-9150',  'Nissan Caravan',       2018, 14, 'DIESEL', 210300, TRUNC(SYSDATE) - 2600, TRUNC(SYSDATE) + 120, TRUNC(SYSDATE) + 30, 'UNDER_REPAIR');
INSERT INTO vehicle (vehicle_id, type_id, reg_no, make_model, manufacture_year, seat_capacity, fuel_type, odometer_km, purchase_date, insurance_expiry, next_service_due, status)
VALUES (seq_vehicle.NEXTVAL, 3, 'CBE-2468', 'Toyota Premio',        2022, 4,  'PETROL', 54200,  TRUNC(SYSDATE) - 900,  TRUNC(SYSDATE) + 10,  TRUNC(SYSDATE) + 90, 'ACTIVE');

INSERT INTO bus (vehicle_id, deck_type, door_count, has_ac, has_wifi) VALUES (1, 'SINGLE', 2, 'Y', 'Y');
INSERT INTO bus (vehicle_id, deck_type, door_count, has_ac, has_wifi) VALUES (2, 'DOUBLE', 2, 'Y', 'N');
INSERT INTO van (vehicle_id, luggage_capacity_kg, has_sliding_door) VALUES (3, 300, 'Y');
INSERT INTO van (vehicle_id, luggage_capacity_kg, has_sliding_door) VALUES (4, 250, 'Y');
INSERT INTO car (vehicle_id, is_luxury, boot_capacity_kg) VALUES (5, 'Y', 400);

-- Stops, routes, route stops --------------------------------------------------------
INSERT INTO stop (stop_id, stop_name, city, district, latitude, longitude, is_terminal) VALUES (seq_stop.NEXTVAL, 'Colombo Fort',        'Colombo',   'Colombo', 6.9335, 79.8500, 'Y');
INSERT INTO stop (stop_id, stop_name, city, district, latitude, longitude, is_terminal) VALUES (seq_stop.NEXTVAL, 'Kadawatha',          'Kadawatha', 'Gampaha', 7.0010, 79.9500, 'N');
INSERT INTO stop (stop_id, stop_name, city, district, latitude, longitude, is_terminal) VALUES (seq_stop.NEXTVAL, 'Kegalle',            'Kegalle',   'Kegalle', 7.2513, 80.3464, 'N');
INSERT INTO stop (stop_id, stop_name, city, district, latitude, longitude, is_terminal) VALUES (seq_stop.NEXTVAL, 'Kandy Bus Stand',    'Kandy',     'Kandy',   7.2906, 80.6337, 'Y');
INSERT INTO stop (stop_id, stop_name, city, district, latitude, longitude, is_terminal) VALUES (seq_stop.NEXTVAL, 'Panadura',           'Panadura',  'Kalutara',6.7133, 79.9026, 'N');
INSERT INTO stop (stop_id, stop_name, city, district, latitude, longitude, is_terminal) VALUES (seq_stop.NEXTVAL, 'Galle Bus Stand',    'Galle',     'Galle',   6.0329, 80.2168, 'Y');
INSERT INTO stop (stop_id, stop_name, city, district, latitude, longitude, is_terminal) VALUES (seq_stop.NEXTVAL, 'Ja-Ela',             'Ja-Ela',    'Gampaha', 7.0744, 79.8919, 'N');
INSERT INTO stop (stop_id, stop_name, city, district, latitude, longitude, is_terminal) VALUES (seq_stop.NEXTVAL, 'Bandaranaike Airport','Katunayake','Gampaha', 7.1808, 79.8841, 'Y');

INSERT INTO route (route_id, route_code, route_name, origin_stop_id, dest_stop_id, distance_km, duration_min, base_fare, status) VALUES (seq_route.NEXTVAL, 'R01', 'Colombo - Kandy Express',  1, 4, 115, 210, 500, 'ACTIVE');
INSERT INTO route (route_id, route_code, route_name, origin_stop_id, dest_stop_id, distance_km, duration_min, base_fare, status) VALUES (seq_route.NEXTVAL, 'R02', 'Colombo - Galle Coastal',  1, 6, 126, 180, 450, 'ACTIVE');
INSERT INTO route (route_id, route_code, route_name, origin_stop_id, dest_stop_id, distance_km, duration_min, base_fare, status) VALUES (seq_route.NEXTVAL, 'R03', 'Colombo - Airport Shuttle',1, 8, 35,  60,  300, 'ACTIVE');

INSERT INTO route_stop VALUES (seq_route_stop.NEXTVAL, 1, 1, 1, 0,   0);
INSERT INTO route_stop VALUES (seq_route_stop.NEXTVAL, 1, 2, 2, 35,  150);
INSERT INTO route_stop VALUES (seq_route_stop.NEXTVAL, 1, 3, 3, 120, 350);
INSERT INTO route_stop VALUES (seq_route_stop.NEXTVAL, 1, 4, 4, 210, 500);
INSERT INTO route_stop VALUES (seq_route_stop.NEXTVAL, 2, 1, 1, 0,   0);
INSERT INTO route_stop VALUES (seq_route_stop.NEXTVAL, 2, 5, 2, 50,  150);
INSERT INTO route_stop VALUES (seq_route_stop.NEXTVAL, 2, 6, 3, 180, 450);
INSERT INTO route_stop VALUES (seq_route_stop.NEXTVAL, 3, 1, 1, 0,   0);
INSERT INTO route_stop VALUES (seq_route_stop.NEXTVAL, 3, 7, 2, 30,  150);
INSERT INTO route_stop VALUES (seq_route_stop.NEXTVAL, 3, 8, 3, 60,  300);

-- Schedules -------------------------------------------------------------------------
INSERT INTO schedule (schedule_id, route_id, departure_time, days_of_week, effective_from, effective_to, is_active) VALUES (seq_schedule.NEXTVAL, 1, '06:30', 'YYYYYYY', TRUNC(SYSDATE) - 200, NULL, 'Y');
INSERT INTO schedule (schedule_id, route_id, departure_time, days_of_week, effective_from, effective_to, is_active) VALUES (seq_schedule.NEXTVAL, 1, '14:00', 'YYYYYYY', TRUNC(SYSDATE) - 200, NULL, 'Y');
INSERT INTO schedule (schedule_id, route_id, departure_time, days_of_week, effective_from, effective_to, is_active) VALUES (seq_schedule.NEXTVAL, 2, '07:00', 'YYYYYYY', TRUNC(SYSDATE) - 200, NULL, 'Y');
INSERT INTO schedule (schedule_id, route_id, departure_time, days_of_week, effective_from, effective_to, is_active) VALUES (seq_schedule.NEXTVAL, 3, '05:30', 'YYYYYYY', TRUNC(SYSDATE) - 200, NULL, 'Y');
INSERT INTO schedule (schedule_id, route_id, departure_time, days_of_week, effective_from, effective_to, is_active) VALUES (seq_schedule.NEXTVAL, 3, '18:00', 'YYYYYNN', TRUNC(SYSDATE) - 200, NULL, 'Y');

-- Trips: 5 completed, 1 cancelled, 4 upcoming ---------------------------------------
-- columns: id, schedule, route, vehicle, driver, date, scheduled, actual dep, actual arr, seats left, status
INSERT INTO trip VALUES (seq_trip.NEXTVAL, 1, 1, 1, 6, TRUNC(SYSDATE) - 6, CAST(TRUNC(SYSDATE) - 6 + (6*60+30)/1440 AS TIMESTAMP), CAST(TRUNC(SYSDATE) - 6 + (6*60+33)/1440 AS TIMESTAMP), CAST(TRUNC(SYSDATE) - 6 + (10*60+5)/1440 AS TIMESTAMP),  43, 'COMPLETED');
INSERT INTO trip VALUES (seq_trip.NEXTVAL, 3, 2, 2, 7, TRUNC(SYSDATE) - 5, CAST(TRUNC(SYSDATE) - 5 + (7*60)/1440 AS TIMESTAMP),    CAST(TRUNC(SYSDATE) - 5 + (7*60+12)/1440 AS TIMESTAMP), CAST(TRUNC(SYSDATE) - 5 + (10*60+15)/1440 AS TIMESTAMP), 44, 'COMPLETED');
INSERT INTO trip VALUES (seq_trip.NEXTVAL, 4, 3, 3, 8, TRUNC(SYSDATE) - 4, CAST(TRUNC(SYSDATE) - 4 + (5*60+30)/1440 AS TIMESTAMP), CAST(TRUNC(SYSDATE) - 4 + (5*60+30)/1440 AS TIMESTAMP), CAST(TRUNC(SYSDATE) - 4 + (6*60+35)/1440 AS TIMESTAMP),  12, 'COMPLETED');
INSERT INTO trip VALUES (seq_trip.NEXTVAL, 2, 1, 1, 6, TRUNC(SYSDATE) - 3, CAST(TRUNC(SYSDATE) - 3 + (14*60)/1440 AS TIMESTAMP),   CAST(TRUNC(SYSDATE) - 3 + (14*60+6)/1440 AS TIMESTAMP), CAST(TRUNC(SYSDATE) - 3 + (17*60+40)/1440 AS TIMESTAMP), 44, 'COMPLETED');
INSERT INTO trip VALUES (seq_trip.NEXTVAL, 3, 2, 2, 7, TRUNC(SYSDATE) - 2, CAST(TRUNC(SYSDATE) - 2 + (7*60)/1440 AS TIMESTAMP),    CAST(TRUNC(SYSDATE) - 2 + (7*60+25)/1440 AS TIMESTAMP), CAST(TRUNC(SYSDATE) - 2 + (10*60+30)/1440 AS TIMESTAMP), 44, 'COMPLETED');
INSERT INTO trip VALUES (seq_trip.NEXTVAL, 1, 1, 1, 8, TRUNC(SYSDATE) - 1, CAST(TRUNC(SYSDATE) - 1 + (6*60+30)/1440 AS TIMESTAMP), NULL, NULL, 45, 'CANCELLED');
INSERT INTO trip VALUES (seq_trip.NEXTVAL, 4, 3, 3, 6, TRUNC(SYSDATE) + 1, CAST(TRUNC(SYSDATE) + 1 + (5*60+30)/1440 AS TIMESTAMP), NULL, NULL, 13, 'SCHEDULED');
INSERT INTO trip VALUES (seq_trip.NEXTVAL, 1, 1, 2, 7, TRUNC(SYSDATE) + 1, CAST(TRUNC(SYSDATE) + 1 + (6*60+30)/1440 AS TIMESTAMP), NULL, NULL, 44, 'SCHEDULED');
INSERT INTO trip VALUES (seq_trip.NEXTVAL, 3, 2, 1, 8, TRUNC(SYSDATE) + 2, CAST(TRUNC(SYSDATE) + 2 + (7*60)/1440 AS TIMESTAMP),    NULL, NULL, 45, 'SCHEDULED');
INSERT INTO trip VALUES (seq_trip.NEXTVAL, 5, 3, 5, 6, TRUNC(SYSDATE) + 2, CAST(TRUNC(SYSDATE) + 2 + (18*60)/1440 AS TIMESTAMP),   NULL, NULL, 4,  'SCHEDULED');

-- Bookings (9): 6 completed, 1 confirmed, 1 pending, 1 cancelled ---------------------
-- columns: id, ref, passenger, trip, board, drop, booked_at, seats, total, channel, status, cancelled_at
INSERT INTO booking VALUES (seq_booking.NEXTVAL, 'SM00000001', 1, 1, 1, 4, SYSTIMESTAMP - INTERVAL '7' DAY, 1, 500, 'ONLINE',  'COMPLETED', NULL);
INSERT INTO booking VALUES (seq_booking.NEXTVAL, 'SM00000002', 2, 1, 1, 3, SYSTIMESTAMP - INTERVAL '7' DAY, 1, 315, 'MOBILE',  'COMPLETED', NULL);
INSERT INTO booking VALUES (seq_booking.NEXTVAL, 'SM00000003', 3, 2, 1, 6, SYSTIMESTAMP - INTERVAL '6' DAY, 1, 360, 'COUNTER', 'COMPLETED', NULL);
INSERT INTO booking VALUES (seq_booking.NEXTVAL, 'SM00000004', 4, 3, 1, 8, SYSTIMESTAMP - INTERVAL '5' DAY, 2, 450, 'ONLINE',  'COMPLETED', NULL);
INSERT INTO booking VALUES (seq_booking.NEXTVAL, 'SM00000005', 5, 4, 2, 4, SYSTIMESTAMP - INTERVAL '4' DAY, 1, 350, 'COUNTER', 'COMPLETED', NULL);
INSERT INTO booking VALUES (seq_booking.NEXTVAL, 'SM00000006', 1, 5, 1, 5, SYSTIMESTAMP - INTERVAL '3' DAY, 1, 150, 'MOBILE',  'COMPLETED', NULL);
INSERT INTO booking VALUES (seq_booking.NEXTVAL, 'SM00000007', 2, 7, 1, 8, SYSTIMESTAMP - INTERVAL '1' DAY, 1, 270, 'ONLINE',  'CONFIRMED', NULL);
INSERT INTO booking VALUES (seq_booking.NEXTVAL, 'SM00000008', 5, 8, 1, 4, SYSTIMESTAMP - INTERVAL '1' DAY, 1, 500, 'ONLINE',  'PENDING',   NULL);
INSERT INTO booking VALUES (seq_booking.NEXTVAL, 'SM00000009', 3, 9, 1, 6, SYSTIMESTAMP - INTERVAL '2' DAY, 1, 360, 'ONLINE',  'CANCELLED', SYSTIMESTAMP - INTERVAL '1' DAY);

-- Tickets (10): columns: id, booking, seat, name, fare, qr, issued_at, status
INSERT INTO ticket VALUES (seq_ticket.NEXTVAL, 1, '1', 'Nimali Perera',      500, 'QR-00000001-1', SYSTIMESTAMP - INTERVAL '7' DAY, 'USED');
INSERT INTO ticket VALUES (seq_ticket.NEXTVAL, 2, '2', 'Kasun Fernando',    315, 'QR-00000002-2', SYSTIMESTAMP - INTERVAL '7' DAY, 'USED');
INSERT INTO ticket VALUES (seq_ticket.NEXTVAL, 3, '1', 'Dilini Silva',      360, 'QR-00000003-1', SYSTIMESTAMP - INTERVAL '6' DAY, 'USED');
INSERT INTO ticket VALUES (seq_ticket.NEXTVAL, 4, '1', 'Sunil Jayasinghe',  225, 'QR-00000004-1', SYSTIMESTAMP - INTERVAL '5' DAY, 'USED');
INSERT INTO ticket VALUES (seq_ticket.NEXTVAL, 4, '2', 'Sunil Jayasinghe',  225, 'QR-00000004-2', SYSTIMESTAMP - INTERVAL '5' DAY, 'USED');
INSERT INTO ticket VALUES (seq_ticket.NEXTVAL, 5, '1', 'Tharindu Bandara',  350, 'QR-00000005-1', SYSTIMESTAMP - INTERVAL '4' DAY, 'USED');
INSERT INTO ticket VALUES (seq_ticket.NEXTVAL, 6, '1', 'Nimali Perera',     150, 'QR-00000006-1', SYSTIMESTAMP - INTERVAL '3' DAY, 'USED');
INSERT INTO ticket VALUES (seq_ticket.NEXTVAL, 7, '1', 'Kasun Fernando',    270, 'QR-00000007-1', SYSTIMESTAMP - INTERVAL '1' DAY, 'VALID');
INSERT INTO ticket VALUES (seq_ticket.NEXTVAL, 8, '1', 'Tharindu Bandara',  500, 'QR-00000008-1', SYSTIMESTAMP - INTERVAL '1' DAY, 'VALID');
INSERT INTO ticket VALUES (seq_ticket.NEXTVAL, 9, '1', 'Dilini Silva',      360, 'QR-00000009-1', SYSTIMESTAMP - INTERVAL '2' DAY, 'CANCELLED');

-- Payments (8) + subtype rows --------------------------------------------------------
-- columns: id, booking, amount, method, txn_ref, paid_at, status, refund
INSERT INTO payment VALUES (seq_payment.NEXTVAL, 1, 500, 'CARD',   'TXN0000000001', SYSTIMESTAMP - INTERVAL '7' DAY, 'SUCCESS',  0);
INSERT INTO payment VALUES (seq_payment.NEXTVAL, 2, 315, 'WALLET', 'TXN0000000002', SYSTIMESTAMP - INTERVAL '7' DAY, 'SUCCESS',  0);
INSERT INTO payment VALUES (seq_payment.NEXTVAL, 3, 360, 'CASH',   'TXN0000000003', SYSTIMESTAMP - INTERVAL '6' DAY, 'SUCCESS',  0);
INSERT INTO payment VALUES (seq_payment.NEXTVAL, 4, 450, 'CARD',   'TXN0000000004', SYSTIMESTAMP - INTERVAL '5' DAY, 'SUCCESS',  0);
INSERT INTO payment VALUES (seq_payment.NEXTVAL, 5, 350, 'CASH',   'TXN0000000005', SYSTIMESTAMP - INTERVAL '4' DAY, 'SUCCESS',  0);
INSERT INTO payment VALUES (seq_payment.NEXTVAL, 6, 150, 'WALLET', 'TXN0000000006', SYSTIMESTAMP - INTERVAL '3' DAY, 'SUCCESS',  0);
INSERT INTO payment VALUES (seq_payment.NEXTVAL, 7, 270, 'CARD',   'TXN0000000007', SYSTIMESTAMP - INTERVAL '1' DAY, 'SUCCESS',  0);
INSERT INTO payment VALUES (seq_payment.NEXTVAL, 9, 360, 'CARD',   'TXN0000000008', SYSTIMESTAMP - INTERVAL '2' DAY, 'REFUNDED', 324);

INSERT INTO card_payment (payment_id, card_brand, card_last4, auth_code, gateway) VALUES (1, 'VISA',       '4417', 'AUTH000001', 'PayHere');
INSERT INTO card_payment (payment_id, card_brand, card_last4, auth_code, gateway) VALUES (4, 'MASTERCARD', '5521', 'AUTH000004', 'PayHere');
INSERT INTO card_payment (payment_id, card_brand, card_last4, auth_code, gateway) VALUES (7, 'VISA',       '9038', 'AUTH000007', 'PayHere');
INSERT INTO card_payment (payment_id, card_brand, card_last4, auth_code, gateway) VALUES (8, 'VISA',       '1122', 'AUTH000008', 'PayHere');
INSERT INTO wallet_payment (payment_id, wallet_provider, wallet_ref) VALUES (2, 'FriMi', 'FM-883201');
INSERT INTO wallet_payment (payment_id, wallet_provider, wallet_ref) VALUES (6, 'Genie', 'GN-120077');
INSERT INTO cash_payment (payment_id, collected_by, receipt_no) VALUES (3, 7, 'RCP00000003');
INSERT INTO cash_payment (payment_id, collected_by, receipt_no) VALUES (5, 6, 'RCP00000005');

-- Maintenance (7) --------------------------------------------------------------------
-- columns: id, vehicle, centre, type, service_date, completed_date, odometer, cost, next_due_date, next_due_km, description, status
INSERT INTO maintenance VALUES (seq_maintenance.NEXTVAL, 1, 1, 'ROUTINE',    TRUNC(SYSDATE) - 120, TRUNC(SYSDATE) - 119, 170000, 45000, TRUNC(SYSDATE) + 60, 190000, 'Oil and filter change',       'COMPLETED');
INSERT INTO maintenance VALUES (seq_maintenance.NEXTVAL, 2, 1, 'ROUTINE',    TRUNC(SYSDATE) - 170, TRUNC(SYSDATE) - 169, 90000,  38000, TRUNC(SYSDATE) + 7,  100000, 'Full service',                'COMPLETED');
INSERT INTO maintenance VALUES (seq_maintenance.NEXTVAL, 3, 2, 'ROUTINE',    TRUNC(SYSDATE) - 200, TRUNC(SYSDATE) - 199, 112000, 22000, TRUNC(SYSDATE) - 5,  125000, 'Brake pads and oil',          'COMPLETED');
INSERT INTO maintenance VALUES (seq_maintenance.NEXTVAL, 4, 3, 'ROUTINE',    TRUNC(SYSDATE) - 150, TRUNC(SYSDATE) - 149, 198000, 30000, TRUNC(SYSDATE) + 30, 211800, 'Routine service',             'COMPLETED');
INSERT INTO maintenance VALUES (seq_maintenance.NEXTVAL, 4, 3, 'REPAIR',     TRUNC(SYSDATE) - 2,   NULL,                 209000, 85000, NULL,                 NULL,   'Gearbox repair',              'IN_PROGRESS');
INSERT INTO maintenance VALUES (seq_maintenance.NEXTVAL, 5, 1, 'INSPECTION', TRUNC(SYSDATE) - 90,  TRUNC(SYSDATE) - 90,  48000,  8000,  TRUNC(SYSDATE) + 90, 58000,  'Annual inspection',           'COMPLETED');
INSERT INTO maintenance VALUES (seq_maintenance.NEXTVAL, 2, 1, 'ROUTINE',    TRUNC(SYSDATE) + 7,   NULL,                 96400,  0,     NULL,                 NULL,   'Upcoming scheduled service',  'SCHEDULED');

-- Feedback (5) -----------------------------------------------------------------------
-- columns: id, passenger, trip, overall, driver, vehicle, punctuality, comments, submitted_at, response, responded_at
INSERT INTO feedback VALUES (seq_feedback.NEXTVAL, 1, 1, 5, 5, 4, 5, 'Smooth and on time.',        SYSTIMESTAMP - INTERVAL '6' DAY, NULL, NULL);
INSERT INTO feedback VALUES (seq_feedback.NEXTVAL, 2, 1, 4, 4, 4, 3, 'Good, slightly late start.',  SYSTIMESTAMP - INTERVAL '6' DAY, NULL, NULL);
INSERT INTO feedback VALUES (seq_feedback.NEXTVAL, 3, 2, 3, 3, 4, 2, 'Departed late.',             SYSTIMESTAMP - INTERVAL '5' DAY, 'Sorry about the delay, we are reviewing it.', SYSTIMESTAMP - INTERVAL '4' DAY);
INSERT INTO feedback VALUES (seq_feedback.NEXTVAL, 4, 3, 5, 5, 5, 5, 'Very comfortable ride.',     SYSTIMESTAMP - INTERVAL '4' DAY, NULL, NULL);
INSERT INTO feedback VALUES (seq_feedback.NEXTVAL, 5, 4, 4, 4, 3, 4, 'Fine overall.',              SYSTIMESTAMP - INTERVAL '3' DAY, NULL, NULL);

COMMIT;

-- Row counts (every table must be 10 or fewer) ----------------------------------------
SELECT 'person' AS tbl, COUNT(*) AS n FROM person UNION ALL
SELECT 'passenger', COUNT(*) FROM passenger UNION ALL
SELECT 'driver', COUNT(*) FROM driver UNION ALL
SELECT 'vehicle', COUNT(*) FROM vehicle UNION ALL
SELECT 'route', COUNT(*) FROM route UNION ALL
SELECT 'route_stop', COUNT(*) FROM route_stop UNION ALL
SELECT 'trip', COUNT(*) FROM trip UNION ALL
SELECT 'booking', COUNT(*) FROM booking UNION ALL
SELECT 'ticket', COUNT(*) FROM ticket UNION ALL
SELECT 'payment', COUNT(*) FROM payment UNION ALL
SELECT 'maintenance', COUNT(*) FROM maintenance UNION ALL
SELECT 'feedback', COUNT(*) FROM feedback;
