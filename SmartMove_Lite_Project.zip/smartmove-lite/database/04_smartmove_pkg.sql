--------------------------------------------------------------------------------
-- SmartMove Transport Solutions
-- 04_smartmove_pkg.sql : Business logic and reporting package
--
-- Structure
--   Operations   create_booking, cancel_booking, record_payment, complete_trip
--   Functions    fn_calculate_fare, fn_total_revenue
--   Reports      each of the five reports exists twice:
--                  rc_*   returns a SYS_REFCURSOR  -> consumed by the web app
--                  rpt_*  prints via DBMS_OUTPUT    -> demo / viva
--                The rpt_* procedures FETCH from the rc_* cursors, so each
--                report's SQL lives in exactly one place.
--
-- Transactions
--   Operations do NOT commit. The caller owns the transaction (the Node API
--   commits per request; 05_demo.sql rolls back at the end). Each operation
--   sets a savepoint and rolls back to it on failure, so a failed call never
--   leaves half-written rows behind.
--------------------------------------------------------------------------------


CREATE OR REPLACE PACKAGE smartmove_pkg AS

    ----------------------------------------------------------------------------
    -- Error codes. Every business rule violation raises one of these through
    -- RAISE_APPLICATION_ERROR with a descriptive message; the named
    -- exceptions let PL/SQL callers catch them by name.
    ----------------------------------------------------------------------------
    c_err_insufficient_seats CONSTANT PLS_INTEGER := -20001;
    c_err_trip_not_bookable  CONSTANT PLS_INTEGER := -20002;
    c_err_invalid_stops      CONSTANT PLS_INTEGER := -20003;
    c_err_passenger_inactive CONSTANT PLS_INTEGER := -20004;
    c_err_not_cancellable    CONSTANT PLS_INTEGER := -20005;
    c_err_date_range         CONSTANT PLS_INTEGER := -20006;
    c_err_driver_ineligible  CONSTANT PLS_INTEGER := -20007;   -- raised by trg_trip_assignment
    c_err_vehicle_unavail    CONSTANT PLS_INTEGER := -20008;   -- raised by trg_trip_assignment
    c_err_feedback_denied    CONSTANT PLS_INTEGER := -20009;   -- raised by trg_feedback_validate
    c_err_payment_invalid    CONSTANT PLS_INTEGER := -20010;
    c_err_not_found          CONSTANT PLS_INTEGER := -20011;
    c_err_no_data            CONSTANT PLS_INTEGER := -20012;
    c_err_subtype_mismatch   CONSTANT PLS_INTEGER := -20013;   -- raised by subtype triggers
    c_err_resource_busy      CONSTANT PLS_INTEGER := -20014;
    c_err_invalid_state      CONSTANT PLS_INTEGER := -20015;

    e_insufficient_seats EXCEPTION;  PRAGMA EXCEPTION_INIT(e_insufficient_seats, -20001);
    e_trip_not_bookable  EXCEPTION;  PRAGMA EXCEPTION_INIT(e_trip_not_bookable,  -20002);
    e_invalid_stops      EXCEPTION;  PRAGMA EXCEPTION_INIT(e_invalid_stops,      -20003);
    e_passenger_inactive EXCEPTION;  PRAGMA EXCEPTION_INIT(e_passenger_inactive, -20004);
    e_not_cancellable    EXCEPTION;  PRAGMA EXCEPTION_INIT(e_not_cancellable,    -20005);
    e_date_range         EXCEPTION;  PRAGMA EXCEPTION_INIT(e_date_range,         -20006);
    e_driver_ineligible  EXCEPTION;  PRAGMA EXCEPTION_INIT(e_driver_ineligible,  -20007);
    e_vehicle_unavail    EXCEPTION;  PRAGMA EXCEPTION_INIT(e_vehicle_unavail,    -20008);
    e_feedback_denied    EXCEPTION;  PRAGMA EXCEPTION_INIT(e_feedback_denied,    -20009);
    e_payment_invalid    EXCEPTION;  PRAGMA EXCEPTION_INIT(e_payment_invalid,    -20010);
    e_not_found          EXCEPTION;  PRAGMA EXCEPTION_INIT(e_not_found,          -20011);
    e_no_data            EXCEPTION;  PRAGMA EXCEPTION_INIT(e_no_data,            -20012);
    e_subtype_mismatch   EXCEPTION;  PRAGMA EXCEPTION_INIT(e_subtype_mismatch,   -20013);
    e_resource_busy      EXCEPTION;  PRAGMA EXCEPTION_INIT(e_resource_busy,      -20014);
    e_invalid_state      EXCEPTION;  PRAGMA EXCEPTION_INIT(e_invalid_state,      -20015);

    ----------------------------------------------------------------------------
    -- Business constants
    ----------------------------------------------------------------------------
    c_min_fare             CONSTANT NUMBER := 50;     -- LKR, floor for any segment
    c_student_discount     CONSTANT NUMBER := 20;     -- %
    c_senior_discount      CONSTANT NUMBER := 25;     -- %
    c_on_time_grace_min    CONSTANT NUMBER := 10;     -- departure within this is "on time"
    c_points_per_lkr       CONSTANT NUMBER := 100;    -- 1 loyalty point per LKR 100 spent

    ----------------------------------------------------------------------------
    -- Report row types (column order matches the matching rc_* query)
    ----------------------------------------------------------------------------
    TYPE t_top_route_rec IS RECORD (
        rank_no          NUMBER,
        route_code       route.route_code%TYPE,
        route_name       route.route_name%TYPE,
        trips            NUMBER,
        bookings         NUMBER,
        seats_sold       NUMBER,
        revenue          NUMBER,
        load_factor_pct  NUMBER
    );

    TYPE t_revenue_method_rec IS RECORD (
        method       payment.method%TYPE,
        txns         NUMBER,
        gross        NUMBER,
        refunds      NUMBER,
        net          NUMBER,
        share_pct    NUMBER
    );

    TYPE t_revenue_route_rec IS RECORD (
        route_code    route.route_code%TYPE,
        route_name    route.route_name%TYPE,
        bookings      NUMBER,
        seats         NUMBER,
        net           NUMBER,
        avg_per_seat  NUMBER
    );

    TYPE t_history_rec IS RECORD (
        booking_ref     booking.booking_ref%TYPE,
        trip_date       DATE,
        dep_time        VARCHAR2(5),
        route_code      route.route_code%TYPE,
        board_stop      stop.stop_name%TYPE,
        drop_stop       stop.stop_name%TYPE,
        seat_count      NUMBER,
        total_amount    NUMBER,
        booking_status  booking.status%TYPE,
        pay_method      VARCHAR2(10),
        rating          NUMBER
    );

    TYPE t_maintenance_rec IS RECORD (
        reg_no            vehicle.reg_no%TYPE,
        type_name         vehicle_type.type_name%TYPE,
        odometer_km       NUMBER,
        last_service      DATE,
        next_service_due  DATE,
        next_due_km       NUMBER,
        km_remaining      NUMBER,
        days_remaining    NUMBER,
        insurance_expiry  DATE,
        open_jobs         NUMBER,
        priority          VARCHAR2(10)
    );

    TYPE t_driver_rec IS RECORD (
        rank_no        NUMBER,
        driver_name    person.full_name%TYPE,
        licence_no     driver.licence_no%TYPE,
        completed      NUMBER,
        cancelled      NUMBER,
        passengers     NUMBER,
        on_time_pct    NUMBER,
        avg_delay_min  NUMBER,
        driver_rating  NUMBER,
        reviews        NUMBER,
        score          NUMBER,
        band           VARCHAR2(12)
    );

    ----------------------------------------------------------------------------
    -- Functions
    ----------------------------------------------------------------------------
    -- Per-seat fare for a segment of a route, after the better of the
    -- passenger's category discount and their employer's corporate discount.
    FUNCTION fn_calculate_fare (
        p_route_id       IN route.route_id%TYPE,
        p_board_stop_id  IN stop.stop_id%TYPE,
        p_drop_stop_id   IN stop.stop_id%TYPE,
        p_passenger_id   IN passenger.passenger_id%TYPE
    ) RETURN NUMBER;

    -- Net ticket revenue (payments less refunds) for an inclusive date range.
    FUNCTION fn_total_revenue (
        p_from  IN DATE,
        p_to    IN DATE
    ) RETURN NUMBER;

    ----------------------------------------------------------------------------
    -- Operations
    ----------------------------------------------------------------------------
    PROCEDURE create_booking (
        p_passenger_id   IN  passenger.passenger_id%TYPE,
        p_trip_id        IN  trip.trip_id%TYPE,
        p_board_stop_id  IN  stop.stop_id%TYPE,
        p_drop_stop_id   IN  stop.stop_id%TYPE,
        p_seat_count     IN  PLS_INTEGER,
        p_channel        IN  booking.booking_channel%TYPE DEFAULT 'ONLINE',
        o_booking_id     OUT booking.booking_id%TYPE,
        o_booking_ref    OUT booking.booking_ref%TYPE,
        o_total_amount   OUT booking.total_amount%TYPE
    );

    PROCEDURE record_payment (
        p_booking_id       IN  booking.booking_id%TYPE,
        p_method           IN  payment.method%TYPE,
        p_amount           IN  payment.amount%TYPE,
        p_card_brand       IN  card_payment.card_brand%TYPE        DEFAULT NULL,
        p_card_last4       IN  card_payment.card_last4%TYPE        DEFAULT NULL,
        p_gateway          IN  card_payment.gateway%TYPE           DEFAULT NULL,
        p_wallet_provider  IN  wallet_payment.wallet_provider%TYPE DEFAULT NULL,
        p_wallet_ref       IN  wallet_payment.wallet_ref%TYPE      DEFAULT NULL,
        p_collected_by     IN  cash_payment.collected_by%TYPE      DEFAULT NULL,
        o_payment_id       OUT payment.payment_id%TYPE
    );

    PROCEDURE cancel_booking (
        p_booking_id     IN  booking.booking_id%TYPE,
        o_refund_amount  OUT payment.refund_amount%TYPE
    );

    PROCEDURE complete_trip (
        p_trip_id          IN  trip.trip_id%TYPE,
        o_passengers_done  OUT PLS_INTEGER
    );

    ----------------------------------------------------------------------------
    -- Report data sources (for the application layer)
    ----------------------------------------------------------------------------
    FUNCTION rc_top_routes         (p_from IN DATE, p_to IN DATE, p_top_n IN PLS_INTEGER DEFAULT 5) RETURN SYS_REFCURSOR;
    FUNCTION rc_revenue_by_method  (p_from IN DATE, p_to IN DATE) RETURN SYS_REFCURSOR;
    FUNCTION rc_revenue_by_route   (p_from IN DATE, p_to IN DATE) RETURN SYS_REFCURSOR;
    FUNCTION rc_passenger_history  (p_passenger_id IN passenger.passenger_id%TYPE) RETURN SYS_REFCURSOR;
    FUNCTION rc_maintenance_due    (p_days_ahead IN PLS_INTEGER DEFAULT 14, p_km_buffer IN PLS_INTEGER DEFAULT 2000) RETURN SYS_REFCURSOR;
    FUNCTION rc_driver_performance (p_from IN DATE, p_to IN DATE) RETURN SYS_REFCURSOR;

    ----------------------------------------------------------------------------
    -- Printed reports (DBMS_OUTPUT)
    ----------------------------------------------------------------------------
    PROCEDURE rpt_top_routes         (p_from IN DATE, p_to IN DATE, p_top_n IN PLS_INTEGER DEFAULT 5);
    PROCEDURE rpt_revenue            (p_from IN DATE, p_to IN DATE);
    PROCEDURE rpt_passenger_history  (p_passenger_id IN passenger.passenger_id%TYPE, p_max_rows IN PLS_INTEGER DEFAULT 15);
    PROCEDURE rpt_maintenance_due    (p_days_ahead IN PLS_INTEGER DEFAULT 14, p_km_buffer IN PLS_INTEGER DEFAULT 2000);
    PROCEDURE rpt_driver_performance (p_from IN DATE, p_to IN DATE);

END smartmove_pkg;
/


CREATE OR REPLACE PACKAGE BODY smartmove_pkg AS

    c_width CONSTANT PLS_INTEGER := 112;

    ----------------------------------------------------------------------------
    -- PRIVATE HELPERS
    ----------------------------------------------------------------------------
    PROCEDURE raise_err (p_code IN PLS_INTEGER, p_msg IN VARCHAR2) IS
    BEGIN
        RAISE_APPLICATION_ERROR(p_code, p_msg);
    END raise_err;

    -- Server clock as a plain TIMESTAMP, consistent with SYSDATE-based data
    FUNCTION now_ts RETURN TIMESTAMP IS
    BEGIN
        RETURN CAST(SYSTIMESTAMP AS TIMESTAMP);
    END now_ts;

    FUNCTION minutes_until (p_ts IN TIMESTAMP) RETURN NUMBER IS
        v_gap INTERVAL DAY(9) TO SECOND;
    BEGIN
        v_gap := p_ts - now_ts;
        RETURN EXTRACT(DAY FROM v_gap) * 1440
             + EXTRACT(HOUR FROM v_gap) * 60
             + EXTRACT(MINUTE FROM v_gap);
    END minutes_until;

    PROCEDURE check_range (p_from IN DATE, p_to IN DATE) IS
    BEGIN
        IF p_from IS NULL OR p_to IS NULL THEN
            raise_err(c_err_date_range, 'Both a start date and an end date are required');
        END IF;
        IF p_from > p_to THEN
            raise_err(c_err_date_range,
                'Start date ' || TO_CHAR(p_from, 'YYYY-MM-DD') ||
                ' is after end date ' || TO_CHAR(p_to, 'YYYY-MM-DD'));
        END IF;
    END check_range;

    -- Output formatting
    PROCEDURE say (p_text IN VARCHAR2 DEFAULT NULL) IS
    BEGIN
        DBMS_OUTPUT.PUT_LINE(NVL(p_text, ' '));
    END say;

    FUNCTION col (p_text IN VARCHAR2, p_width IN PLS_INTEGER) RETURN VARCHAR2 IS
    BEGIN
        RETURN RPAD(NVL(SUBSTR(p_text, 1, p_width - 1), ' '), p_width);
    END col;

    FUNCTION num (p_text IN VARCHAR2, p_width IN PLS_INTEGER) RETURN VARCHAR2 IS
    BEGIN
        RETURN LPAD(NVL(p_text, '-'), p_width);
    END num;

    FUNCTION money (p_value IN NUMBER) RETURN VARCHAR2 IS
    BEGIN
        RETURN TO_CHAR(NVL(p_value, 0), 'FM999,999,999,990.00');
    END money;

    FUNCTION pct (p_value IN NUMBER) RETURN VARCHAR2 IS
    BEGIN
        RETURN CASE WHEN p_value IS NULL THEN NULL ELSE TO_CHAR(p_value, 'FM990.0') END;
    END pct;

    FUNCTION ymd (p_date IN DATE) RETURN VARCHAR2 IS
    BEGIN
        RETURN TO_CHAR(p_date, 'YYYY-MM-DD');
    END ymd;

    PROCEDURE hr (p_char IN VARCHAR2 DEFAULT '-') IS
    BEGIN
        say(RPAD(p_char, c_width, p_char));
    END hr;

    PROCEDURE print_header (p_title IN VARCHAR2, p_subtitle IN VARCHAR2 DEFAULT NULL) IS
    BEGIN
        say;
        hr('=');
        say('  SMARTMOVE TRANSPORT SOLUTIONS');
        say('  ' || p_title);
        IF p_subtitle IS NOT NULL THEN
            say('  ' || p_subtitle);
        END IF;
        say('  Generated ' || TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI'));
        hr('=');
    END print_header;


    ----------------------------------------------------------------------------
    -- FUNCTIONS
    ----------------------------------------------------------------------------
    FUNCTION fn_calculate_fare (
        p_route_id       IN route.route_id%TYPE,
        p_board_stop_id  IN stop.stop_id%TYPE,
        p_drop_stop_id   IN stop.stop_id%TYPE,
        p_passenger_id   IN passenger.passenger_id%TYPE
    ) RETURN NUMBER
    IS
        v_board_seq      route_stop.stop_seq%TYPE;
        v_drop_seq       route_stop.stop_seq%TYPE;
        v_board_fare     route_stop.fare_from_origin%TYPE;
        v_drop_fare      route_stop.fare_from_origin%TYPE;
        v_category       passenger.passenger_category%TYPE;
        v_corp_pct       corporate_client.discount_pct%TYPE;
        v_corp_status    corporate_client.status%TYPE;
        v_corp_end       corporate_client.contract_end%TYPE;
        v_category_pct   NUMBER := 0;
        v_effective_pct  NUMBER := 0;
        v_segment_fare   NUMBER;
    BEGIN
        BEGIN
            SELECT stop_seq, fare_from_origin
              INTO v_board_seq, v_board_fare
              FROM route_stop
             WHERE route_id = p_route_id AND stop_id = p_board_stop_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                raise_err(c_err_invalid_stops,
                    'Boarding stop ' || p_board_stop_id || ' is not on route ' || p_route_id);
        END;

        BEGIN
            SELECT stop_seq, fare_from_origin
              INTO v_drop_seq, v_drop_fare
              FROM route_stop
             WHERE route_id = p_route_id AND stop_id = p_drop_stop_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                raise_err(c_err_invalid_stops,
                    'Drop-off stop ' || p_drop_stop_id || ' is not on route ' || p_route_id);
        END;

        IF v_drop_seq <= v_board_seq THEN
            raise_err(c_err_invalid_stops,
                'Drop-off stop must come after the boarding stop on route ' || p_route_id);
        END IF;

        v_segment_fare := GREATEST(v_drop_fare - v_board_fare, c_min_fare);

        BEGIN
            SELECT p.passenger_category, cc.discount_pct, cc.status, cc.contract_end
              INTO v_category, v_corp_pct, v_corp_status, v_corp_end
              FROM passenger p
              LEFT JOIN corporate_client cc ON cc.client_id = p.client_id
             WHERE p.passenger_id = p_passenger_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                raise_err(c_err_not_found, 'Passenger ' || p_passenger_id || ' does not exist');
        END;

        v_category_pct := CASE v_category
                              WHEN 'STUDENT' THEN c_student_discount
                              WHEN 'SENIOR'  THEN c_senior_discount
                              ELSE 0
                          END;

        -- Corporate discount only applies under a live contract
        IF v_corp_status = 'ACTIVE' AND (v_corp_end IS NULL OR v_corp_end >= TRUNC(SYSDATE)) THEN
            v_effective_pct := GREATEST(v_category_pct, NVL(v_corp_pct, 0));
        ELSE
            v_effective_pct := v_category_pct;
        END IF;

        -- Discounts do not stack: the passenger gets the better of the two
        RETURN ROUND(v_segment_fare * (1 - v_effective_pct / 100), 2);
    END fn_calculate_fare;


    FUNCTION fn_total_revenue (p_from IN DATE, p_to IN DATE) RETURN NUMBER IS
        v_total NUMBER;
    BEGIN
        check_range(p_from, p_to);

        SELECT NVL(SUM(p.amount - p.refund_amount), 0)
          INTO v_total
          FROM payment p
         WHERE p.status IN ('SUCCESS', 'REFUNDED')
           AND p.paid_at >= CAST(TRUNC(p_from)    AS TIMESTAMP)
           AND p.paid_at <  CAST(TRUNC(p_to) + 1  AS TIMESTAMP);

        RETURN v_total;
    END fn_total_revenue;


    ----------------------------------------------------------------------------
    -- OPERATIONS
    ----------------------------------------------------------------------------
    PROCEDURE create_booking (
        p_passenger_id   IN  passenger.passenger_id%TYPE,
        p_trip_id        IN  trip.trip_id%TYPE,
        p_board_stop_id  IN  stop.stop_id%TYPE,
        p_drop_stop_id   IN  stop.stop_id%TYPE,
        p_seat_count     IN  PLS_INTEGER,
        p_channel        IN  booking.booking_channel%TYPE DEFAULT 'ONLINE',
        o_booking_id     OUT booking.booking_id%TYPE,
        o_booking_ref    OUT booking.booking_ref%TYPE,
        o_total_amount   OUT booking.total_amount%TYPE
    )
    IS
        -- Locks the trip row so two concurrent bookings cannot both see the
        -- last seat as free.
        CURSOR c_trip IS
            SELECT t.trip_id, t.route_id, t.status, t.scheduled_departure,
                   t.seats_available, v.seat_capacity
              FROM trip t
              JOIN vehicle v ON v.vehicle_id = t.vehicle_id
             WHERE t.trip_id = p_trip_id
               FOR UPDATE OF t.seats_available WAIT 5;
        r_trip c_trip%ROWTYPE;

        -- Seats 1..capacity not held by a live ticket, lowest first
        CURSOR c_free_seats (cp_trip_id IN NUMBER, cp_capacity IN NUMBER) IS
            SELECT seat_no
              FROM (SELECT TO_CHAR(LEVEL) AS seat_no
                      FROM dual
                   CONNECT BY LEVEL <= cp_capacity
                    MINUS
                    SELECT tk.seat_no
                      FROM ticket tk
                      JOIN booking b ON b.booking_id = tk.booking_id
                     WHERE b.trip_id = cp_trip_id
                       AND tk.status IN ('VALID', 'USED'))
             ORDER BY TO_NUMBER(seat_no);

        v_pax_status  passenger.status%TYPE;
        v_pax_name    person.full_name%TYPE;
        v_unit_fare   NUMBER;
        v_issued      PLS_INTEGER := 0;

        e_lock_timeout EXCEPTION;
        PRAGMA EXCEPTION_INIT(e_lock_timeout, -30006);   -- ORA-30006: resource busy, WAIT timeout
    BEGIN
        SAVEPOINT sp_create_booking;

        IF p_seat_count IS NULL OR p_seat_count NOT BETWEEN 1 AND 10 THEN
            raise_err(c_err_insufficient_seats, 'Seat count must be between 1 and 10');
        END IF;

        IF p_channel NOT IN ('ONLINE', 'MOBILE', 'COUNTER', 'AGENT') THEN
            raise_err(c_err_invalid_state, 'Unknown booking channel ' || p_channel);
        END IF;

        -- Passenger must exist and be allowed to book
        BEGIN
            SELECT pa.status, pe.full_name
              INTO v_pax_status, v_pax_name
              FROM passenger pa
              JOIN person pe ON pe.person_id = pa.passenger_id
             WHERE pa.passenger_id = p_passenger_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                raise_err(c_err_not_found, 'Passenger ' || p_passenger_id || ' does not exist');
        END;

        IF v_pax_status <> 'ACTIVE' THEN
            raise_err(c_err_passenger_inactive,
                'Passenger ' || p_passenger_id || ' is ' || v_pax_status || ' and cannot book');
        END IF;

        -- Lock and validate the trip
        OPEN c_trip;
        FETCH c_trip INTO r_trip;
        IF c_trip%NOTFOUND THEN
            CLOSE c_trip;
            raise_err(c_err_not_found, 'Trip ' || p_trip_id || ' does not exist');
        END IF;
        CLOSE c_trip;   -- row lock is held until commit/rollback

        IF r_trip.status NOT IN ('SCHEDULED', 'BOARDING', 'DELAYED') THEN
            raise_err(c_err_trip_not_bookable,
                'Trip ' || p_trip_id || ' is ' || r_trip.status || ' and is not open for booking');
        END IF;

        IF r_trip.scheduled_departure <= now_ts THEN
            raise_err(c_err_trip_not_bookable, 'Trip ' || p_trip_id || ' has already departed');
        END IF;

        IF r_trip.seats_available < p_seat_count THEN
            raise_err(c_err_insufficient_seats,
                'Requested ' || p_seat_count || ' seat(s) but only ' ||
                r_trip.seats_available || ' remain on trip ' || p_trip_id);
        END IF;

        -- Price and write the booking
        v_unit_fare    := fn_calculate_fare(r_trip.route_id, p_board_stop_id, p_drop_stop_id, p_passenger_id);
        o_total_amount := v_unit_fare * p_seat_count;

        INSERT INTO booking (passenger_id, trip_id, board_stop_id, drop_stop_id,
                             seat_count, total_amount, booking_channel, status)
        VALUES (p_passenger_id, p_trip_id, p_board_stop_id, p_drop_stop_id,
                p_seat_count, o_total_amount, p_channel, 'PENDING')
        RETURNING booking_id, booking_ref INTO o_booking_id, o_booking_ref;   -- keys set by trg_booking_keys

        -- Allocate the lowest free seat numbers
        FOR r_seat IN c_free_seats(p_trip_id, r_trip.seat_capacity) LOOP
            EXIT WHEN v_issued = p_seat_count;

            INSERT INTO ticket (ticket_id, booking_id, seat_no, passenger_name, fare, qr_code, status)
            VALUES (seq_ticket.NEXTVAL, o_booking_id, r_seat.seat_no, v_pax_name, v_unit_fare,
                    'QR-' || LPAD(o_booking_id, 8, '0') || '-' || r_seat.seat_no, 'VALID');

            v_issued := v_issued + 1;
        END LOOP;

        -- seats_available and the seat map disagree: refuse rather than oversell
        IF v_issued < p_seat_count THEN
            raise_err(c_err_insufficient_seats,
                'Seat map for trip ' || p_trip_id || ' has only ' || v_issued || ' free seat(s)');
        END IF;

        UPDATE trip
           SET seats_available = seats_available - p_seat_count
         WHERE trip_id = p_trip_id;

    EXCEPTION
        WHEN e_lock_timeout THEN
            ROLLBACK TO sp_create_booking;
            raise_err(c_err_resource_busy,
                'Trip ' || p_trip_id || ' is being booked by another user; please retry');
        WHEN OTHERS THEN
            ROLLBACK TO sp_create_booking;
            RAISE;
    END create_booking;


    PROCEDURE record_payment (
        p_booking_id       IN  booking.booking_id%TYPE,
        p_method           IN  payment.method%TYPE,
        p_amount           IN  payment.amount%TYPE,
        p_card_brand       IN  card_payment.card_brand%TYPE        DEFAULT NULL,
        p_card_last4       IN  card_payment.card_last4%TYPE        DEFAULT NULL,
        p_gateway          IN  card_payment.gateway%TYPE           DEFAULT NULL,
        p_wallet_provider  IN  wallet_payment.wallet_provider%TYPE DEFAULT NULL,
        p_wallet_ref       IN  wallet_payment.wallet_ref%TYPE      DEFAULT NULL,
        p_collected_by     IN  cash_payment.collected_by%TYPE      DEFAULT NULL,
        o_payment_id       OUT payment.payment_id%TYPE
    )
    IS
        CURSOR c_booking IS
            SELECT booking_id, status, total_amount
              FROM booking
             WHERE booking_id = p_booking_id
               FOR UPDATE OF status WAIT 5;
        r_booking c_booking%ROWTYPE;

        e_lock_timeout EXCEPTION;
        PRAGMA EXCEPTION_INIT(e_lock_timeout, -30006);
    BEGIN
        SAVEPOINT sp_record_payment;

        OPEN c_booking;
        FETCH c_booking INTO r_booking;
        IF c_booking%NOTFOUND THEN
            CLOSE c_booking;
            raise_err(c_err_not_found, 'Booking ' || p_booking_id || ' does not exist');
        END IF;
        CLOSE c_booking;

        IF r_booking.status <> 'PENDING' THEN
            raise_err(c_err_invalid_state,
                'Booking ' || p_booking_id || ' is ' || r_booking.status || ' and cannot take a payment');
        END IF;

        IF p_amount IS NULL OR p_amount <> r_booking.total_amount THEN
            raise_err(c_err_payment_invalid,
                'Payment of LKR ' || money(p_amount) || ' does not match booking total LKR ' ||
                money(r_booking.total_amount));
        END IF;

        -- Subtype-specific validation
        CASE p_method
            WHEN 'CARD' THEN
                IF p_card_brand IS NULL OR NOT REGEXP_LIKE(NVL(p_card_last4, 'x'), '^[0-9]{4}$') THEN
                    raise_err(c_err_payment_invalid, 'Card payments need a card brand and the last 4 digits');
                END IF;
            WHEN 'WALLET' THEN
                IF p_wallet_provider IS NULL THEN
                    raise_err(c_err_payment_invalid, 'Wallet payments need a wallet provider');
                END IF;
            WHEN 'CASH' THEN
                NULL;
            ELSE
                raise_err(c_err_payment_invalid, 'Unknown payment method ' || NVL(p_method, 'NULL'));
        END CASE;

        o_payment_id := seq_payment.NEXTVAL;

        INSERT INTO payment (payment_id, booking_id, amount, method, txn_ref, paid_at, status, refund_amount)
        VALUES (o_payment_id, p_booking_id, p_amount, p_method,
                'TXN' || LPAD(o_payment_id, 10, '0'), SYSTIMESTAMP, 'SUCCESS', 0);
        -- trg_payment_confirms_booking moves the booking PENDING -> CONFIRMED

        IF p_method = 'CARD' THEN
            INSERT INTO card_payment (payment_id, card_brand, card_last4, auth_code, gateway)
            VALUES (o_payment_id, p_card_brand, p_card_last4,
                    'AUTH' || LPAD(o_payment_id, 6, '0'), p_gateway);
        ELSIF p_method = 'WALLET' THEN
            INSERT INTO wallet_payment (payment_id, wallet_provider, wallet_ref)
            VALUES (o_payment_id, p_wallet_provider, p_wallet_ref);
        ELSE
            INSERT INTO cash_payment (payment_id, collected_by, receipt_no)
            VALUES (o_payment_id, p_collected_by, 'RCP' || LPAD(o_payment_id, 8, '0'));
        END IF;

    EXCEPTION
        WHEN e_lock_timeout THEN
            ROLLBACK TO sp_record_payment;
            raise_err(c_err_resource_busy, 'Booking ' || p_booking_id || ' is locked; please retry');
        WHEN OTHERS THEN
            ROLLBACK TO sp_record_payment;
            RAISE;
    END record_payment;


    PROCEDURE cancel_booking (
        p_booking_id     IN  booking.booking_id%TYPE,
        o_refund_amount  OUT payment.refund_amount%TYPE
    )
    IS
        CURSOR c_booking IS
            SELECT b.booking_id, b.status, b.seat_count, b.trip_id, t.scheduled_departure
              FROM booking b
              JOIN trip t ON t.trip_id = b.trip_id
             WHERE b.booking_id = p_booking_id
               FOR UPDATE OF b.status WAIT 5;
        r_booking c_booking%ROWTYPE;

        v_minutes_left  NUMBER;
        v_refund_pct    NUMBER;

        e_lock_timeout EXCEPTION;
        PRAGMA EXCEPTION_INIT(e_lock_timeout, -30006);
    BEGIN
        SAVEPOINT sp_cancel_booking;
        o_refund_amount := 0;

        OPEN c_booking;
        FETCH c_booking INTO r_booking;
        IF c_booking%NOTFOUND THEN
            CLOSE c_booking;
            raise_err(c_err_not_found, 'Booking ' || p_booking_id || ' does not exist');
        END IF;
        CLOSE c_booking;

        IF r_booking.status NOT IN ('PENDING', 'CONFIRMED') THEN
            raise_err(c_err_not_cancellable,
                'Booking ' || p_booking_id || ' is ' || r_booking.status || ' and cannot be cancelled');
        END IF;

        v_minutes_left := minutes_until(r_booking.scheduled_departure);

        IF v_minutes_left <= 0 THEN
            raise_err(c_err_not_cancellable,
                'Booking ' || p_booking_id || ' cannot be cancelled after departure');
        END IF;

        -- Refund policy: 24h+ = 90%, 2-24h = 50%, under 2h = no refund
        v_refund_pct := CASE
                            WHEN v_minutes_left >= 24 * 60 THEN 90
                            WHEN v_minutes_left >=  2 * 60 THEN 50
                            ELSE 0
                        END;

        IF v_refund_pct > 0 THEN
            UPDATE payment
               SET status        = 'REFUNDED',
                   refund_amount = ROUND(amount * v_refund_pct / 100, 2)
             WHERE booking_id = p_booking_id
               AND status     = 'SUCCESS';

            IF SQL%ROWCOUNT > 0 THEN
                SELECT NVL(SUM(refund_amount), 0)
                  INTO o_refund_amount
                  FROM payment
                 WHERE booking_id = p_booking_id
                   AND status     = 'REFUNDED';
            END IF;
        END IF;

        UPDATE booking
           SET status       = 'CANCELLED',
               cancelled_at = SYSTIMESTAMP
         WHERE booking_id = p_booking_id;

        UPDATE ticket
           SET status = 'CANCELLED'
         WHERE booking_id = p_booking_id
           AND status     = 'VALID';

        -- Pending and confirmed bookings both held seats; release them
        UPDATE trip
           SET seats_available = seats_available + r_booking.seat_count
         WHERE trip_id = r_booking.trip_id;

    EXCEPTION
        WHEN e_lock_timeout THEN
            ROLLBACK TO sp_cancel_booking;
            raise_err(c_err_resource_busy, 'Booking ' || p_booking_id || ' is locked; please retry');
        WHEN OTHERS THEN
            ROLLBACK TO sp_cancel_booking;
            RAISE;
    END cancel_booking;


    PROCEDURE complete_trip (
        p_trip_id          IN  trip.trip_id%TYPE,
        o_passengers_done  OUT PLS_INTEGER
    )
    IS
        CURSOR c_trip IS
            SELECT trip_id, status, actual_departure, scheduled_departure
              FROM trip
             WHERE trip_id = p_trip_id
               FOR UPDATE OF status WAIT 5;
        r_trip c_trip%ROWTYPE;

        -- Every open booking on the trip, updated row-by-row via CURRENT OF
        CURSOR c_open_bookings IS
            SELECT booking_id, passenger_id, total_amount, seat_count, status
              FROM booking
             WHERE trip_id = p_trip_id
               AND status IN ('PENDING', 'CONFIRMED')
               FOR UPDATE OF status;

        v_now          TIMESTAMP;   -- private functions cannot be called from SQL, so capture it first

        e_lock_timeout EXCEPTION;
        PRAGMA EXCEPTION_INIT(e_lock_timeout, -30006);
    BEGIN
        SAVEPOINT sp_complete_trip;
        v_now := now_ts;
        o_passengers_done := 0;

        OPEN c_trip;
        FETCH c_trip INTO r_trip;
        IF c_trip%NOTFOUND THEN
            CLOSE c_trip;
            raise_err(c_err_not_found, 'Trip ' || p_trip_id || ' does not exist');
        END IF;
        CLOSE c_trip;

        IF r_trip.status NOT IN ('BOARDING', 'IN_TRANSIT', 'DELAYED') THEN
            raise_err(c_err_invalid_state,
                'Trip ' || p_trip_id || ' is ' || r_trip.status ||
                '; only boarding, in-transit or delayed trips can be completed');
        END IF;

        FOR r_bk IN c_open_bookings LOOP
            IF r_bk.status = 'CONFIRMED' THEN
                UPDATE booking SET status = 'COMPLETED' WHERE CURRENT OF c_open_bookings;

                UPDATE ticket SET status = 'USED'
                 WHERE booking_id = r_bk.booking_id AND status = 'VALID';

                UPDATE passenger
                   SET loyalty_points = loyalty_points + FLOOR(r_bk.total_amount / c_points_per_lkr)
                 WHERE passenger_id = r_bk.passenger_id;

                o_passengers_done := o_passengers_done + r_bk.seat_count;
            ELSE
                -- Never paid, never boarded
                UPDATE booking SET status = 'NO_SHOW' WHERE CURRENT OF c_open_bookings;

                UPDATE ticket SET status = 'EXPIRED'
                 WHERE booking_id = r_bk.booking_id AND status = 'VALID';
            END IF;
        END LOOP;

        UPDATE trip
           SET status           = 'COMPLETED',
               actual_departure = NVL(actual_departure, scheduled_departure),
               actual_arrival   = v_now
         WHERE trip_id = p_trip_id;
        -- trg_trip_status_change advances the odometer and releases the driver

    EXCEPTION
        WHEN e_lock_timeout THEN
            ROLLBACK TO sp_complete_trip;
            raise_err(c_err_resource_busy, 'Trip ' || p_trip_id || ' is locked; please retry');
        WHEN OTHERS THEN
            ROLLBACK TO sp_complete_trip;
            RAISE;
    END complete_trip;


    ----------------------------------------------------------------------------
    -- REPORT DATA SOURCES
    ----------------------------------------------------------------------------

    -- REPORT 1 : Most frequently used routes
    FUNCTION rc_top_routes (p_from IN DATE, p_to IN DATE, p_top_n IN PLS_INTEGER DEFAULT 5)
        RETURN SYS_REFCURSOR
    IS
        l_rc SYS_REFCURSOR;
    BEGIN
        check_range(p_from, p_to);
        IF p_top_n IS NULL OR p_top_n < 1 THEN
            raise_err(c_err_invalid_state, 'Top-N must be a positive number');
        END IF;

        OPEN l_rc FOR
            WITH trip_load AS (
                SELECT t.trip_id,
                       t.route_id,
                       v.seat_capacity,
                       COUNT(CASE WHEN b.status IN ('CONFIRMED', 'COMPLETED') THEN 1 END)          AS bookings,
                       NVL(SUM(CASE WHEN b.status IN ('CONFIRMED', 'COMPLETED') THEN b.seat_count END), 0)   AS seats_sold,
                       NVL(SUM(CASE WHEN b.status IN ('CONFIRMED', 'COMPLETED') THEN b.total_amount END), 0) AS revenue
                  FROM trip t
                  JOIN vehicle v      ON v.vehicle_id = t.vehicle_id
                  LEFT JOIN booking b ON b.trip_id    = t.trip_id
                 WHERE t.trip_date BETWEEN TRUNC(p_from) AND TRUNC(p_to)
                   AND t.status <> 'CANCELLED'
                 GROUP BY t.trip_id, t.route_id, v.seat_capacity
            )
            SELECT rank_no, route_code, route_name, trips, bookings, seats_sold, revenue, load_factor_pct
              FROM (SELECT RANK() OVER (ORDER BY SUM(tl.bookings) DESC)                     AS rank_no,
                           r.route_code,
                           r.route_name,
                           COUNT(*)                                                         AS trips,
                           SUM(tl.bookings)                                                 AS bookings,
                           SUM(tl.seats_sold)                                               AS seats_sold,
                           SUM(tl.revenue)                                                  AS revenue,
                           ROUND(100 * SUM(tl.seats_sold) / NULLIF(SUM(tl.seat_capacity), 0), 1) AS load_factor_pct
                      FROM trip_load tl
                      JOIN route r ON r.route_id = tl.route_id
                     GROUP BY r.route_code, r.route_name)
             WHERE rank_no <= p_top_n
             ORDER BY rank_no, route_code;

        RETURN l_rc;
    END rc_top_routes;


    -- REPORT 2a : Revenue by payment method
    FUNCTION rc_revenue_by_method (p_from IN DATE, p_to IN DATE) RETURN SYS_REFCURSOR IS
        l_rc SYS_REFCURSOR;
    BEGIN
        check_range(p_from, p_to);

        OPEN l_rc FOR
            SELECT p.method,
                   COUNT(*)                                                     AS txns,
                   SUM(p.amount)                                                AS gross,
                   SUM(p.refund_amount)                                         AS refunds,
                   SUM(p.amount - p.refund_amount)                              AS net,
                   ROUND(100 * RATIO_TO_REPORT(SUM(p.amount - p.refund_amount)) OVER (), 1) AS share_pct
              FROM payment p
             WHERE p.status IN ('SUCCESS', 'REFUNDED')
               AND p.paid_at >= CAST(TRUNC(p_from)   AS TIMESTAMP)
               AND p.paid_at <  CAST(TRUNC(p_to) + 1 AS TIMESTAMP)
             GROUP BY p.method
             ORDER BY net DESC;

        RETURN l_rc;
    END rc_revenue_by_method;


    -- REPORT 2b : Revenue by route
    FUNCTION rc_revenue_by_route (p_from IN DATE, p_to IN DATE) RETURN SYS_REFCURSOR IS
        l_rc SYS_REFCURSOR;
    BEGIN
        check_range(p_from, p_to);

        OPEN l_rc FOR
            SELECT r.route_code,
                   r.route_name,
                   COUNT(DISTINCT b.booking_id)                                          AS bookings,
                   SUM(b.seat_count)                                                     AS seats,
                   SUM(p.amount - p.refund_amount)                                       AS net,
                   ROUND(SUM(p.amount - p.refund_amount) / NULLIF(SUM(b.seat_count), 0), 2) AS avg_per_seat
              FROM payment p
              JOIN booking b ON b.booking_id = p.booking_id
              JOIN trip t    ON t.trip_id    = b.trip_id
              JOIN route r   ON r.route_id   = t.route_id
             WHERE p.status IN ('SUCCESS', 'REFUNDED')
               AND p.paid_at >= CAST(TRUNC(p_from)   AS TIMESTAMP)
               AND p.paid_at <  CAST(TRUNC(p_to) + 1 AS TIMESTAMP)
             GROUP BY r.route_code, r.route_name
             ORDER BY net DESC;

        RETURN l_rc;
    END rc_revenue_by_route;


    -- REPORT 3 : Passenger travel history
    FUNCTION rc_passenger_history (p_passenger_id IN passenger.passenger_id%TYPE) RETURN SYS_REFCURSOR IS
        l_rc     SYS_REFCURSOR;
        v_exists PLS_INTEGER;
    BEGIN
        SELECT COUNT(*) INTO v_exists FROM passenger WHERE passenger_id = p_passenger_id;
        IF v_exists = 0 THEN
            raise_err(c_err_not_found, 'Passenger ' || p_passenger_id || ' does not exist');
        END IF;

        OPEN l_rc FOR
            SELECT b.booking_ref,
                   t.trip_date,
                   TO_CHAR(t.scheduled_departure, 'HH24:MI') AS dep_time,
                   r.route_code,
                   bs.stop_name                              AS board_stop,
                   ds.stop_name                              AS drop_stop,
                   b.seat_count,
                   b.total_amount,
                   b.status                                  AS booking_status,
                   p.method                                  AS pay_method,
                   f.overall_rating                          AS rating
              FROM booking b
              JOIN trip t       ON t.trip_id   = b.trip_id
              JOIN route r      ON r.route_id  = t.route_id
              JOIN stop bs      ON bs.stop_id  = b.board_stop_id
              JOIN stop ds      ON ds.stop_id  = b.drop_stop_id
              LEFT JOIN payment p  ON p.booking_id  = b.booking_id
              LEFT JOIN feedback f ON f.trip_id     = b.trip_id
                                  AND f.passenger_id = b.passenger_id
             WHERE b.passenger_id = p_passenger_id
             ORDER BY t.scheduled_departure DESC, b.booking_id DESC;

        RETURN l_rc;
    END rc_passenger_history;


    -- REPORT 4 : Vehicles due for maintenance
    FUNCTION rc_maintenance_due (p_days_ahead IN PLS_INTEGER DEFAULT 14, p_km_buffer IN PLS_INTEGER DEFAULT 2000)
        RETURN SYS_REFCURSOR
    IS
        l_rc SYS_REFCURSOR;
    BEGIN
        IF p_days_ahead < 0 OR p_km_buffer < 0 THEN
            raise_err(c_err_invalid_state, 'Look-ahead days and km buffer must not be negative');
        END IF;

        OPEN l_rc FOR
            WITH last_service AS (
                SELECT vehicle_id,
                       MAX(service_date)                                          AS last_service,
                       MAX(next_due_km) KEEP (DENSE_RANK LAST ORDER BY service_date) AS next_due_km
                  FROM maintenance
                 WHERE status = 'COMPLETED'
                 GROUP BY vehicle_id
            ),
            open_jobs AS (
                SELECT vehicle_id, COUNT(*) AS open_jobs
                  FROM maintenance
                 WHERE status IN ('SCHEDULED', 'IN_PROGRESS')
                 GROUP BY vehicle_id
            ),
            candidates AS (
                SELECT v.reg_no,
                       vt.type_name,
                       v.odometer_km,
                       ls.last_service,
                       v.next_service_due,
                       ls.next_due_km,
                       ls.next_due_km - v.odometer_km                     AS km_remaining,
                       TRUNC(v.next_service_due) - TRUNC(SYSDATE)         AS days_remaining,
                       v.insurance_expiry,
                       NVL(oj.open_jobs, 0)                               AS open_jobs,
                       CASE
                           WHEN v.next_service_due < TRUNC(SYSDATE)
                             OR v.odometer_km >= ls.next_due_km          THEN 'OVERDUE'
                           WHEN v.insurance_expiry <= TRUNC(SYSDATE) + p_days_ahead THEN 'INSURANCE'
                           ELSE 'DUE_SOON'
                       END                                                AS priority
                  FROM vehicle v
                  JOIN vehicle_type vt     ON vt.type_id    = v.type_id
                  LEFT JOIN last_service ls ON ls.vehicle_id = v.vehicle_id
                  LEFT JOIN open_jobs oj    ON oj.vehicle_id = v.vehicle_id
                 WHERE v.status <> 'RETIRED'
                   AND (   v.next_service_due <= TRUNC(SYSDATE) + p_days_ahead
                        OR v.odometer_km      >= ls.next_due_km - p_km_buffer
                        OR v.insurance_expiry <= TRUNC(SYSDATE) + p_days_ahead)
            )
            SELECT reg_no, type_name, odometer_km, last_service, next_service_due, next_due_km,
                   km_remaining, days_remaining, insurance_expiry, open_jobs, priority
              FROM candidates
             ORDER BY CASE priority WHEN 'OVERDUE' THEN 1 WHEN 'INSURANCE' THEN 2 ELSE 3 END,
                      LEAST(NVL(days_remaining, 9999), NVL(km_remaining / 100, 9999));

        RETURN l_rc;
    END rc_maintenance_due;


    -- REPORT 5 : Driver performance scorecard
    FUNCTION rc_driver_performance (p_from IN DATE, p_to IN DATE) RETURN SYS_REFCURSOR IS
        l_rc SYS_REFCURSOR;
    BEGIN
        check_range(p_from, p_to);

        OPEN l_rc FOR
            WITH trip_base AS (
                SELECT t.trip_id,
                       t.driver_id,
                       t.status,
                       CASE WHEN t.actual_departure IS NOT NULL THEN
                             EXTRACT(DAY    FROM (t.actual_departure - t.scheduled_departure)) * 1440
                           + EXTRACT(HOUR   FROM (t.actual_departure - t.scheduled_departure)) * 60
                           + EXTRACT(MINUTE FROM (t.actual_departure - t.scheduled_departure))
                       END AS delay_min
                  FROM trip t
                 WHERE t.trip_date BETWEEN TRUNC(p_from) AND TRUNC(p_to)
                   AND t.status IN ('COMPLETED', 'CANCELLED')
            ),
            drv_trips AS (
                SELECT driver_id,
                       COUNT(CASE WHEN status = 'COMPLETED' THEN 1 END) AS completed,
                       COUNT(CASE WHEN status = 'CANCELLED' THEN 1 END) AS cancelled,
                       ROUND(100 * COUNT(CASE WHEN status = 'COMPLETED'
                                               AND delay_min <= c_on_time_grace_min THEN 1 END)
                                 / NULLIF(COUNT(CASE WHEN status = 'COMPLETED' THEN 1 END), 0), 1) AS on_time_pct,
                       ROUND(AVG(CASE WHEN status = 'COMPLETED' THEN delay_min END), 1)           AS avg_delay_min
                  FROM trip_base
                 GROUP BY driver_id
            ),
            drv_pax AS (
                SELECT tb.driver_id, SUM(b.seat_count) AS passengers
                  FROM trip_base tb
                  JOIN booking b ON b.trip_id = tb.trip_id AND b.status = 'COMPLETED'
                 GROUP BY tb.driver_id
            ),
            drv_fb AS (
                SELECT tb.driver_id,
                       ROUND(AVG(f.driver_rating), 2) AS driver_rating,
                       COUNT(*)                       AS reviews
                  FROM trip_base tb
                  JOIN feedback f ON f.trip_id = tb.trip_id
                 GROUP BY tb.driver_id
            ),
            scored AS (
                SELECT pe.full_name                  AS driver_name,
                       d.licence_no,
                       dt.completed,
                       dt.cancelled,
                       NVL(dp.passengers, 0)         AS passengers,
                       dt.on_time_pct,
                       dt.avg_delay_min,
                       df.driver_rating,
                       NVL(df.reviews, 0)            AS reviews,
                       -- 50% punctuality, 50% passenger rating (rating scaled to 100)
                       ROUND(0.5 * NVL(dt.on_time_pct, 0)
                           + 0.5 * NVL(df.driver_rating, 0) / 5 * 100, 1) AS score
                  FROM drv_trips dt
                  JOIN driver d        ON d.driver_id   = dt.driver_id
                  JOIN person pe       ON pe.person_id  = d.driver_id
                  LEFT JOIN drv_pax dp ON dp.driver_id  = dt.driver_id
                  LEFT JOIN drv_fb df  ON df.driver_id  = dt.driver_id
            )
            SELECT RANK() OVER (ORDER BY score DESC) AS rank_no,
                   driver_name, licence_no, completed, cancelled, passengers,
                   on_time_pct, avg_delay_min, driver_rating, reviews, score,
                   CASE
                       WHEN score >= 85 THEN 'EXCELLENT'
                       WHEN score >= 70 THEN 'GOOD'
                       WHEN score >= 55 THEN 'FAIR'
                       ELSE 'NEEDS REVIEW'
                   END AS band
              FROM scored
             ORDER BY rank_no, driver_name;

        RETURN l_rc;
    END rc_driver_performance;


    ----------------------------------------------------------------------------
    -- PRINTED REPORTS
    ----------------------------------------------------------------------------
    PROCEDURE rpt_top_routes (p_from IN DATE, p_to IN DATE, p_top_n IN PLS_INTEGER DEFAULT 5) IS
        l_rc    SYS_REFCURSOR;
        r       t_top_route_rec;
        v_rows  PLS_INTEGER := 0;
    BEGIN
        l_rc := rc_top_routes(p_from, p_to, p_top_n);

        print_header('REPORT 1 : MOST FREQUENTLY USED ROUTES (TOP ' || p_top_n || ')',
                     'Period ' || ymd(p_from) || ' to ' || ymd(p_to) || '  |  ranked by confirmed + completed bookings');

        say(num('Rank', 4) || '  ' || col('Code', 8) || col('Route', 40) ||
            num('Trips', 7) || num('Bookings', 10) || num('Seats', 8) ||
            num('Revenue LKR', 17) || num('Load %', 9));
        hr;

        LOOP
            FETCH l_rc INTO r;
            EXIT WHEN l_rc%NOTFOUND;
            v_rows := v_rows + 1;

            say(num(r.rank_no, 4) || '  ' || col(r.route_code, 8) || col(r.route_name, 40) ||
                num(r.trips, 7) || num(r.bookings, 10) || num(r.seats_sold, 8) ||
                num(money(r.revenue), 17) || num(pct(r.load_factor_pct), 9));
        END LOOP;
        CLOSE l_rc;

        IF v_rows = 0 THEN
            raise_err(c_err_no_data, 'No trips ran between ' || ymd(p_from) || ' and ' || ymd(p_to));
        END IF;

        hr;
        say('Load % = seats sold / seats offered across all non-cancelled trips on the route.');

    EXCEPTION
        WHEN e_date_range OR e_no_data OR e_invalid_state THEN
            IF l_rc%ISOPEN THEN CLOSE l_rc; END IF;
            say('Report not produced: ' || SUBSTR(SQLERRM, 12));
        WHEN OTHERS THEN
            IF l_rc%ISOPEN THEN CLOSE l_rc; END IF;
            say('Unexpected error in rpt_top_routes: ' || SQLERRM);
            RAISE;
    END rpt_top_routes;


    PROCEDURE rpt_revenue (p_from IN DATE, p_to IN DATE) IS
        l_rc         SYS_REFCURSOR;
        r_method     t_revenue_method_rec;
        r_route      t_revenue_route_rec;
        v_total      NUMBER;
        v_sum_method NUMBER := 0;
        v_gross      NUMBER := 0;
        v_refunds    NUMBER := 0;
        v_txns       NUMBER := 0;
    BEGIN
        v_total := fn_total_revenue(p_from, p_to);   -- also validates the range

        IF v_total = 0 THEN
            raise_err(c_err_no_data, 'No payments recorded between ' || ymd(p_from) || ' and ' || ymd(p_to));
        END IF;

        print_header('REPORT 2 : TICKET SALES REVENUE',
                     'Period ' || ymd(p_from) || ' to ' || ymd(p_to) || '  |  net = payments less refunds');

        -- By method
        say('A. By payment method');
        hr;
        say(col('Method', 12) || num('Transactions', 14) || num('Gross LKR', 18) ||
            num('Refunds LKR', 16) || num('Net LKR', 18) || num('Share %', 10));
        hr;

        l_rc := rc_revenue_by_method(p_from, p_to);
        LOOP
            FETCH l_rc INTO r_method;
            EXIT WHEN l_rc%NOTFOUND;

            v_sum_method := v_sum_method + r_method.net;
            v_gross      := v_gross      + r_method.gross;
            v_refunds    := v_refunds    + r_method.refunds;
            v_txns       := v_txns       + r_method.txns;

            say(col(r_method.method, 12) || num(r_method.txns, 14) || num(money(r_method.gross), 18) ||
                num(money(r_method.refunds), 16) || num(money(r_method.net), 18) ||
                num(pct(r_method.share_pct), 10));
        END LOOP;
        CLOSE l_rc;

        hr;
        say(col('TOTAL', 12) || num(v_txns, 14) || num(money(v_gross), 18) ||
            num(money(v_refunds), 16) || num(money(v_sum_method), 18) || num('100.0', 10));

        -- By route
        say;
        say('B. By route');
        hr;
        say(col('Code', 8) || col('Route', 40) || num('Bookings', 10) || num('Seats', 9) ||
            num('Net LKR', 18) || num('Per seat', 12));
        hr;

        l_rc := rc_revenue_by_route(p_from, p_to);
        LOOP
            FETCH l_rc INTO r_route;
            EXIT WHEN l_rc%NOTFOUND;

            say(col(r_route.route_code, 8) || col(r_route.route_name, 40) ||
                num(r_route.bookings, 10) || num(r_route.seats, 9) ||
                num(money(r_route.net), 18) || num(money(r_route.avg_per_seat), 12));
        END LOOP;
        CLOSE l_rc;
        hr;

        -- Cross-check the breakdown against the standalone function
        say('Net revenue (fn_total_revenue) : LKR ' || money(v_total));
        say('Reconciliation                 : ' ||
            CASE WHEN v_total = v_sum_method THEN 'OK - method breakdown matches total'
                 ELSE 'MISMATCH of LKR ' || money(v_total - v_sum_method) END);

    EXCEPTION
        WHEN e_date_range OR e_no_data THEN
            IF l_rc%ISOPEN THEN CLOSE l_rc; END IF;
            say('Report not produced: ' || SUBSTR(SQLERRM, 12));
        WHEN OTHERS THEN
            IF l_rc%ISOPEN THEN CLOSE l_rc; END IF;
            say('Unexpected error in rpt_revenue: ' || SQLERRM);
            RAISE;
    END rpt_revenue;


    PROCEDURE rpt_passenger_history (p_passenger_id IN passenger.passenger_id%TYPE,
                                     p_max_rows     IN PLS_INTEGER DEFAULT 15) IS
        l_rc            SYS_REFCURSOR;
        r               t_history_rec;
        v_name          person.full_name%TYPE;
        v_category      passenger.passenger_category%TYPE;
        v_company       corporate_client.company_name%TYPE;
        v_points        passenger.loyalty_points%TYPE;
        v_since         passenger.registered_date%TYPE;
        v_bookings      NUMBER;
        v_completed     NUMBER;
        v_cancelled     NUMBER;
        v_seats         NUMBER;
        v_fav_route     route.route_code%TYPE;
        v_spent         NUMBER;
        v_avg_rating    NUMBER;
        v_rows          PLS_INTEGER := 0;
    BEGIN
        -- Profile (NO_DATA_FOUND -> not found)
        BEGIN
            SELECT pe.full_name, pa.passenger_category, NVL(cc.company_name, '-'),
                   pa.loyalty_points, pa.registered_date
              INTO v_name, v_category, v_company, v_points, v_since
              FROM passenger pa
              JOIN person pe ON pe.person_id = pa.passenger_id
              LEFT JOIN corporate_client cc ON cc.client_id = pa.client_id
             WHERE pa.passenger_id = p_passenger_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                raise_err(c_err_not_found, 'Passenger ' || p_passenger_id || ' does not exist');
        END;

        -- Aggregate travel summary
        SELECT COUNT(*),
               COUNT(CASE WHEN b.status = 'COMPLETED' THEN 1 END),
               COUNT(CASE WHEN b.status = 'CANCELLED' THEN 1 END),
               NVL(SUM(CASE WHEN b.status = 'COMPLETED' THEN b.seat_count END), 0),
               STATS_MODE(r.route_code)
          INTO v_bookings, v_completed, v_cancelled, v_seats, v_fav_route
          FROM booking b
          JOIN trip t  ON t.trip_id  = b.trip_id
          JOIN route r ON r.route_id = t.route_id
         WHERE b.passenger_id = p_passenger_id;

        SELECT NVL(SUM(p.amount - p.refund_amount), 0)
          INTO v_spent
          FROM payment p
          JOIN booking b ON b.booking_id = p.booking_id
         WHERE b.passenger_id = p_passenger_id
           AND p.status IN ('SUCCESS', 'REFUNDED');

        SELECT ROUND(AVG(overall_rating), 2)
          INTO v_avg_rating
          FROM feedback
         WHERE passenger_id = p_passenger_id;

        print_header('REPORT 3 : PASSENGER TRAVEL HISTORY',
                     'Passenger #' || p_passenger_id || '  ' || v_name);

        say(col('Category', 20)       || v_category);
        say(col('Employer', 20)       || v_company);
        say(col('Member since', 20)   || ymd(v_since));
        say(col('Loyalty points', 20) || v_points);
        say(col('Bookings', 20)       || v_bookings || '  (' || v_completed || ' completed, ' ||
                                         v_cancelled || ' cancelled)');
        say(col('Seats travelled', 20)|| v_seats);
        say(col('Net spend', 20)      || 'LKR ' || money(v_spent));
        say(col('Most used route', 20)|| NVL(v_fav_route, '-'));
        say(col('Avg rating given', 20)|| NVL(TO_CHAR(v_avg_rating, 'FM0.00'), '-'));
        say;
        say('Most recent ' || p_max_rows || ' bookings');
        hr;
        say(col('Booking', 12) || col('Date', 11) || col('Dep', 6) || col('Route', 7) ||
            col('From', 23) || col('To', 23) || num('Seats', 5) || num('Amount', 11) || '  ' ||
            col('Status', 11) || col('Paid', 7) || num('Rate', 4));
        hr;

        l_rc := rc_passenger_history(p_passenger_id);
        LOOP
            FETCH l_rc INTO r;
            EXIT WHEN l_rc%NOTFOUND OR v_rows >= p_max_rows;
            v_rows := v_rows + 1;

            say(col(r.booking_ref, 12) || col(ymd(r.trip_date), 11) || col(r.dep_time, 6) ||
                col(r.route_code, 7) || col(r.board_stop, 23) || col(r.drop_stop, 23) ||
                num(r.seat_count, 5) || num(money(r.total_amount), 11) || '  ' ||
                col(r.booking_status, 11) || col(NVL(r.pay_method, '-'), 7) || num(r.rating, 4));
        END LOOP;
        CLOSE l_rc;

        IF v_rows = 0 THEN
            say('  (no bookings yet)');
        END IF;
        hr;

    EXCEPTION
        WHEN e_not_found THEN
            IF l_rc%ISOPEN THEN CLOSE l_rc; END IF;
            say('Report not produced: ' || SUBSTR(SQLERRM, 12));
        WHEN OTHERS THEN
            IF l_rc%ISOPEN THEN CLOSE l_rc; END IF;
            say('Unexpected error in rpt_passenger_history: ' || SQLERRM);
            RAISE;
    END rpt_passenger_history;


    PROCEDURE rpt_maintenance_due (p_days_ahead IN PLS_INTEGER DEFAULT 14,
                                   p_km_buffer  IN PLS_INTEGER DEFAULT 2000) IS
        l_rc         SYS_REFCURSOR;
        r            t_maintenance_rec;
        v_rows       PLS_INTEGER := 0;
        v_overdue    PLS_INTEGER := 0;
        v_insurance  PLS_INTEGER := 0;
        v_soon       PLS_INTEGER := 0;
    BEGIN
        l_rc := rc_maintenance_due(p_days_ahead, p_km_buffer);

        print_header('REPORT 4 : VEHICLES DUE FOR MAINTENANCE',
                     'Service or insurance due within ' || p_days_ahead || ' days, or within ' ||
                     p_km_buffer || ' km of the service interval');

        say(col('Priority', 11) || col('Reg no', 9) || col('Type', 9) || num('Odometer', 10) ||
            num('Last service', 14) || num('Due date', 12) || num('Days', 6) ||
            num('Due km', 10) || num('Km left', 9) || num('Insurance', 12) || num('Open jobs', 11));
        hr;

        LOOP
            FETCH l_rc INTO r;
            EXIT WHEN l_rc%NOTFOUND;
            v_rows := v_rows + 1;

            CASE r.priority
                WHEN 'OVERDUE'   THEN v_overdue   := v_overdue + 1;
                WHEN 'INSURANCE' THEN v_insurance := v_insurance + 1;
                ELSE                  v_soon      := v_soon + 1;
            END CASE;

            say(col(r.priority, 11) || col(r.reg_no, 9) || col(r.type_name, 9) ||
                num(TO_CHAR(r.odometer_km, 'FM999,999,990'), 10) ||
                num(ymd(r.last_service), 14) || num(ymd(r.next_service_due), 12) ||
                num(r.days_remaining, 6) ||
                num(TO_CHAR(r.next_due_km, 'FM999,999,990'), 10) ||
                num(TO_CHAR(r.km_remaining, 'FM999,999,990'), 9) ||
                num(ymd(r.insurance_expiry), 12) || num(r.open_jobs, 11));
        END LOOP;
        CLOSE l_rc;

        hr;
        IF v_rows = 0 THEN
            say('No vehicles are due for maintenance in this window.');
        ELSE
            say(v_rows || ' vehicle(s) flagged: ' || v_overdue || ' overdue, ' ||
                v_insurance || ' insurance renewal, ' || v_soon || ' due soon.');
            say('Negative "Km left" means the vehicle has already passed its service interval.');
        END IF;

    EXCEPTION
        WHEN e_invalid_state THEN
            IF l_rc%ISOPEN THEN CLOSE l_rc; END IF;
            say('Report not produced: ' || SUBSTR(SQLERRM, 12));
        WHEN OTHERS THEN
            IF l_rc%ISOPEN THEN CLOSE l_rc; END IF;
            say('Unexpected error in rpt_maintenance_due: ' || SQLERRM);
            RAISE;
    END rpt_maintenance_due;


    PROCEDURE rpt_driver_performance (p_from IN DATE, p_to IN DATE) IS
        l_rc    SYS_REFCURSOR;
        r       t_driver_rec;
        v_rows  PLS_INTEGER := 0;
    BEGIN
        l_rc := rc_driver_performance(p_from, p_to);

        print_header('REPORT 5 : DRIVER PERFORMANCE SCORECARD',
                     'Period ' || ymd(p_from) || ' to ' || ymd(p_to) ||
                     '  |  score = 50% on-time departures + 50% passenger rating');

        say(num('#', 3) || '  ' || col('Driver', 27) || num('Trips', 6) || num('Cxl', 5) ||
            num('Pax', 7) || num('On-time%', 10) || num('Avg late', 10) ||
            num('Rating', 8) || num('Reviews', 9) || num('Score', 8) || '  ' || col('Band', 13));
        hr;

        LOOP
            FETCH l_rc INTO r;
            EXIT WHEN l_rc%NOTFOUND;
            v_rows := v_rows + 1;

            say(num(r.rank_no, 3) || '  ' || col(r.driver_name, 27) || num(r.completed, 6) ||
                num(r.cancelled, 5) || num(r.passengers, 7) || num(pct(r.on_time_pct), 10) ||
                num(CASE WHEN r.avg_delay_min IS NULL THEN NULL
                         ELSE TO_CHAR(r.avg_delay_min, 'FM990.0') || 'm' END, 10) ||
                num(TO_CHAR(r.driver_rating, 'FM0.00'), 8) || num(r.reviews, 9) ||
                num(pct(r.score), 8) || '  ' || col(r.band, 13));
        END LOOP;
        CLOSE l_rc;

        IF v_rows = 0 THEN
            raise_err(c_err_no_data,
                'No completed or cancelled trips between ' || ymd(p_from) || ' and ' || ymd(p_to));
        END IF;

        hr;
        say('On-time = departed within ' || c_on_time_grace_min || ' minutes of schedule. ' ||
            'Bands: 85+ excellent, 70+ good, 55+ fair.');

    EXCEPTION
        WHEN e_date_range OR e_no_data THEN
            IF l_rc%ISOPEN THEN CLOSE l_rc; END IF;
            say('Report not produced: ' || SUBSTR(SQLERRM, 12));
        WHEN OTHERS THEN
            IF l_rc%ISOPEN THEN CLOSE l_rc; END IF;
            say('Unexpected error in rpt_driver_performance: ' || SQLERRM);
            RAISE;
    END rpt_driver_performance;

END smartmove_pkg;
/


--------------------------------------------------------------------------------
-- Verification
--------------------------------------------------------------------------------
SELECT object_name, object_type, status
  FROM user_objects
 WHERE object_name = 'SMARTMOVE_PKG';

SELECT type, line, position, text
  FROM user_errors
 WHERE name = 'SMARTMOVE_PKG'
 ORDER BY type, sequence;
