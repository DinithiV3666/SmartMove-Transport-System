const router = require('express').Router();
const db = require('../db/oracle');
const { asyncHandler } = require('../lib/errors');
const { todayISO } = require('../lib/validate');

router.get('/', asyncHandler(async (req, res) => {
  const from = todayISO(-30);
  const to = todayISO(0);
  const [today, bookings, revenue, fleet, due, upcoming, topRoutes, daily] = await Promise.all([
    db.query(
      `SELECT status, COUNT(*) AS n FROM trip WHERE trip_date = TRUNC(SYSDATE) GROUP BY status`),
    db.queryOne(
      `SELECT COUNT(*) AS bookings, NVL(SUM(seat_count), 0) AS seats
         FROM booking
        WHERE booked_at >= SYSTIMESTAMP - INTERVAL '30' DAY
          AND status IN ('CONFIRMED', 'COMPLETED')`),
    db.queryOne(
      `SELECT smartmove_pkg.fn_total_revenue(TO_DATE(:p_from, 'YYYY-MM-DD'), TO_DATE(:p_to, 'YYYY-MM-DD')) AS net
         FROM dual`, { p_from: from, p_to: to }),
    db.query(`SELECT status, COUNT(*) AS n FROM vehicle GROUP BY status`),
    db.refCursor(`smartmove_pkg.rc_maintenance_due(:p_days, :p_km)`, { p_days: 14, p_km: 2000 }),
    db.query(
      `SELECT * FROM (
         SELECT t.trip_id, t.scheduled_departure, t.status, t.seats_available,
                r.route_code, r.route_name, v.reg_no, v.seat_capacity
           FROM trip t
           JOIN route r   ON r.route_id   = t.route_id
           JOIN vehicle v ON v.vehicle_id = t.vehicle_id
          WHERE t.scheduled_departure >= CAST(SYSTIMESTAMP AS TIMESTAMP)
            AND t.status IN ('SCHEDULED', 'BOARDING', 'DELAYED')
          ORDER BY t.scheduled_departure)
        WHERE ROWNUM <= 8`),
    db.refCursor(`smartmove_pkg.rc_top_routes(TO_DATE(:p_from, 'YYYY-MM-DD'), TO_DATE(:p_to, 'YYYY-MM-DD'), :p_n)`,
      { p_from: from, p_to: to, p_n: 6 }),
    db.query(
      `SELECT TO_CHAR(TRUNC(paid_at), 'YYYY-MM-DD') AS day,
              SUM(amount - refund_amount)          AS net
         FROM payment
        WHERE status IN ('SUCCESS', 'REFUNDED')
          AND paid_at >= CAST(TRUNC(SYSDATE) - 30 AS TIMESTAMP)
        GROUP BY TRUNC(paid_at)
        ORDER BY TRUNC(paid_at)`),
  ]);

  res.json({
    period: { from, to },
    tripsToday: Object.fromEntries(today.map((r) => [r.status, r.n])),
    bookings30d: bookings,
    revenue30d: revenue ? revenue.net : 0,
    fleet: Object.fromEntries(fleet.map((r) => [r.status, r.n])),
    maintenanceDue: due.length,
    upcoming,
    topRoutes,
    dailyRevenue: daily,
  });
}));

module.exports = router;
