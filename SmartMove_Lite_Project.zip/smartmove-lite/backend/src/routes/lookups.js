const router = require('express').Router();
const db = require('../db/oracle');
const { asyncHandler } = require('../lib/errors');

// Small reference lists used to fill dropdowns in the UI.
router.get('/', asyncHandler(async (req, res) => {
  const [stops, routes] = await Promise.all([
    db.query(`SELECT stop_id, stop_name, city, is_terminal FROM stop ORDER BY stop_name`),
    db.query(`SELECT route_id, route_code, route_name FROM route WHERE status = 'ACTIVE' ORDER BY route_code`),
  ]);
  res.json({ stops, routes });
}));

module.exports = router;
