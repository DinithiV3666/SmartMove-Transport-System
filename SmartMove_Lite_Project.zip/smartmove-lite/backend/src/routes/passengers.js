const router = require('express').Router();
const db = require('../db/oracle');
const { asyncHandler } = require('../lib/errors');

router.get('/', asyncHandler(async (req, res) => {
  const search = req.query.q ? `%${String(req.query.q).trim().toUpperCase()}%` : null;
  res.json(await db.query(
    `SELECT pa.passenger_id, pe.full_name, pe.nic, pe.phone, pe.email, pa.passenger_category,
            pa.loyalty_points, pa.status, pa.registered_date, cc.company_name
       FROM passenger pa
       JOIN person pe ON pe.person_id = pa.passenger_id
       LEFT JOIN corporate_client cc ON cc.client_id = pa.client_id
      WHERE (:p_q IS NULL OR UPPER(pe.full_name) LIKE :p_q OR pe.nic LIKE :p_q OR pe.phone LIKE :p_q)
      ORDER BY pe.full_name`, { p_q: search }));
}));

module.exports = router;
