/**
 * The five business reports, each served straight from its smartmove_pkg
 * ref-cursor function, so the web app and 05_demo.sql always agree.
 */
const router = require('express').Router();
const db = require('../db/oracle');
const { asyncHandler } = require('../lib/errors');
const v = require('../lib/validate');

const range = (q, defaultDays = 30) => ({
  p_from: v.date(q.from || v.todayISO(-defaultDays), 'from'),
  p_to: v.date(q.to || v.todayISO(0), 'to'),
});
const D = (name) => `TO_DATE(:${name}, 'YYYY-MM-DD')`;

// Report 1: most frequently used routes
router.get('/top-routes', asyncHandler(async (req, res) => {
  const r = range(req.query, 90);
  const top = v.int(req.query.top || 5, 'top');
  res.json({ ...r, rows: await db.refCursor(`smartmove_pkg.rc_top_routes(${D('p_from')}, ${D('p_to')}, :p_n)`, { ...r, p_n: top }) });
}));

// Report 2: revenue in a period (function total + two breakdowns)
router.get('/revenue', asyncHandler(async (req, res) => {
  const r = range(req.query, 30);
  const [total, byMethod, byRoute] = await Promise.all([
    db.queryOne(`SELECT smartmove_pkg.fn_total_revenue(${D('p_from')}, ${D('p_to')}) AS net FROM dual`, r),
    db.refCursor(`smartmove_pkg.rc_revenue_by_method(${D('p_from')}, ${D('p_to')})`, r),
    db.refCursor(`smartmove_pkg.rc_revenue_by_route(${D('p_from')}, ${D('p_to')})`, r),
  ]);
  res.json({ ...r, totalNet: total ? total.net : 0, byMethod, byRoute });
}));

// Report 3: passenger travel history
router.get('/passenger-history/:id', asyncHandler(async (req, res) => {
  const id = v.int(req.params.id, 'Passenger id');
  res.json({ passengerId: id, rows: await db.refCursor(`smartmove_pkg.rc_passenger_history(:id)`, { id }) });
}));

// Report 4: vehicles due for maintenance
router.get('/maintenance-due', asyncHandler(async (req, res) => {
  const days = v.int(req.query.days || 14, 'days', { min: 0 });
  const km = v.int(req.query.km || 2000, 'km', { min: 0 });
  res.json({ days, km, rows: await db.refCursor(`smartmove_pkg.rc_maintenance_due(:p_days, :p_km)`, { p_days: days, p_km: km }) });
}));

// Report 5: driver performance scorecard
router.get('/driver-performance', asyncHandler(async (req, res) => {
  const r = range(req.query, 60);
  res.json({ ...r, rows: await db.refCursor(`smartmove_pkg.rc_driver_performance(${D('p_from')}, ${D('p_to')})`, r) });
}));

module.exports = router;
