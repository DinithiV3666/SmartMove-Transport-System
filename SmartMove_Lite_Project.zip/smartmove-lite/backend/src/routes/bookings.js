const router = require('express').Router();
const db = require('../db/oracle');
const { oracledb } = db;
const { asyncHandler, HttpError } = require('../lib/errors');
const v = require('../lib/validate');

router.get('/', asyncHandler(async (req, res) => {
  const binds = {
    p_status: v.oneOf(req.query.status, 'status',
      ['PENDING', 'CONFIRMED', 'CANCELLED', 'COMPLETED', 'NO_SHOW'], { optional: true }),
    p_pax: v.int(req.query.passengerId, 'passengerId', { optional: true }),
  };
  res.json(await db.query(
    `SELECT * FROM (
       SELECT b.booking_id, b.booking_ref, b.booked_at, b.seat_count, b.total_amount, b.status,
              b.booking_channel, pe.full_name AS passenger_name, r.route_code, t.trip_id, t.scheduled_departure
         FROM booking b
         JOIN person pe ON pe.person_id = b.passenger_id
         JOIN trip t    ON t.trip_id    = b.trip_id
         JOIN route r   ON r.route_id   = t.route_id
        WHERE (:p_status IS NULL OR b.status = :p_status)
          AND (:p_pax IS NULL OR b.passenger_id = :p_pax)
        ORDER BY b.booked_at DESC)
      WHERE ROWNUM <= 100`, binds));
}));

// Look up by numeric id or by booking reference (SM00001234).
router.get('/:key', asyncHandler(async (req, res) => {
  const key = String(req.params.key).trim().toUpperCase();
  const where = /^\d+$/.test(key) ? 'b.booking_id = :p_key' : 'b.booking_ref = :p_key';
  const booking = await db.queryOne(
    `SELECT b.booking_id, b.booking_ref, b.booked_at, b.seat_count, b.total_amount, b.status,
            b.booking_channel, b.cancelled_at, b.passenger_id, pe.full_name AS passenger_name,
            t.trip_id, t.scheduled_departure, t.status AS trip_status, r.route_code, r.route_name,
            bs.stop_name AS board_stop, ds.stop_name AS drop_stop, v.reg_no
       FROM booking b
       JOIN person pe ON pe.person_id = b.passenger_id
       JOIN trip t    ON t.trip_id    = b.trip_id
       JOIN route r   ON r.route_id   = t.route_id
       JOIN vehicle v ON v.vehicle_id = t.vehicle_id
       JOIN stop bs   ON bs.stop_id   = b.board_stop_id
       JOIN stop ds   ON ds.stop_id   = b.drop_stop_id
      WHERE ${where}`, { p_key: /^\d+$/.test(key) ? Number(key) : key });
  if (!booking) throw new HttpError(404, `No booking found for "${req.params.key}".`);
  const [tickets, payments] = await Promise.all([
    db.query(`SELECT ticket_id, seat_no, passenger_name, fare, qr_code, status
                FROM ticket WHERE booking_id = :id ORDER BY TO_NUMBER(seat_no)`, { id: booking.bookingId }),
    db.query(`SELECT p.payment_id, p.amount, p.method, p.txn_ref, p.paid_at, p.status, p.refund_amount,
                     cp.card_brand, cp.card_last4, wp.wallet_provider, cs.receipt_no
                FROM payment p
                LEFT JOIN card_payment cp   ON cp.payment_id = p.payment_id
                LEFT JOIN wallet_payment wp ON wp.payment_id = p.payment_id
                LEFT JOIN cash_payment cs   ON cs.payment_id = p.payment_id
               WHERE p.booking_id = :id ORDER BY p.paid_at`, { id: booking.bookingId }),
  ]);
  res.json({ ...booking, tickets, payments });
}));

// Price a journey before booking (smartmove_pkg.fn_calculate_fare).
router.post('/quote', asyncHandler(async (req, res) => {
  const b = req.body || {};
  const binds = {
    route_id: v.int(b.routeId, 'Route'),
    board: v.int(b.boardStopId, 'Boarding stop'),
    drop_stop: v.int(b.dropStopId, 'Drop-off stop'),
    pax: v.int(b.passengerId, 'Passenger'),
  };
  const row = await db.queryOne(
    `SELECT smartmove_pkg.fn_calculate_fare(:route_id, :board, :drop_stop, :pax) AS unit_fare FROM dual`, binds);
  const seats = v.int(b.seatCount || 1, 'Seat count');
  res.json({ unitFare: row.unitFare, seatCount: seats, total: Number((row.unitFare * seats).toFixed(2)) });
}));

// smartmove_pkg.create_booking: locks the trip, allocates seats, prices with discounts.
router.post('/', asyncHandler(async (req, res) => {
  const b = req.body || {};
  const binds = {
    pax: v.int(b.passengerId, 'Passenger'),
    trip: v.int(b.tripId, 'Trip'),
    board: v.int(b.boardStopId, 'Boarding stop'),
    drop_stop: v.int(b.dropStopId, 'Drop-off stop'),
    seats: v.int(b.seatCount, 'Seat count'),
    channel: v.oneOf(b.channel || 'COUNTER', 'Channel', ['ONLINE', 'MOBILE', 'COUNTER', 'AGENT']),
    out_id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
    out_ref: { dir: oracledb.BIND_OUT, type: oracledb.STRING, maxSize: 15 },
    out_total: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
  };
  const result = await db.execute(
    `BEGIN
       smartmove_pkg.create_booking(
         p_passenger_id => :pax, p_trip_id => :trip, p_board_stop_id => :board,
         p_drop_stop_id => :drop_stop, p_seat_count => :seats, p_channel => :channel,
         o_booking_id => :out_id, o_booking_ref => :out_ref, o_total_amount => :out_total);
     END;`, binds);
  const out = { bookingId: result.outBinds.out_id, bookingRef: result.outBinds.out_ref, totalAmount: result.outBinds.out_total };
  res.status(201).json(out);
}));

// smartmove_pkg.record_payment: validates amount and subtype details; trigger confirms the booking.
router.post('/:id/pay', asyncHandler(async (req, res) => {
  const id = v.int(req.params.id, 'Booking id');
  const b = req.body || {};
  const binds = {
    id,
    method: v.oneOf(b.method, 'Payment method', ['CARD', 'CASH', 'WALLET']),
    amount: v.num(b.amount, 'Amount', { min: 0.01 }),
    card_brand: b.cardBrand ? String(b.cardBrand).toUpperCase() : null,
    card_last4: b.cardLast4 ? String(b.cardLast4) : null,
    gateway: b.gateway || null,
    wallet_provider: b.walletProvider || null,
    wallet_ref: b.walletRef || null,
    collected_by: v.int(b.collectedBy, 'Collected by', { optional: true }),
    out_id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
  };
  const result = await db.execute(
    `BEGIN
       smartmove_pkg.record_payment(
         p_booking_id => :id, p_method => :method, p_amount => :amount,
         p_card_brand => :card_brand, p_card_last4 => :card_last4, p_gateway => :gateway,
         p_wallet_provider => :wallet_provider, p_wallet_ref => :wallet_ref,
         p_collected_by => :collected_by, o_payment_id => :out_id);
     END;`, binds);
  res.status(201).json({ paymentId: result.outBinds.out_id, bookingId: id });
}));

// smartmove_pkg.cancel_booking: refund policy 90% / 50% / 0% by time to departure.
router.post('/:id/cancel', asyncHandler(async (req, res) => {
  const id = v.int(req.params.id, 'Booking id');
  const result = await db.execute(
    `BEGIN smartmove_pkg.cancel_booking(p_booking_id => :id, o_refund_amount => :refund); END;`,
    { id, refund: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER } });
  res.json({ bookingId: id, refundAmount: result.outBinds.refund });
}));

module.exports = router;
