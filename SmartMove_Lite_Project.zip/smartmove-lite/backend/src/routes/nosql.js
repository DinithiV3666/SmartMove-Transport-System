/**
 * MongoDB endpoints: the two collections that do not fit well in tables.
 * Documents refer to Oracle rows by plain numeric ids; Oracle stays the
 * source of truth for those rows.
 *
 *   gps_tracking    location pings per trip (append-heavy, geospatial index)
 *   feedback_media  tags, photos and replies attached to an Oracle feedback row
 */
const router = require('express').Router();
const mongo = require('../db/mongo');
const db = require('../db/oracle');
const { asyncHandler, HttpError } = require('../lib/errors');
const v = require('../lib/validate');

router.use(mongo.requireMongo);

const limitOf = (q, def = 50) => Math.min(v.int(q.limit || def, 'limit'), 500);

// ---- GPS tracking ---------------------------------------------------------
router.get('/tracking/:tripId', asyncHandler(async (req, res) => {
  const tripId = v.int(req.params.tripId, 'Trip id');
  const pings = await mongo.collection('gps_tracking')
    .find({ tripId }).sort({ ts: 1 }).limit(limitOf(req.query, 500)).toArray();
  res.json(pings);
}));

router.post('/tracking/:tripId', asyncHandler(async (req, res) => {
  const tripId = v.int(req.params.tripId, 'Trip id');
  const b = req.body || {};
  const lat = v.num(b.lat, 'Latitude', { min: -90 });
  const lng = v.num(b.lng, 'Longitude', { min: -180 });
  const trip = await db.queryOne(`SELECT vehicle_id FROM trip WHERE trip_id = :id`, { id: tripId });
  if (!trip) throw new HttpError(404, `Trip ${tripId} does not exist in Oracle.`);
  const doc = {
    tripId,
    vehicleId: trip.vehicleId,
    ts: b.ts ? new Date(b.ts) : new Date(),
    location: { type: 'Point', coordinates: [lng, lat] },
    speedKmh: b.speedKmh !== undefined ? Number(b.speedKmh) : null,
    heading: b.heading !== undefined ? Number(b.heading) : null,
  };
  const r = await mongo.collection('gps_tracking').insertOne(doc);
  res.status(201).json({ id: r.insertedId, ...doc });
}));

// Simulate a trip's journey: one ping per route stop plus points in between.
router.post('/tracking/:tripId/simulate', asyncHandler(async (req, res) => {
  const tripId = v.int(req.params.tripId, 'Trip id');
  const trip = await db.queryOne(
    `SELECT t.vehicle_id, t.route_id, t.scheduled_departure FROM trip t WHERE t.trip_id = :id`, { id: tripId });
  if (!trip) throw new HttpError(404, `Trip ${tripId} does not exist in Oracle.`);
  const stops = await db.query(
    `SELECT s.latitude, s.longitude, rs.offset_min
       FROM route_stop rs JOIN stop s ON s.stop_id = rs.stop_id
      WHERE rs.route_id = :r ORDER BY rs.stop_seq`, { r: trip.routeId });
  const start = new Date(trip.scheduledDeparture);
  const docs = [];
  for (let i = 0; i < stops.length - 1; i += 1) {
    const a = stops[i]; const b = stops[i + 1];
    for (let k = 0; k < 4; k += 1) {
      const f = k / 4;
      const minutes = a.offsetMin + (b.offsetMin - a.offsetMin) * f;
      docs.push({
        tripId,
        vehicleId: trip.vehicleId,
        ts: new Date(start.getTime() + minutes * 60000),
        location: { type: 'Point', coordinates: [a.longitude + (b.longitude - a.longitude) * f, a.latitude + (b.latitude - a.latitude) * f] },
        speedKmh: Math.round(35 + Math.random() * 35),
        heading: Math.round((Math.atan2(b.longitude - a.longitude, b.latitude - a.latitude) * 180) / Math.PI + 360) % 360,
        simulated: true,
      });
    }
  }
  const last = stops[stops.length - 1];
  if (last) {
    docs.push({ tripId, vehicleId: trip.vehicleId, ts: new Date(start.getTime() + last.offsetMin * 60000),
      location: { type: 'Point', coordinates: [last.longitude, last.latitude] }, speedKmh: 0, heading: null, simulated: true });
  }
  await mongo.collection('gps_tracking').deleteMany({ tripId, simulated: true });
  if (docs.length) await mongo.collection('gps_tracking').insertMany(docs);
  res.status(201).json({ tripId, pings: docs.length });
}));

// ---- Feedback: ratings in Oracle, free-form extras in MongoDB ------------------
router.get('/feedback', asyncHandler(async (req, res) => {
  const rows = await db.query(
    `SELECT f.feedback_id, f.overall_rating, f.driver_rating, f.vehicle_rating, f.punctuality,
            f.comments, f.submitted_at, f.response, pe.full_name AS passenger_name,
            t.trip_id, r.route_code
       FROM feedback f
       JOIN person pe ON pe.person_id = f.passenger_id
       JOIN trip t    ON t.trip_id    = f.trip_id
       JOIN route r   ON r.route_id   = t.route_id
      ORDER BY f.submitted_at DESC`);
  const docs = await mongo.collection('feedback_media')
    .find({ feedbackId: { $in: rows.map((r) => r.feedbackId) } }).toArray();
  const byId = new Map(docs.map((d) => [d.feedbackId, d]));
  res.json(rows.map((r) => ({ ...r, media: byId.get(r.feedbackId) || null })));
}));

module.exports = router;
