const router = require('express').Router();
const db = require('../db/oracle');
const { oracledb } = db;
const { asyncHandler, HttpError } = require('../lib/errors');
const v = require('../lib/validate');

const TRIP_SELECT = `
  SELECT t.trip_id, t.trip_date, t.scheduled_departure, t.actual_departure, t.actual_arrival,
         t.seats_available, t.status, t.schedule_id,
         r.route_id, r.route_code, r.route_name, r.duration_min, r.base_fare,
         v.vehicle_id, v.reg_no, v.make_model, v.seat_capacity, vt.type_name,
         d.driver_id, p.full_name AS driver_name
    FROM trip t
    JOIN route r         ON r.route_id   = t.route_id
    JOIN vehicle v       ON v.vehicle_id = t.vehicle_id
    JOIN vehicle_type vt ON vt.type_id   = v.type_id
    JOIN driver d        ON d.driver_id  = t.driver_id
    JOIN person p        ON p.person_id  = d.driver_id`;

// Search trips by date, route and status.
router.get('/', asyncHandler(async (req, res) => {
  const binds = {
    p_date: v.date(req.query.date, 'date', { optional: true }),
    p_route: v.int(req.query.routeId, 'routeId', { optional: true }),
    p_status: v.oneOf(req.query.status, 'status',
      ['SCHEDULED', 'BOARDING', 'IN_TRANSIT', 'COMPLETED', 'CANCELLED', 'DELAYED'], { optional: true }),
  };
  res.json(await db.query(
    `SELECT * FROM (
       ${TRIP_SELECT}
        WHERE (:p_date IS NULL OR t.trip_date = TO_DATE(:p_date, 'YYYY-MM-DD'))
          AND (:p_route IS NULL OR t.route_id = :p_route)
          AND (:p_status IS NULL OR t.status = :p_status)
        ORDER BY t.scheduled_departure)
      WHERE ROWNUM <= 200`, binds));
}));

router.get('/:id', asyncHandler(async (req, res) => {
  const id = v.int(req.params.id, 'Trip id');
  const trip = await db.queryOne(`${TRIP_SELECT} WHERE t.trip_id = :id`, { id });
  if (!trip) throw new HttpError(404, `Trip ${id} does not exist.`);
  const [stops, bookings] = await Promise.all([
    db.query(
      `SELECT rs.stop_seq, rs.offset_min, rs.fare_from_origin, s.stop_id, s.stop_name, s.city,
              s.latitude, s.longitude
         FROM route_stop rs JOIN stop s ON s.stop_id = rs.stop_id
        WHERE rs.route_id = :route_id ORDER BY rs.stop_seq`, { route_id: trip.routeId }),
    db.query(
      `SELECT b.booking_id, b.booking_ref, b.seat_count, b.total_amount, b.status, b.booked_at,
              pe.full_name AS passenger_name, bs.stop_name AS board_stop, ds.stop_name AS drop_stop
         FROM booking b
         JOIN person pe ON pe.person_id = b.passenger_id
         JOIN stop bs   ON bs.stop_id   = b.board_stop_id
         JOIN stop ds   ON ds.stop_id   = b.drop_stop_id
        WHERE b.trip_id = :id
        ORDER BY b.booked_at`, { id }),
  ]);
  res.json({ ...trip, stops, bookings });
}));

// Move a trip through its lifecycle (trg_trip_status_change updates the driver).
router.patch('/:id/status', asyncHandler(async (req, res) => {
  const id = v.int(req.params.id, 'Trip id');
  const status = v.oneOf(req.body && req.body.status, 'status', ['BOARDING', 'IN_TRANSIT', 'DELAYED', 'CANCELLED']);
  if (status === 'CANCELLED') {
    const open = await db.queryOne(
      `SELECT COUNT(*) AS n FROM booking WHERE trip_id = :id AND status IN ('PENDING', 'CONFIRMED')`, { id });
    if (open && open.n > 0) {
      throw new HttpError(409, `Trip ${id} still has ${open.n} open booking(s). Cancel those bookings first.`);
    }
  }
  const result = await db.execute(
    `UPDATE trip SET status = :p_status,
            actual_departure = CASE WHEN :p_status = 'IN_TRANSIT' AND actual_departure IS NULL
                                    THEN CAST(SYSTIMESTAMP AS TIMESTAMP) ELSE actual_departure END
      WHERE trip_id = :id AND status NOT IN ('COMPLETED', 'CANCELLED')`, { p_status: status, id });
  if (!result.rowsAffected) throw new HttpError(409, `Trip ${id} does not exist or is already completed or cancelled.`);
  res.json({ tripId: id, status });
}));

// smartmove_pkg.complete_trip: closes bookings, awards loyalty points; trigger advances the odometer.
router.post('/:id/complete', asyncHandler(async (req, res) => {
  const id = v.int(req.params.id, 'Trip id');
  const result = await db.execute(
    `BEGIN smartmove_pkg.complete_trip(p_trip_id => :id, o_passengers_done => :done); END;`,
    { id, done: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER } });
  res.json({ tripId: id, passengersCompleted: result.outBinds.done });
}));

module.exports = router;
