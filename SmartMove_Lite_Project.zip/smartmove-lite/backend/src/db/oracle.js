/**
 * Oracle access layer (node-oracledb, thin mode: no Instant Client needed).
 *
 *   query(sql, binds)           -> array of rows with camelCase keys
 *   queryOne(sql, binds)        -> first row or null
 *   execute(sql, binds)         -> raw result (autoCommit on)
 *   refCursor(plsqlExpr, binds) -> rows from a function returning SYS_REFCURSOR
 */
const oracledb = require('oracledb');
const config = require('../config');

oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;
oracledb.fetchAsString = [oracledb.CLOB];

let pool = null;
let lastError = null;

async function init() {
  try {
    const created = await oracledb.createPool({
      ...config.oracle,
      poolMin: 0,
      poolMax: 6,
      poolIncrement: 1,
      poolTimeout: 60,
    });
    // The pool is lazy: prove the credentials and address work before saying "ready".
    const conn = await created.getConnection();
    await conn.ping();
    await conn.close();
    pool = created;
    lastError = null;
    console.log(`Oracle pool ready (${config.oracle.connectString})`);
  } catch (err) {
    pool = null;
    lastError = friendly(err);
    console.error(`Oracle unavailable: ${lastError}`);
  }
}

/** Turn driver/listener errors into advice a student can act on. */
function friendly(err) {
  const msg = String((err && err.message) || err);
  if (/ORA-01017/.test(msg)) return 'Oracle rejected the username or password in backend/.env (ORA-01017).';
  if (/NJS-503|NJS-500|ECONNREFUSED|ORA-12541|ETIMEDOUT|ENOTFOUND/.test(msg)) {
    return `Cannot reach Oracle at ${config.oracle.connectString}. Is the database running, and are the host and port right?`;
  }
  if (/ORA-12514|NJS-518/.test(msg)) {
    return `Oracle is running but does not recognise the service in ORACLE_CONNECT_STRING (${config.oracle.connectString}). Use FREEPDB1 for a local install.`;
  }
  return msg.split('\n')[0];
}

function status() {
  return { connected: Boolean(pool), error: lastError };
}

const camel = (key) => key.toLowerCase().replace(/_([a-z0-9])/g, (_, c) => c.toUpperCase());
const shape = (row) => {
  const out = {};
  for (const [k, v] of Object.entries(row)) out[camel(k)] = v;
  return out;
};

async function withConnection(fn) {
  if (!pool) {
    await init();
    if (!pool) {
      const err = new Error(lastError || 'The Oracle database is not reachable. Check backend/.env and that the database is running.');
      err.status = 503;
      throw err;
    }
  }
  let conn;
  try {
    conn = await pool.getConnection();
  } catch (err) {
    pool = null;
    lastError = friendly(err);
    const e = new Error(lastError);
    e.status = 503;
    throw e;
  }
  try {
    return await fn(conn);
  } finally {
    await conn.close();
  }
}

async function query(sql, binds = {}) {
  return withConnection(async (conn) => {
    const result = await conn.execute(sql, binds);
    return (result.rows || []).map(shape);
  });
}

async function queryOne(sql, binds = {}) {
  const rows = await query(sql, binds);
  return rows[0] || null;
}

async function execute(sql, binds = {}, options = {}) {
  return withConnection((conn) => conn.execute(sql, binds, { autoCommit: true, ...options }));
}

async function refCursor(plsqlCall, binds = {}) {
  return withConnection(async (conn) => {
    const result = await conn.execute(
      `BEGIN :rc := ${plsqlCall}; END;`,
      { ...binds, rc: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR } },
    );
    const rs = result.outBinds.rc;
    try {
      const rows = await rs.getRows();
      return rows.map(shape);
    } finally {
      await rs.close();
    }
  });
}

async function close() {
  if (pool) await pool.close(5);
}

module.exports = { oracledb, init, status, query, queryOne, execute, refCursor, close };
