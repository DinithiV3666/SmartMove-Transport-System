/**
 * MongoDB access layer. MongoDB is optional: if MONGODB_URI is not set or the
 * cluster is unreachable, every Oracle feature keeps working and the NoSQL
 * endpoints answer 503.
 */
const { MongoClient } = require('mongodb');
const config = require('../config');

let client = null;
let db = null;
let lastError = config.mongo.uri ? null : 'MONGODB_URI is not set in backend/.env';

async function init() {
  if (!config.mongo.uri) return;
  try {
    client = new MongoClient(config.mongo.uri, { serverSelectionTimeoutMS: 8000 });
    await client.connect();
    db = client.db(config.mongo.dbName);
    lastError = null;
    console.log(`MongoDB ready (database "${config.mongo.dbName}")`);
  } catch (err) {
    db = null;
    lastError = err.message;
    console.error(`MongoDB unavailable: ${err.message}`);
  }
}

function status() {
  return { connected: Boolean(db), error: lastError };
}

function collection(name) {
  return db ? db.collection(name) : null;
}

/** Express middleware: answer 503 when MongoDB isn't connected. */
function requireMongo(req, res, next) {
  if (!db) {
    return res.status(503).json({
      error: 'MongoDB is not connected. Set MONGODB_URI in backend/.env and restart the API.',
    });
  }
  return next();
}

async function close() {
  if (client) await client.close();
}

module.exports = { init, status, collection, requireMongo, close };
