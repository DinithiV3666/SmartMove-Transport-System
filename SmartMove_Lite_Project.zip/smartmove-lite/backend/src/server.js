const express = require('express');
const cors = require('cors');
const config = require('./config');
const oracle = require('./db/oracle');
const mongo = require('./db/mongo');
const { errorMiddleware } = require('./lib/errors');

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

app.get('/api/health', (req, res) => {
  res.json({ api: 'ok', oracle: oracle.status(), mongo: mongo.status(), time: new Date().toISOString() });
});

app.use('/api/lookups', require('./routes/lookups'));
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/passengers', require('./routes/passengers'));
app.use('/api/trips', require('./routes/trips'));
app.use('/api/bookings', require('./routes/bookings'));
app.use('/api/reports', require('./routes/reports'));
app.use('/api/nosql', require('./routes/nosql'));

app.use('/api', (req, res) => res.status(404).json({ error: `No endpoint ${req.method} ${req.originalUrl}` }));
app.use(errorMiddleware);

async function start() {
  await Promise.all([oracle.init(), mongo.init()]);
  const server = app.listen(config.port, () => {
    console.log(`SmartMove API listening on http://localhost:${config.port}`);
  });
  const shutdown = async () => {
    server.close();
    await Promise.allSettled([oracle.close(), mongo.close()]);
    process.exit(0);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

if (require.main === module) start();

module.exports = app;
