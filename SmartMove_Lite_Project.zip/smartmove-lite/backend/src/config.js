const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

function required(name) {
  const value = process.env[name];
  if (!value) {
    console.error(`Missing ${name} in backend/.env (copy .env.example to .env and fill it in).`);
    process.exit(1);
  }
  return value;
}

module.exports = {
  port: Number(process.env.PORT || 4000),
  oracle: {
    user: required('ORACLE_USER'),
    password: required('ORACLE_PASSWORD'),
    connectString: required('ORACLE_CONNECT_STRING'),
  },
  mongo: {
    uri: process.env.MONGODB_URI && !process.env.MONGODB_URI.includes('<password>')
      ? process.env.MONGODB_URI : null,
    dbName: process.env.MONGODB_DB || 'smartmove',
  },
};
