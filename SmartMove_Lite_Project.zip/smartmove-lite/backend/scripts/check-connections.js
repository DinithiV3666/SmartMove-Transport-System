/**
 * npm run check  ->  confirms backend/.env works before starting the API.
 */
const oracle = require('../src/db/oracle');
const mongo = require('../src/db/mongo');

(async () => {
  await oracle.init();
  const o = oracle.status();
  if (o.connected) {
    try {
      const pkg = await oracle.query(
        `SELECT object_type, status FROM user_objects WHERE object_name = 'SMARTMOVE_PKG' ORDER BY object_type`);
      const trips = await oracle.queryOne(`SELECT COUNT(*) AS n FROM trip`);
      console.log(`Oracle   OK  - ${trips.n} trips; SMARTMOVE_PKG: ${pkg.map((p) => `${p.objectType} ${p.status}`).join(', ') || 'MISSING (run 04_smartmove_pkg.sql)'}`);
    } catch (err) {
      console.log(`Oracle   connected, but the schema looks incomplete: ${err.message}`);
    }
  } else {
    console.log(`Oracle   FAILED - ${o.error}`);
  }
  await mongo.init();
  const m = mongo.status();
  console.log(m.connected ? 'MongoDB  OK' : `MongoDB  not connected - ${m.error}`);
  await Promise.allSettled([oracle.close(), mongo.close()]);
  process.exit(o.connected ? 0 : 1);
})();
