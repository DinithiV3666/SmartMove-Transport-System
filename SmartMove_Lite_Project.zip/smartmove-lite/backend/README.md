# SmartMove Lite: backend (Express API)

Node.js + Express over Oracle (node-oracledb, thin mode) and MongoDB.
Bookings, payments, cancellations and trip completion call `smartmove_pkg`,
and the five reports call its `rc_*` ref-cursor functions, so the API and
`database/05_demo.sql` always agree.

## Run

```
cd backend
npm install
copy .env.example .env      (Mac: cp .env.example .env)  then edit .env
npm run check               confirms Oracle and MongoDB connect
npm run dev                 starts the API on http://localhost:4000
```

## Endpoints

| Area | Endpoints |
|---|---|
| Status | `GET /api/health`, `GET /api/dashboard`, `GET /api/lookups`, `GET /api/passengers` |
| Trips | `GET /api/trips?date=&routeId=&status=`, `GET /api/trips/:id`, `PATCH /api/trips/:id/status`, `POST /api/trips/:id/complete` |
| Bookings | `GET /api/bookings`, `GET /api/bookings/:idOrRef`, `POST /api/bookings/quote`, `POST /api/bookings`, `POST /api/bookings/:id/pay`, `POST /api/bookings/:id/cancel` |
| Reports | `GET /api/reports/top-routes`, `/revenue`, `/passenger-history/:id`, `/maintenance-due`, `/driver-performance` |
| MongoDB | `GET/POST /api/nosql/tracking/:tripId`, `POST /api/nosql/tracking/:tripId/simulate`, `GET /api/nosql/feedback` |

Business-rule errors from the package (ORA-20001 to ORA-20015) come back as
`4xx` responses carrying the package's own message. MongoDB is optional:
without it everything except the MongoDB page still works.
